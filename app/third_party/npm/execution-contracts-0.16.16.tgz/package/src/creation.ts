/** Shared wire contract for a host and an embedded creation module. */
export const CREATION_ENTRY_SCHEMA = "techstack.creation-entry/v1";
export const CREATION_EVENT_SCHEMA = "techstack.creation-event/v1";
export const CREATION_EMBED_PATH = "/embed/creation";

export const CREATION_STEP_KEYS = ["goals", "server", "access", "users", "login"] as const;
export type CreationStepKey = (typeof CREATION_STEP_KEYS)[number];
export const CREATION_ENTRY_PROCESSES = [
  "add-use-case",
  "place-on-server",
  "add-server",
  "stack",
] as const;
export type CreationEntryProcess = (typeof CREATION_ENTRY_PROCESSES)[number];
export type CreationEntryFrame = "sheet" | "step";
export interface CreationEntry {
  process: CreationEntryProcess;
  frame: CreationEntryFrame;
  step?: CreationStepKey;
  useCase?: string;
  setup?: string;
  stack?: string;
  server?: string;
}

const ID = /^[A-Za-z0-9][A-Za-z0-9_.:-]{0,127}$/;
const SETUP = /^[a-z0-9:,-]{1,2048}$/;
const matching = (value: string | null, pattern: RegExp) =>
  value && pattern.test(value) ? value : undefined;
const stepOf = (value: unknown): CreationStepKey | undefined =>
  CREATION_STEP_KEYS.find((key) => key === value);

export function parseCreationEntry(params: {
  get(name: string): string | null;
}): CreationEntry | null {
  const process = CREATION_ENTRY_PROCESSES.find((key) => key === params.get("process"));
  if (!process) return null;
  return {
    process,
    frame: params.get("frame") === "step" ? "step" : "sheet",
    step: stepOf(params.get("step")),
    useCase: matching(params.get("use-case"), ID),
    setup: matching(params.get("setup"), SETUP),
    stack: matching(params.get("stack"), ID),
    server: matching(params.get("server"), ID),
  };
}

export function creationEntryPath(entry: CreationEntry): string {
  const params = new URLSearchParams({ process: entry.process, frame: entry.frame });
  if (entry.step) params.set("step", entry.step);
  if (entry.useCase) params.set("use-case", entry.useCase);
  if (entry.setup) params.set("setup", entry.setup);
  if (entry.stack) params.set("stack", entry.stack);
  if (entry.server) params.set("server", entry.server);
  return `${CREATION_EMBED_PATH}?${params.toString()}`;
}

export type CreationEventStep = CreationStepKey | "target";
export type CreationEvent =
  | { event: "ready" }
  | { event: "step-changed"; step: CreationEventStep; summary: string }
  | { event: "resize"; height: number }
  | { event: "submitted"; runId: string }
  | { event: "progress"; runId: string; phase: string }
  | {
      event: "completed";
      runId: string;
      stackId: string;
      outcome: "succeeded" | "failed" | "accepted";
    }
  | { event: "cancelled" }
  | { event: "open-full"; path: string };
export type CreationCommand =
  | { command: "go-to-step"; step: CreationStepKey }
  | { command: "close-request" };

export function parseCreationCommand(data: unknown): CreationCommand | null {
  if (
    !data ||
    typeof data !== "object" ||
    !("type" in data) ||
    data.type !== "creation-command" ||
    !("schema" in data) ||
    data.schema !== CREATION_EVENT_SCHEMA ||
    !("command" in data)
  )
    return null;
  if (data.command === "close-request") return { command: "close-request" };
  if (data.command !== "go-to-step" || !("step" in data)) return null;
  const step = stepOf(data.step);
  return step ? { command: "go-to-step", step } : null;
}

/** Parses wire messages only; the host must separately authorize navigation paths. */
export function parseCreationEvent(data: unknown): CreationEvent | null {
  if (
    !data ||
    typeof data !== "object" ||
    !("type" in data) ||
    data.type !== "creation-event" ||
    !("schema" in data) ||
    data.schema !== CREATION_EVENT_SCHEMA ||
    !("event" in data)
  )
    return null;
  switch (data.event) {
    case "ready":
      return { event: "ready" };
    case "cancelled":
      return { event: "cancelled" };
    case "resize":
      return "height" in data &&
        typeof data.height === "number" &&
        Number.isFinite(data.height) &&
        data.height >= 0
        ? { event: "resize", height: data.height }
        : null;
    case "submitted":
      return "runId" in data && typeof data.runId === "string"
        ? { event: "submitted", runId: data.runId }
        : null;
    case "progress":
      return "runId" in data &&
        typeof data.runId === "string" &&
        "phase" in data &&
        typeof data.phase === "string"
        ? { event: "progress", runId: data.runId, phase: data.phase }
        : null;
    case "step-changed": {
      if (!("step" in data) || !("summary" in data) || typeof data.summary !== "string")
        return null;
      const step = data.step === "target" ? "target" : stepOf(data.step);
      return step ? { event: "step-changed", step, summary: data.summary } : null;
    }
    case "completed":
      return "runId" in data &&
        typeof data.runId === "string" &&
        "stackId" in data &&
        typeof data.stackId === "string" &&
        "outcome" in data &&
        (data.outcome === "succeeded" || data.outcome === "failed" || data.outcome === "accepted")
        ? { event: "completed", runId: data.runId, stackId: data.stackId, outcome: data.outcome }
        : null;
    case "open-full":
      return "path" in data && typeof data.path === "string" && /^\/[^/\\]/.test(data.path)
        ? { event: "open-full", path: data.path }
        : null;
    default:
      return null;
  }
}
