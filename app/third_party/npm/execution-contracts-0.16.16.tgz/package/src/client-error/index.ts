import { validateSchemaDocuments } from "../schemaValidator.js";
import { clientErrorEnvelopeKeys, clientErrorSchemaDocuments } from "./schemas.generated.js";
import type { ModelAction, ModelDenial, ModelFailureCause } from "./types.generated.js";
export type { ClientErrorEnvelopeV1, ClientErrorGuidance, ClientErrorLocalization, ModelAction, ModelDenial, ModelFailureCause, ModelFailureContext } from "./types.generated.js";

export type ModelFailure =
  | { representation: "canonical"; denial: ModelDenial }
  | { representation: "legacy"; cause: ModelFailureCause; errorCode: string; reasonCode?: string; retryable?: boolean; retryAfterMS?: number | null; resetAt?: string; actions: ModelAction[] };

function record(value: unknown): value is Record<string, unknown> {
  return value !== null && typeof value === "object" && !Array.isArray(value);
}
function text(value: unknown, max = 256): string | undefined {
  return typeof value === "string" && value.length > 0 && [...value].length <= max ? value : undefined;
}
// Bound traversal before schema evaluation, including unexpected fields. The
// decoder consumes JSON-shaped data; it never executes supplied getters.
function boundedJson(value: unknown, depth = 0, count = { value: 0, characters: 0 }): boolean {
  if (++count.value > 2048 || depth > 12) return false;
  if (value === null || typeof value === "boolean") return true;
  if (typeof value === "number") return Number.isFinite(value);
  if (typeof value === "string") { count.characters += value.length; return value.length <= 16000 && count.characters <= 64000; }
  if (!record(value) && !Array.isArray(value)) return false;
  if (Array.isArray(value) && (value.length > 256 || Object.keys(value).length !== value.length)) return false;
  const keys = Object.keys(value);
  count.characters += keys.reduce((sum,key) => sum + key.length, 0);
  if (keys.some(key => key.length > 256) || count.characters > 64000) return false;
  const prototype = Object.getPrototypeOf(value);
  if (prototype !== null && prototype !== Object.prototype && prototype !== Array.prototype) return false;
  return Object.getOwnPropertySymbols(value).length === 0 && Object.values(Object.getOwnPropertyDescriptors(value)).every((descriptor) => "value" in descriptor && boundedJson(descriptor.value, depth + 1, count));
}
function schemaValid(ref: string, value: unknown): boolean {
  return validateSchemaDocuments(clientErrorSchemaDocuments, "client error", ref, value).length === 0;
}
function validModel(value: unknown): value is ModelDenial {
  if (!record(value) || (value.capability !== "ai.model-executions" && value.capability !== "ai.agent-runs")) return false;
  if (!schemaValid("client-error-envelope.v1.schema.json", value)) return false;
  if (typeof value.reset_at === "string") {
    const parts = /^(\d{4})-(\d{2})-(\d{2})T/u.exec(value.reset_at);
    if (!parts) return false;
    const calendar = new Date(`${parts[0].slice(0,10)}T00:00:00Z`);
    if (calendar.getUTCFullYear() !== Number(parts[1]) || calendar.getUTCMonth()+1 !== Number(parts[2]) || calendar.getUTCDate() !== Number(parts[3])) return false;
  }
  // JSON Schema cannot express equal positional guidance lengths.
  const guidance = record(value.user_guidance) ? value.user_guidance : undefined;
  const localization = guidance && record(guidance.localization) ? guidance.localization : undefined;
  return !!guidance && !!localization && Array.isArray(guidance.next_steps) && Array.isArray(localization.next_step_message_ids) && guidance.next_steps.length === localization.next_step_message_ids.length;
}

function aliasesAgree(value: Record<string, unknown>, denial: ModelDenial): boolean {
  const same = (actual: unknown, expected: unknown) => actual === undefined || actual === expected;
  if (!same(value.resetAt, denial.reset_at ?? "")) return false;
  if (Object.hasOwn(value, "denial")) {
    if (!same(value.code, denial.error_code) || !same(value.errorCode, denial.error_code)
      || !same(value.reasonCode, denial.reason_code) || !same(value.retryable, denial.retryable)) return false;
    if (value.userGuidance !== undefined) {
      if (!schemaValid("client-error-transport.v1.schema.json#/$defs/stream/properties/userGuidance", value.userGuidance) || !record(value.userGuidance)) return false;
      if (value.userGuidance.title !== denial.user_guidance.title || value.userGuidance.body !== denial.user_guidance.body
        || JSON.stringify(value.userGuidance.nextSteps) !== JSON.stringify(denial.user_guidance.next_steps)) return false;
    }
  } else {
    if (record(value.error) && value.error.code !== denial.error_code) return false;
    if (!same(value.reason, denial.reason_code)) return false;
  }
  if (value.topUp !== undefined && !denial.actions.some(action => action.kind === "buy_ai_boost")) return false;
  if (Array.isArray(value.alternatives)) for (const alternative of value.alternatives) {
    if (!record(alternative)) return false;
    if (Array.isArray(alternative.providerIds) && alternative.providerIds.some(id => !denial.actions.some(action => action.kind === "use_provider_key" && action.provider_id === id))) return false;
    if (Array.isArray(alternative.endpointIds) && alternative.endpointIds.some(id => !denial.actions.some(action => action.kind === "use_model_endpoint" && action.endpoint_id === id))) return false;
  }
  return true;
}

/** Decode only a complete canonical AI denial; no rights or money decision. */
export function decodeModelDenial(value: unknown): ModelDenial | undefined {
  if (!boundedJson(value)) return undefined;
  if (validModel(value)) return value;
  if (!record(value)) return undefined;
  if (Object.hasOwn(value, "denial")) return validModel(value.denial) && aliasesAgree(value, value.denial) ? value.denial : undefined;
  if (!schemaValid("client-error-transport.v1.schema.json", value)) return undefined;

  const candidate = Object.fromEntries(Object.entries(value).filter(([key]) => clientErrorEnvelopeKeys.includes(key)));
  return validModel(candidate) && aliasesAgree(value, candidate) ? candidate : undefined;
}

// Exact known running-channel codes, never an inference from HTTP status or
// English diagnostics. Remove with the Stable parser contraction evidence.
const legacyCauses: Readonly<Record<string, ModelFailureCause>> = {
  missing_authorization: "authentication", unauthorized: "authentication", token_expired: "authentication",
  agent_not_allowed: "authorization", ai_agent_not_entitled: "authorization", insufficient_scope: "authorization", agent_entitlement_denied: "authorization",
  model_not_allowed: "model_policy", model_forbidden: "model_policy", ai_model_not_available_for_tier: "model_policy", ai_model_unknown: "model_policy", model_capability_missing: "model_policy", ai_model_not_released: "model_policy",
  quota_exhausted: "funding", ai_credits_exhausted: "funding", ai_credit_reservation_denied: "funding", ai_tier_missing: "authorization",
  provider_capacity_unavailable: "capacity", model_capacity_exhausted: "capacity", platform_capacity_exhausted: "capacity",
  provider_key_invalid: "configuration", provider_key_missing: "configuration", connection_not_available: "configuration", funding_constraint_denied: "configuration", endpoint_not_found: "configuration", endpoint_model_unavailable: "configuration", endpoint_not_allowed: "authorization",
  quota_unavailable: "infrastructure", ai_credit_budget_missing: "infrastructure", upstream_unavailable: "infrastructure", origin_not_configured: "infrastructure", idempotency_uncertain: "infrastructure",
  provider_rate_limited: "provider", provider_upstream_unavailable: "provider", provider_request_rejected: "provider", endpoint_offline: "provider", endpoint_unreachable: "provider", endpoint_timeout: "provider", endpoint_busy: "capacity",
};

/** Bounded migration reader. Legacy prose/URLs never become UI guidance. */
export function decodeModelFailure(value: unknown): ModelFailure | undefined {
  const denial = decodeModelDenial(value);
  if (denial) return { representation: "canonical", denial };
  if (!boundedJson(value) || !record(value)) return undefined;
  if (value.representation === "legacy") {
    const allowed = ["representation", "cause", "errorCode", "reasonCode", "retryable", "retryAfterMS", "resetAt", "actions"];
    if (Object.keys(value).some(key => !allowed.includes(key))) return undefined;
    if (!Array.isArray(value.actions) || value.actions.length > 16 || !value.actions.every(action => schemaValid("client-error-envelope.v1.schema.json#/$defs/action", action))) return undefined;
    const wire = {
      errorCode: value.errorCode,
      ...(value.reasonCode !== undefined ? {reasonCode:value.reasonCode}:{}),
      ...(value.retryable !== undefined ? {retryable:value.retryable}:{}),
      ...(value.retryAfterMS !== undefined ? {retry_after_ms:value.retryAfterMS}:{}),
      ...(value.resetAt !== undefined ? {resetAt:value.resetAt}:{}),
    };
    const legacy = decodeModelFailure(wire);
    if (!legacy || legacy.representation !== "legacy" || legacy.cause !== value.cause) return undefined;
    if (value.reasonCode !== legacy.reasonCode || value.retryable !== legacy.retryable || value.retryAfterMS !== legacy.retryAfterMS || value.resetAt !== legacy.resetAt) return undefined;
    const actions = value.actions.filter((action): action is ModelAction => schemaValid("client-error-envelope.v1.schema.json#/$defs/action", action));
    return {...legacy, actions};
  }
  // A malformed canonical object must not be downgraded into trusted legacy.
  if (Object.hasOwn(value, "denial") || Object.hasOwn(value, "cause")) return undefined;
  const nested = record(value.error) ? value.error : {};
  const errorCode = text(value.error_code ?? value.errorCode ?? value.code ?? nested.code ?? value.error);
  const reasonCode = text(value.reason_code ?? value.reasonCode ?? value.reason);
  const cause = (reasonCode && Object.hasOwn(legacyCauses, reasonCode) ? legacyCauses[reasonCode] : undefined) ?? (errorCode && Object.hasOwn(legacyCauses, errorCode) ? legacyCauses[errorCode] : undefined);
  if (!cause || !errorCode) return undefined;
  const actions: ModelAction[] = [];
  if (cause === "authentication") actions.push({kind:"sign_in"});
  if (errorCode === "quota_exhausted" || reasonCode === "ai_credits_exhausted") actions.push({kind:"select_free_model"}, {kind:"buy_ai_boost"}, {kind:"manage_plan"});
  if (Array.isArray(value.alternatives)) for (const alternative of value.alternatives.slice(0, 2)) {
    if (!record(alternative)) continue;
    if (alternative.route === "byok" && Array.isArray(alternative.providerIds)) for (const id of alternative.providerIds) { const provider = text(id); if (provider && actions.length < 16) actions.push({kind:"use_provider_key",provider_id:provider}); }
    if (alternative.route === "endpoint" && Array.isArray(alternative.endpointIds)) for (const id of alternative.endpointIds) { const endpoint = text(id); if (endpoint && actions.length < 16) actions.push({kind:"use_model_endpoint",endpoint_id:endpoint}); }
  }
  const delay = Object.hasOwn(value, "retry_after_ms") ? value.retry_after_ms : value.retryAfterMs;
  const retryAfterMS = delay === null ? null : typeof delay === "number" && Number.isSafeInteger(delay) && delay >= 0 ? delay : undefined;
  const reset = text(value.reset_at ?? value.resetAt);
  return {representation:"legacy",cause,errorCode,...(reasonCode ? {reasonCode}:{}),...(typeof value.retryable === "boolean" ? {retryable:value.retryable}:{}),...(retryAfterMS !== undefined ? {retryAfterMS}:{}),...(reset && Number.isFinite(Date.parse(reset)) ? {resetAt:reset}:{}),actions};
}
