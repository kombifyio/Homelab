# @kombifyio/speechkit-voice-ui

Framework-neutral SpeechKit Voice UI Kit: custom elements, design tokens, and
the `speechkit.voice_ui.v1` behavior spec for voice surfaces (Voice Chat UI
Standard). No React, Svelte, or LiveKit dependency — the elements work in plain
HTML, Svelte 5, React 19, and any other host that can render custom elements.
Native surfaces (Compose) implement spec parity from the shipped
`spec/` + `src/tokens/tokens.json` + `locales/*.json` artifacts.

## Elements

| Element | Purpose |
| --- | --- |
| `<speechkit-voice-assistant>` | The standard Voice Assistant surface (Aura Orb). One element serves every frame: `size="orb"` (bare visual for hosts with their own chrome), `compact` (pill / keyboard bar / watch face), `expanded` (hero + status + teleprompter turn list). See below. |
| `<speechkit-voice-button>` | The standard split button: primary segment starts/stops Dictation; the secondary segment (`agent` attribute; chevron click or long-press) starts the Voice Agent. Without the `voice_agent` capability it renders locked and shows the denial guidance instead of disappearing. |
| `<speechkit-voice-overlay>` | Compact ephemeral glass voice-agent overlay: teleprompter turn list (drafts dimmed, finals solid), autoscroll + jump-to-live, tap-to-interrupt orb, consent gate, ended/reconnect stage, Escape exit. |
| `<speechkit-voice-visualizer>` | Orb/pill/dot audio-state indicator (`state`, `level`), honoring `prefers-reduced-motion`. |
| `<speechkit-voice-consent>` | Fail-closed voice consent gate (`one_shot` / `continuous` scopes). |
| `<speechkit-voice-provider>` | Context provider distributing one controller to a subtree. |
| `<speechkit-voice-dialog>` | Frameless, slightly translucent card that streams the voice-agent dialogue (newest turn at the bottom, top fade). `anchor="above\|below\|start\|end"` places it next to a launcher, `auto-open` shows it when a session starts; a slim bar holds the recording indicator, an end-session icon and a hide icon. |
| `<speechkit-live-transcript>` | Bounded 1–2 line streaming transcript (`lines`, `source`, `placeholder`); only final segments reach the polite live region. |
| `<speechkit-voice-pill>` | In-Composer voice pill: recording dot, level bars and the elapsed time while dictating (`mode="dictation"`), or the Voice Agent phase (`mode="voice_agent"`). Controller-driven or host-driven (`phase`, `level`, `started-at`); hides while idle; `static` or reduced motion rests the bars. |
| `<speechkit-voice-notice>` | One-line error/status chip localized by reason code, with Retry, ✕ and an on-demand details disclosure. Never shows raw codes or URLs in the default view. |

The split button carries the recording indicator: idle, requesting (microphone
prompt / session setup), listening (red dot plus level-reactive bars),
processing, speaking and error. Motion stays inside the control; under
`prefers-reduced-motion` the bars rest at fixed heights and the visible state
label keeps "being recorded" obvious. Any denial renders as a compact notice
above the button (`no-notice` opts out, e.g. when a dialog shows it).

## Voice Assistant (`<speechkit-voice-assistant>`)

The canonical Voice Assistant UI module. Attach a controller (or use the
ready-made adapter below), and the element renders the full experience:
state-coupled orb animation, status labels in 6 locales, live teleprompter
transcript, and tap-to-interrupt barge-in.

| Attribute | Values | Meaning |
| --- | --- | --- |
| `size` | `orb` \| `compact` (default) \| `expanded` | Bare visual / pill–bar–watch face / hero + transcript. |
| `frame` | `overlay` \| `keyboard` \| `watch` \| `phone` \| `panel` (default) | Host surface; `keyboard` renders the full-width inline bar, `watch` the round face. |
| `variant` | `aura` (default) \| `waveform` | Visual motif: Aura Orb or the dual-hue Glass Waveform. Everything else is identical across variants. |
| `transcript` | boolean | Off = animation/status only; compact shows at most the last sentence. |
| `mark-src` | URL | Host-provided brand image in the orb centre (the kit ships no brand asset; no mark slot in `waveform`). |
| `aura-state` | 8 orb states | Host FSM override for the orb visual. |

Semantic mark ids (`rosette \| k \| none`) live in the `./marks` subpath:

```ts
import { resolveMarkSrc, semanticMarkRatio } from "@kombifyio/speechkit-voice-ui/marks";

const src = resolveMarkSrc(settings.assistantMark, { rosette: "/rosette.png", k: "/k.png" });
element.markSrc = src; // null removes the mark (pure orb)
```

Native parity ports (Compose, LVGL) implement the `assistant` and
`assistant-variants` blocks in `tokens.json` plus the spec section — never a
re-interpretation of the visuals.

## Quick start (plain HTML)

```html
<link rel="stylesheet" href="node_modules/@kombifyio/speechkit-voice-ui/src/tokens/tokens.css" />
<script type="module">
  import "@kombifyio/speechkit-voice-ui/define";
</script>

<speechkit-voice-provider id="voice">
  <speechkit-voice-button agent for="overlay">Dictate</speechkit-voice-button>
  <speechkit-voice-overlay id="overlay"></speechkit-voice-overlay>
</speechkit-voice-provider>

<script type="module">
  // The kit is UI-only: inject a VoiceUiController (sessions/transport/audio
  // stay host-owned). Use the ready-made adapter from ./voiceagent-adapter
  // (see below) or write your own.
  document.getElementById("voice").controller = myController;
</script>
```

Framework hosts assign the `controller` property directly on each element
(React 19 and Svelte 5 both set non-primitive props as element properties).
SSR hosts must import `./define` client-side only.

## Controller boundary

The kit renders the canonical `speechkit.voice_surface.v1` event stream and
owns no session FSM, provider keys, tickets, or authorization decisions. See
`VoiceUiController` in the typed API: `start/stop/cancel/subscribe/getState`
plus optional `interrupt()` (barge-in) and `subscribeLevel()` (visualizer).

### Ready-made voice-agent adapter

For a SpeechKit server you do not need to implement that interface yourself:

```ts
import { createVoiceAgentUiController } from "@kombifyio/speechkit-voice-ui/voiceagent-adapter";

const controller = createVoiceAgentUiController({
  serverUrl: "https://speechkit.example.com",
  token: sessionToken,
  start: { provider: "deepgram", locale: "en-US" },
});
```

It owns microphone capture, the ticket WebSocket, playback with barge-in
flushing, and input/output level metering, and emits the canonical event
stream. `@kombifyio/speechkit-voiceagent-client` is an **optional peer
dependency** required only for this subpath — the main entry stays
dependency-free.

## Microphone permission and consent

Check the microphone before opening a server session, so a blocked or missing
microphone never mints a ticket:

```ts
import { checkMicrophonePermission, requestMicrophone, releaseMediaStream } from "@kombifyio/speechkit-voice-ui";

const permission = await checkMicrophonePermission(); // "granted" | "prompt" | "denied" | "unsupported"
if (permission === "denied") showNotice("microphone_permission_denied");
const mic = await requestMicrophone(); // { ok, stream } or { ok: false, reason: "microphone_*" }
// ...later: releaseMediaStream(mic.stream)
```

Consent is confirmed once and remembered: `createVoiceConsentStore` persists the
decision on the device (`localStorage`, key `speechkit.voice.consent.v1`) and
reports every user decision through `onConsentChange`, so the host can store it
in the user's account. On sign-in, seed it back with `setConsentRecord(record)`.
Raising `consentVersion` asks everyone again; `revoke()` clears it.

```ts
const consent = createVoiceConsentStore({
  surface: "web",
  consentVersion: "2026-10",
  onConsentChange: (record) => api.saveVoiceConsent(record)
});
consent.setConsentRecord(await api.loadVoiceConsent());
overlay.consentAdapter = consent; // also accepted by <speechkit-voice-consent>
```

## Theming

Every visual knob is a `--sk-*` CSS custom property (see
`src/tokens/tokens.json`, the machine-readable SSOT) and every internal
surface is exposed via `::part(...)`. Include `tokens.css` for the default
light/dark glass theme or set the properties yourself; `[data-sk-theme]`
forces a theme.

## Spec parity

`spec/voice-ui.spec.md` is the normative behavior spec;
`spec/fixtures/voice-ui-turns.v1.json` and
`spec/fixtures/speechkit-voice-surface.v1.json` are the shared replay
fixtures. Web and native implementations must produce identical outputs for
every fixture case.

## License

Apache-2.0.

## Localization adapter

`locales/*.json` is the canonical six-locale catalog source, including the
native interchange export. `pnpm run localization:compile` compiles its inlang
project with Paraglide JS 2 and generates the message-ID types. The build
checks that every compiled message preserves the source text. The public
`voiceUiMessages(locale, overrides)` API, catalog exports and per-element
locale isolation stay available; hosts need no Paraglide runtime dependency.
Build from the TypeScript workspace with
`pnpm --filter @kombifyio/speechkit-voice-ui... run build` so the optional
Voice Agent peer's declarations are current. Catalog presence alone is not
signed translation QA or a device acceptance result.
