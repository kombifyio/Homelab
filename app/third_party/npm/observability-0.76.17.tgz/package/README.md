# @kombify/observability

Sentry and PostHog wiring for kombify SaaS frontends, servers, and Cloudflare Workers.

Single source of truth per the workspace
[OBSERVABILITY-STANDARD.md](https://github.com/KombiverseLabs/kombify-workspace/blob/main/platform/standards/OBSERVABILITY-STANDARD.md) and
[OBSERVABILITY-STANDARD.md](https://github.com/KombiverseLabs/kombify-workspace/blob/main/platform/standards/OBSERVABILITY-STANDARD.md) §12. Wraps
Sentry SDKs and PostHog capture with kombify defaults (EU region, PII
scrubbing, sample rates, release tagging, consent-gated analytics).

Published as `@kombiverselabs/observability` on GitHub Packages. Private SaaS
consumers pin an explicitly reviewed release and use the workspace alias in
their `package.json`:

```json
"@kombify/observability": "npm:@kombiverselabs/observability@0.4.303"
```

Public OSS and self-hosted product trees must not consume this private package.
Upgrade the pinned release through an explicit consumer PR after the package
source and registry artifact have passed their delivery gates.

## SvelteKit (Node adapter) — private Kombify SaaS surfaces

### `src/hooks.server.ts`

```ts
import { sequence } from '@sveltejs/kit/hooks'
import { initSentryServer, sentryHandle, handleServerError } from '@kombify/observability/sveltekit/server'

initSentryServer({ service: 'kombify-cloud-portal' })

export const handle = sequence(sentryHandle)
export const handleError = handleServerError
```

### `src/hooks.client.ts`

```ts
import { initSentryClient, handleClientError } from '@kombify/observability/sveltekit/client'

initSentryClient({ service: 'kombify-cloud-portal' })

export const handleError = handleClientError
```

### Required environment variables:
- `PUBLIC_SENTRY_DSN` — **public-facing**, exposed to the browser bundle
- `SENTRY_ENVIRONMENT` — `prod`, `dev`, `preview`
- `SENTRY_RELEASE` — Git SHA (set by CI)
- `PUBLIC_POSTHOG_KEY` — PostHog project API key (`phc_...`), SaaS only
- `PUBLIC_POSTHOG_HOST` — `https://e.kombify.io`
- `KOMBIFY_EDITION` — `selfhost-oss` disables PostHog completely

Deployable services that share one environment configuration can opt into
suffixed DSNs without local wrapper code:

```ts
initSentryServer({
  service: 'kombify-cloud-portal',
  dsnEnvKeys: ['SENTRY_DSN_PORTAL', 'SENTRY_DSN'],
})

initSentryClient({
  service: 'kombify-simulate-frontend',
  dsnEnvKeys: ['PUBLIC_SENTRY_DSN'],
})
```

## Cloudflare Workers — kombify-Me, cf-edge

### `src/index.ts`

```ts
import { withSentry } from '@kombify/observability/cloudflare'

export default withSentry(
  { service: 'kombify-me' },
  {
    async fetch(req, env, ctx) {
      // your handler
    }
  }
)
```

### Wrangler bindings required:

```jsonc
// wrangler.jsonc
{
  "vars": {
    "SENTRY_ENVIRONMENT": "prod"
  }
  // SENTRY_DSN injected as a secret via wrangler secret bulk
}
```

## PostHog Product Analytics

Client-side capture is consent-gated by default:

```ts
import {
  initPostHogClient,
  grantPostHogConsent,
  identifyPostHogUser,
  capturePostHogEvent,
  resetPostHogUser,
} from '@kombify/observability/posthog/sveltekit/client'

await initPostHogClient({
  service: 'kombify-cloud-portal',
  product: 'cloud',
  surface: 'dashboard',
})

// After the cookie/CMP opt-in:
grantPostHogConsent({ replay: true })

identifyPostHogUser({
  distinctId: session.user.sub,
  organizationId: session.user.orgId,
  personProperties: { role: session.user.role, plan: session.user.plan },
})

capturePostHogEvent('auth:signup_completed', { plan: session.user.plan })

// On logout:
resetPostHogUser()
```

Server-side capture is for domain events that should not depend on a browser
session:

```ts
import {
  initPostHogServer,
  capturePostHogServerEvent,
  identifyPostHogServerOrganization,
  shutdownPostHogServer,
} from '@kombify/observability/posthog/sveltekit/server'

await initPostHogServer({
  service: 'kombify-cloud-backend',
  product: 'cloud',
  surface: 'billing-webhook',
})

capturePostHogServerEvent({
  event: 'billing:subscription_created',
  distinctId: auth0Subject,
  organizationId: auth0OrgId,
  correlationId: stripeEventId,
  properties: { plan: 'pro' },
})

identifyPostHogServerOrganization({
  organizationId: auth0OrgId,
  correlationId: stripeEventId,
  properties: {
    billing_plan: 'pro',
    billing_subscription_status: 'active',
  },
})

await shutdownPostHogServer()
```

Use `organizationId` on normal events for event-to-account grouping. Use
`identifyPostHogServerOrganization()` or
`identifyPostHogWorkerOrganization()` for durable organization properties such
as billing plan, lifecycle stage, subscription status, revenue currency, or
account health. The helper emits `$groupidentify` with `$group_type:
organization`, `$group_key`, and a scrubbed `$group_set`.

Experiment exposure capture is analytics-only. Flag delivery and entitlement
decisions stay with Flagship/OpenFeature:

```ts
import { capturePostHogWorkerExperimentExposure } from '@kombify/observability/posthog/cloudflare'

capturePostHogWorkerExperimentExposure(env, ctx, {
  service: 'kombify-gateway',
  product: 'platform',
  surface: 'worker',
}, {
  distinctId: auth0Subject,
  organizationId: auth0OrgId,
  correlationId: requestId,
  exposure: {
    flagKey: 'onboarding.v2',
    experimentKey: 'onboarding-activation-v2',
    variant: 'control',
    source: 'flagship',
  },
})
```

The helper emits `experiment:exposure_recorded` with the required
`$feature/<flag-key>` property. It does not evaluate flags and must not be used
for access decisions, entitlements, quotas, or security gates.

Worker-side capture uses `ctx.waitUntil()` and posts to the same
`PUBLIC_POSTHOG_HOST` proxy. Custom events must follow
`<domain>:<object>_<past_action>`; reserved PostHog events like
`$ai_generation` are allowed. Email, name, prompt, input, output, cookies, and
auth headers are scrubbed by the shared helpers until the CRM amendment lands.

## Defaults enforced

From `OBSERVABILITY-STANDARD.md` §6 + §9:

| Setting | Prod | Dev |
|---|---|---|
| `sendDefaultPii` | false | false |
| `tracesSampleRate` | 0.1 | 1.0 |
| `replaysSessionSampleRate` | 0.0 | 0.0 |
| `replaysOnErrorSampleRate` | 0.0 | 0.0 |
| Sentry Session Replay | disabled | disabled |
| Query strings on breadcrumbs | **stripped** | stripped |
| PostHog `capture_exceptions` | false | false |
| PostHog Session Replay | consent-gated, masked | consent-gated, masked |

All configurable via `Config` overrides but only when there is a good reason
documented in the PR description.

## Why a shared package?

Copy-paste Sentry init across ten services would drift — one service forgets
PII masking, another forgets the release tag, another uses a different region
and breaks DSGVO. This package owns the init so every service gets identical,
audited behavior.

## Error budget (Sentry volume)

Sentry errors must stay proportional to affected users: one failure reports at
most once per subject (`user.id`, else tag `tenant_id` / `organization_id` /
`org_id`, else `system`) per hour. Repeats are counted and attached to the next
report as tag and extra `error_budget.suppressed`
(`error_budget.suppressed_since_last` in extra); more than 100 distinct subjects
per fingerprint per hour are dropped and counted in `error_budget.more_subjects`.
Transactions pass through. The package's own `withSentry`, `initSentryServer`
and `initSentryClient` already apply it. Code that calls `@sentry/*` directly
uses the SDK-agnostic entry point (no `@sentry/*` import, any SDK major):

```ts
import { errorBudget } from '@kombify/observability/error-budget'

Sentry.init({ dsn, beforeSend: errorBudget({}, existingBeforeSend) }) // @sentry/cloudflare
Sentry.init({ dsn, beforeSend: errorBudget() })                       // @sentry/sveltekit
Sentry.init({ dsn, beforeSend: errorBudget() })                       // @sentry/react
```

Options: `windowMs` (3_600_000), `maxKeys` (4096), `perFingerprintPerWindow`
(100), `now`. The fingerprint is the explicit `fingerprint` (unless
`{{ default }}`), else last exception type, normalized value (UUIDs, 12+ hex
runs and digits become `#`, 200 characters max) and last in-app frame.
