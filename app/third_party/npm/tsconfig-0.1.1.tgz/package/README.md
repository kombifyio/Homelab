# @kombify/tsconfig

The TypeScript compiler baseline of every kombify JS/TS surface
(`DEVELOPMENT-ENVIRONMENT-STANDARD.md` §3). Published as
`@kombiverselabs/tsconfig`; consumers alias it and vendor the tarball like the
other private packages:

```json
"devDependencies": { "@kombify/tsconfig": "npm:@kombiverselabs/tsconfig@0.1.0" }
```

| File | Content |
| --- | --- |
| `base.json` | `strict`, `noUncheckedIndexedAccess`, `noImplicitOverride`, `noFallthroughCasesInSwitch`, `isolatedModules`. Required. |
| `exact.json` | `base.json` plus `exactOptionalPropertyTypes`. Opt-in per package. |

The preset sets only checks, never `module`, `target` or paths, so it stacks
on any project config. Put it last so its checks win:

```json
{ "extends": ["./.svelte-kit/tsconfig.json", "@kombify/tsconfig/base.json"] }
```

`mise run toolchain:audit` reads the required flags from
`toolchainBaseline.tsconfig` in `internal/standards-enforcement/repo-manifest.json`
and checks each tracked `tsconfig*.json` through its `extends` chain.
Publication: `toolchain-preset-package.yml` from merged `main`.
