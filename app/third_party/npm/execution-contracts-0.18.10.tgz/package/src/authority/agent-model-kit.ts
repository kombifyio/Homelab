/**
 * Shared, internal building blocks of the agent model mappers: the catalog
 * envelope, the closed-object and list helpers, and the localized text shape.
 * Used by `agent-model.ts` (type, role v3, binding, Office v1) and
 * `area-model.ts` (area index, role v4, Factory profile, Office v2, position,
 * role template v3). Not exported from the `authority` entry: the mappers are
 * the public surface, these are how they fail closed.
 *
 * Pure: no runtime import, so clients bundle only what they use.
 */

import type { AgentRoleTemplateV2 } from "./types.js";

export type AgentRoleTemplateLifecycleV1 = AgentRoleTemplateV2["lifecycle"];
export type SupplyDockTrustClassV1 = AgentRoleTemplateV2["trustClass"];
export type CreatableAgentTypeV1 = AgentRoleTemplateV2["agentType"];

export interface AgentModelPublisherV1 {
  name: string;
  firstParty: boolean;
}

/** Customer text: English and German always, the further product languages when published. */
export interface LocalizedTextV1 {
  en: string;
  de: string;
  es?: string;
  "zh-Hans"?: string;
  hi?: string;
  ar?: string;
  fr?: string;
}

export const OPTIONAL_TEXT_LOCALES = ["es", "zh-Hans", "hi", "ar", "fr"] as const;

/** Catalog envelope shared with `AgentRoleTemplateV2`. */
export interface AgentModelCatalogEnvelopeV1<SchemaVersion extends string> {
  schemaVersion: SchemaVersion;
  id: string;
  version: string;
  /** `sha256:<64 hex>`, domain-separated, over the record without digest, lifecycle and trust class. */
  digest: string;
  lifecycle: AgentRoleTemplateLifecycleV1;
  trustClass: SupplyDockTrustClassV1;
  publisher: AgentModelPublisherV1;
}

export const CREATABLE_TYPES: readonly CreatableAgentTypeV1[] = ["permanent", "expert", "ad-hoc"];

export const LIFECYCLES: ReadonlySet<string> = new Set(["draft", "preview", "active", "revoked"]);
export const TRUST_CLASSES: ReadonlySet<string> = new Set([
  "catalog-verified",
  "broker-listed",
  "user-attached",
]);
export const DIGEST = /^sha256:[0-9a-f]{64}$/;

export function invalid(shape: string, reason: string): never {
  throw new TypeError(`${shape} is invalid: ${reason}`);
}

export function record(value: unknown): Record<string, unknown> | undefined {
  return value && typeof value === "object" && !Array.isArray(value)
    ? (value as Record<string, unknown>)
    : undefined;
}

/**
 * An object with no field outside `allowed`. The Core schemas are closed
 * (`additionalProperties: false`) and §4.2b rejects unknown fields before
 * hashing, so a field this build cannot name fails the document.
 */
export function closed(
  value: unknown,
  shape: string,
  path: string,
  allowed: readonly string[],
): Record<string, unknown> {
  const item = record(value);
  if (!item) invalid(shape, `${path} must be an object`);
  const unknown = Object.keys(item).find((key) => !allowed.includes(key));
  if (unknown !== undefined) invalid(shape, `${path} has unknown field ${unknown}`);
  return item;
}

export function text(value: unknown): string | undefined {
  return typeof value === "string" && value.trim() !== "" ? value : undefined;
}

export function integer(value: unknown, minimum: number): number | undefined {
  return typeof value === "number" && Number.isSafeInteger(value) && value >= minimum
    ? value
    : undefined;
}

export function oneOf<T extends string>(value: unknown, members: readonly T[]): T | undefined {
  return typeof value === "string" && (members as readonly string[]).includes(value)
    ? (value as T)
    : undefined;
}

/** A duplicate-free array of `members`, or of non-empty strings when `members` is absent. */
export function uniqueList<T extends string>(
  value: unknown,
  shape: string,
  path: string,
  options: { members?: readonly T[]; minItems?: number; pattern?: RegExp } = {},
): T[] {
  if (!Array.isArray(value)) invalid(shape, `${path} must be an array`);
  if (value.length < (options.minItems ?? 0)) invalid(shape, `${path} is too short`);
  const out: T[] = [];
  for (const entry of value) {
    const member = options.members ? oneOf(entry, options.members) : (text(entry) as T | undefined);
    if (member === undefined || (options.pattern && !options.pattern.test(member))) {
      invalid(shape, `${path} has an invalid member`);
    }
    if (out.includes(member)) invalid(shape, `${path} repeats ${member}`);
    out.push(member);
  }
  return out;
}

export function localized(value: unknown, shape: string, path: string): LocalizedTextV1 {
  const item = closed(value, shape, path, ["en", "de", ...OPTIONAL_TEXT_LOCALES]);
  const en = text(item.en);
  const de = text(item.de);
  if (!en || !de) invalid(shape, `${path} needs en and de`);
  const out: LocalizedTextV1 = { en, de };
  for (const locale of OPTIONAL_TEXT_LOCALES) {
    if (item[locale] === undefined) continue;
    const entry = text(item[locale]);
    if (!entry) invalid(shape, `${path}.${locale} must be non-empty text`);
    out[locale] = entry;
  }
  return out;
}

export const ENVELOPE_FIELDS = [
  "schemaVersion",
  "id",
  "version",
  "digest",
  "lifecycle",
  "trustClass",
  "publisher",
] as const;

export function envelope<SchemaVersion extends string>(
  raw: unknown,
  schemaVersion: SchemaVersion,
  shape: string,
  bodyFields: readonly string[],
): { item: Record<string, unknown>; head: AgentModelCatalogEnvelopeV1<SchemaVersion> } {
  const item = closed(raw, shape, "document", [...ENVELOPE_FIELDS, ...bodyFields]);
  if (item.schemaVersion !== schemaVersion) invalid(shape, "schemaVersion");
  const id = text(item.id);
  const version = text(item.version);
  const digest = text(item.digest);
  const lifecycle = text(item.lifecycle);
  const trustClass = text(item.trustClass);
  const publisher = closed(item.publisher, shape, "publisher", ["name", "firstParty"]);
  const publisherName = text(publisher.name);
  const firstParty = publisher.firstParty;
  if (!id) invalid(shape, "id");
  if (!version) invalid(shape, "version");
  if (!digest || !DIGEST.test(digest)) invalid(shape, "digest");
  if (!lifecycle || !LIFECYCLES.has(lifecycle)) invalid(shape, "lifecycle");
  if (!trustClass || !TRUST_CLASSES.has(trustClass)) invalid(shape, "trustClass");
  if (!publisherName || typeof firstParty !== "boolean") invalid(shape, "publisher");
  return {
    item,
    head: {
      schemaVersion,
      id,
      version,
      digest,
      lifecycle: lifecycle as AgentRoleTemplateLifecycleV1,
      trustClass: trustClass as SupplyDockTrustClassV1,
      publisher: { name: publisherName, firstParty },
    },
  };
}
