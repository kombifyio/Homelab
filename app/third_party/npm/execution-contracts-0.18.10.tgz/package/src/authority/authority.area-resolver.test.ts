import { describe, expect, it } from "vitest";

import {
  resolveAreaAuthority,
  type AreaCatalogDefinitionV1,
  type AreaCatalogV1,
  type AgentPositionV1,
  type AgentRoleTemplateV3,
} from "./index.js";
import {
  areaModelCatalog,
  composeFirstPartyRoleTemplateV3,
} from "./agent-model-catalog/area-model.js";

import snapshot from "./test-fixtures/area-catalog.snapshot.json";

// A reduced, fixed copy of the Gateway catalogue (`kombify-mcp.manifest.json`, branch
// `claude/catalogue-areas`): `{areas, definitions[{id, area, actionClass, lifecycle}]}`.
// Tests never read the Gateway. `humanReason` does not exist in the Gateway catalogue
// yet (design §6); the cases that need it add it to a copy, on the definitions the
// design names.
const catalog = snapshot as unknown as AreaCatalogV1;
const definition = (id: string) => catalog.definitions.find((entry) => entry.id === id)!;
const withHumanReason = (ids: readonly string[], reason = "account"): AreaCatalogV1 => ({
  ...catalog,
  definitions: catalog.definitions.map((entry) =>
    ids.includes(entry.id) ? { ...entry, humanReason: reason } : entry,
  ),
});
const HUMAN = [
  "paperwork.mail.delete",
  "homelab.estate.destroy",
  "cloud.privacy.erase",
  "paperwork.account.erase",
];
const gated = withHumanReason(HUMAN);

const model = areaModelCatalog();
const mail = (roleId: string) =>
  composeFirstPartyRoleTemplateV3(roleId, "paperwork", "mail", "permanent");
const position = (id: string): AgentPositionV1 => model.positions.find((entry) => entry.id === id)!;
const sorted = (list: readonly string[]) => [...list].sort();
const paperworkReads = sorted(
  catalog.definitions
    .filter((entry) => entry.lifecycle === "active" && entry.actionClass === "read")
    .filter((entry) => entry.area.startsWith("paperwork.") || entry.area === "baseline.knowledge")
    .map((entry) => entry.id),
);

describe("the snapshot is a catalogue the resolver can read", () => {
  it("has areas and definitions in the shape the Gateway will pass", () => {
    expect(catalog.areas.length).toBe(68);
    expect(catalog.definitions.length).toBe(171);
    // Every area of the catalogue is in the bundled area index and the other way round.
    expect(sorted(catalog.areas.map((area) => area.id))).toEqual(
      sorted(model.areaIndex.areas.map((area) => area.id)),
    );
  });
});

describe("resolveAreaAuthority for a template", () => {
  it("lets a Mail Specialist send, delete mail and read meetings, but not write meetings", () => {
    const specialist = resolveAreaAuthority(mail("specialist"), catalog);
    expect(specialist.use).toContain("paperwork.mail.send");
    expect(specialist.use).toContain("paperwork.mail.delete");
    expect(specialist.use).toContain("paperwork.meetings.read");
    expect(specialist.use).not.toContain("paperwork.meetings.write");
    expect(specialist.use).not.toContain("paperwork.meetings.delete");
    // The neighbouring areas of the Mail Office are written too.
    expect(specialist.use).toContain("paperwork.documents.write");
    expect(specialist.use).toContain("paperwork.lists.write");
    expect(specialist.use).toContain("paperwork.tags.write");
    expect(specialist.use).toContain("paperwork.automations.write");
    // Notes and setup are only present.
    expect(specialist.use).toContain("paperwork.notes.read");
    expect(specialist.use).not.toContain("paperwork.notes.write");
    expect(specialist.use).not.toContain("paperwork.integrations.configure");
    expect(specialist.classify("paperwork.mail.send")).toBe("standard");
    expect(specialist.classify("paperwork.meetings.read")).toBe("standard");
    expect(specialist.classify("paperwork.meetings.write")).toBe("none");
    expect(specialist.handOn).toEqual([]);
    expect(specialist.answer).toEqual([]);
  });

  it("lets a Drafter draft and organise but neither send nor delete", () => {
    const drafter = resolveAreaAuthority(mail("drafter"), catalog);
    for (const id of ["paperwork.mail.draft", "paperwork.mail.organize", "paperwork.mail.read"]) {
      expect(drafter.use).toContain(id);
      expect(drafter.classify(id)).toBe("standard");
    }
    for (const id of [
      "paperwork.mail.send",
      "paperwork.mail.delete",
      "paperwork.documents.delete",
    ]) {
      expect(drafter.use).not.toContain(id);
      expect(drafter.classify(id)).toBe("none");
    }
    // Only read and reversible_write survive, in every active area.
    const classes = new Set(drafter.use.map((id) => definition(id).actionClass));
    expect(classes).toEqual(new Set(["read", "reversible_write"]));
    // A drafter keeps what a specialist loses to the class filter, never the other way round.
    const specialist = resolveAreaAuthority(mail("specialist"), catalog).use;
    expect(drafter.use.every((id) => specialist.includes(id))).toBe(true);
  });

  it("lets a Researcher read and nothing else", () => {
    const researcher = resolveAreaAuthority(mail("researcher"), catalog);
    // Exactly the active read definitions of the Paperwork Factory's areas and the baseline.
    expect(researcher.use).toEqual(paperworkReads);
    expect(researcher.use.every((id) => definition(id).actionClass === "read")).toBe(true);
    expect(researcher.use).toContain("paperwork.meetings.read");
    expect(researcher.use).toContain("knowledge.platform.read");
    expect(researcher.classify("paperwork.mail.draft")).toBe("none");
    expect(researcher.handOn).toEqual([]);
  });

  it("hands on what a Manager uses, holds and the tools, never a definition a person must be asked about", () => {
    const manager = mail("manager");
    const held = ["homelab.inventory.read", "paperwork.notes.write", "no.such.definition"];
    const plain = resolveAreaAuthority(manager, catalog, held);
    const toolIds = catalog.definitions
      .filter((entry) => entry.area.startsWith("tool."))
      .filter((entry) => entry.lifecycle === "active")
      .map((entry) => entry.id);
    // handOn is exactly use ∪ held ∪ tools: an unknown definition is dropped, a held one stays.
    expect(plain.handOn).toEqual(
      sorted([...plain.use, "homelab.inventory.read", "paperwork.notes.write", ...toolIds]),
    );
    expect(plain.handOn).toContain("web.search.read");
    expect(plain.handOn).toContain("paperwork.mail.delete");
    expect(plain.answer).toEqual(plain.handOn);
    // `held` is beyond the standard: it never widens `use`.
    expect(plain.use).not.toContain("homelab.inventory.read");
    expect(plain.classify("homelab.inventory.read")).toBe("none");

    // With the definitions the design gates behind a person, `use` keeps them, nobody hands them on.
    const asked = resolveAreaAuthority(manager, gated, [...held, "homelab.estate.destroy"]);
    expect(asked.use).toContain("paperwork.mail.delete");
    expect(asked.handOn).not.toContain("paperwork.mail.delete");
    expect(asked.handOn).not.toContain("homelab.estate.destroy");
    expect(asked.answer).not.toContain("paperwork.mail.delete");
    expect(asked.handOn).toContain("paperwork.mail.send");
    expect(asked.handOn.length).toBe(plain.handOn.length - 1);
  });

  it("classifies a tool-area definition as `tool` for every Office agent", () => {
    for (const roleId of ["researcher", "drafter", "specialist", "manager"]) {
      const resolved = resolveAreaAuthority(mail(roleId), catalog);
      expect(resolved.classify("web.search.read")).toBe("tool");
      expect(resolved.classify("github.repository.read")).toBe("tool");
      expect(resolved.use).not.toContain("web.search.read");
    }
    // Another Office's writes, the Companion's areas and staff areas are none.
    const specialist = resolveAreaAuthority(mail("specialist"), catalog);
    expect(specialist.classify("homelab.inventory.operate")).toBe("none");
    expect(specialist.classify("cloud.settings.write")).toBe("none");
    expect(specialist.classify("staff.cmo.read")).toBe("none");
    expect(specialist.classify("unknown.definition")).toBe("none");
  });

  it("follows the Office of the template, not the Factory alone", () => {
    const meetings = resolveAreaAuthority(
      composeFirstPartyRoleTemplateV3("specialist", "paperwork", "meetings", "permanent"),
      catalog,
    );
    expect(meetings.use).toContain("paperwork.meetings.write");
    expect(meetings.use).toContain("paperwork.lists.write");
    expect(meetings.use).not.toContain("paperwork.mail.send");
    expect(meetings.use).toContain("paperwork.mail.read");
    const server = resolveAreaAuthority(
      composeFirstPartyRoleTemplateV3("specialist", "ril-ops", "server", "permanent"),
      catalog,
    );
    expect(server.use).toContain("homelab.inventory.operate");
    // Destroying the whole estate is a Factory area the server Office is not active in.
    expect(server.use).not.toContain("homelab.estate.destroy");
    expect(server.use).toContain("homelab.inventory.read");
  });
});

describe("resolveAreaAuthority for a position", () => {
  it("lets the Paperwork coordinator read and hand on the whole Factory", () => {
    const coordinator = resolveAreaAuthority(position("coordinator.paperwork"), gated);
    expect(coordinator.use).toEqual(paperworkReads);
    expect(coordinator.use.every((id) => definition(id).actionClass === "read")).toBe(true);
    expect(coordinator.use).toContain("paperwork.mail.read");
    expect(coordinator.use).not.toContain("homelab.inventory.read");
    // It hands on and answers every definition of the Factory's areas plus tools.
    const factoryIds = gated.definitions
      .filter((entry) => entry.lifecycle === "active")
      .filter((entry) => entry.area.startsWith("paperwork.") || entry.area.startsWith("tool."))
      .filter((entry) => entry.humanReason === undefined)
      .map((entry) => entry.id);
    expect(coordinator.handOn).toEqual(sorted(factoryIds));
    expect(coordinator.answer).toEqual(coordinator.handOn);
    expect(coordinator.handOn).toContain("paperwork.mail.send");
    expect(coordinator.handOn).toContain("paperwork.integrations.configure");
    expect(coordinator.handOn).not.toContain("paperwork.mail.delete");
    expect(coordinator.handOn).not.toContain("paperwork.account.erase");
    expect(coordinator.handOn).not.toContain("homelab.inventory.write");
    // It executes nothing and gives itself nothing.
    expect(coordinator.classify("paperwork.mail.send")).toBe("none");
    expect(coordinator.classify("web.search.read")).toBe("none");
    expect(coordinator.classify("paperwork.mail.read")).toBe("standard");
  });

  it("lets the Companion use its own areas and connected providers, and give itself Office rights", () => {
    const context = { connectedProviders: ["exa", "github"], personReach: "all" as const };
    const companion = resolveAreaAuthority(position("companion"), catalog, [], context);
    // Reads everywhere except staff.
    expect(companion.use).toContain("paperwork.mail.read");
    expect(companion.use).toContain("homelab.inventory.read");
    expect(companion.use).not.toContain("staff.cmo.read");
    expect(companion.use).not.toContain("web.search.read");
    // Everything of a companion area, writes included.
    expect(companion.use).toContain("cloud.settings.write");
    expect(companion.use).toContain("cloud.privacy.erase");
    expect(companion.classify("cloud.settings.write")).toBe("standard");
    // A Paperwork write is an Office right it gives itself, recorded.
    expect(companion.classify("paperwork.mail.send")).toBe("office-right");
    expect(companion.classify("homelab.inventory.operate")).toBe("office-right");
    expect(companion.classify("paperwork.mail.read")).toBe("standard");
    // A connected provider is standard use, an unconnected one is nothing.
    expect(companion.classify("direct.exa.read")).toBe("standard");
    expect(companion.classify("github.repository.read")).toBe("standard");
    expect(companion.classify("direct.tavily.read")).toBe("none");
    expect(companion.use).not.toContain("direct.tavily.read");
    // A staff definition is out of reach, a tool outside an area is switched on and recorded.
    expect(companion.classify("staff.cmo.write")).toBe("none");
    expect(companion.classify("web.search.read")).toBe("tool");
    expect(companion.classify("unknown.definition")).toBe("none");
  });

  it("bounds what the Companion hands on and answers by the person's reach, and by nothing it was not given", () => {
    const reachable = [
      "paperwork.mail.send",
      "paperwork.mail.read",
      "paperwork.mail.delete",
      "staff.cmo.read",
    ];
    const bounded = resolveAreaAuthority(position("companion"), gated, [], {
      personReach: reachable,
    });
    // Staff is never in the person's reach; a definition a person must be asked about is never handed on.
    expect(bounded.handOn).toEqual(["paperwork.mail.read", "paperwork.mail.send"]);
    expect(bounded.answer).toEqual(bounded.handOn);
    expect(bounded.classify("paperwork.mail.send")).toBe("office-right");
    expect(bounded.classify("paperwork.documents.write")).toBe("none");
    // No reach given is no reach: closed, not ambient.
    const unknownReach = resolveAreaAuthority(position("companion"), catalog);
    expect(unknownReach.handOn).toEqual([]);
    expect(unknownReach.answer).toEqual([]);
    expect(unknownReach.classify("paperwork.mail.send")).toBe("none");
    expect(unknownReach.use.length).toBeGreaterThan(0);
    // No connected providers is none connected.
    expect(unknownReach.classify("direct.exa.read")).toBe("none");
  });

  it("gives the support levels and the person-staffed fallback nothing", () => {
    for (const id of ["support.l1", "support.l2", "support.l3"]) {
      const resolved = resolveAreaAuthority(position(id), catalog, [], {
        connectedProviders: ["exa"],
        personReach: "all",
      });
      expect(resolved.use).toEqual([]);
      expect(resolved.handOn).toEqual([]);
      expect(resolved.answer).toEqual([]);
      expect(resolved.classify("paperwork.mail.read")).toBe("none");
    }
  });
});

describe("what no result ever holds", () => {
  const subjects: { name: string; subject: AgentRoleTemplateV3 | AgentPositionV1 }[] = [
    ...["researcher", "drafter", "specialist", "manager"].map((roleId) => ({
      name: `mail ${roleId}`,
      subject: mail(roleId),
    })),
    { name: "coordinator.paperwork", subject: position("coordinator.paperwork") },
    { name: "coordinator.ril-ops", subject: position("coordinator.ril-ops") },
    { name: "companion", subject: position("companion") },
  ];
  const everything = catalog.definitions.map((entry) => entry.id);
  const everyDestructiveGated = withHumanReason(
    catalog.definitions
      .filter(
        (entry) => entry.actionClass === "destructive" || entry.actionClass === "cost_bearing",
      )
      .map((entry) => entry.id),
    "whole-infrastructure",
  );
  const context = { connectedProviders: ["exa", "tavily", "github"], personReach: "all" as const };

  it("never hands on or answers a definition with a humanReason", () => {
    for (const { name, subject } of subjects) {
      const resolved = resolveAreaAuthority(subject, everyDestructiveGated, everything, context);
      const asked = new Set(
        everyDestructiveGated.definitions
          .filter((entry) => entry.humanReason)
          .map((entry) => entry.id),
      );
      expect(
        resolved.handOn.filter((id) => asked.has(id)),
        name,
      ).toEqual([]);
      expect(
        resolved.answer.filter((id) => asked.has(id)),
        name,
      ).toEqual([]);
    }
  });

  it("never holds a definition that is not active, or one in an unknown area", () => {
    const retired: AreaCatalogDefinitionV1[] = [
      {
        id: "paperwork.mail.legacy",
        area: "paperwork.mail",
        actionClass: "read",
        lifecycle: "retired",
      },
      {
        id: "paperwork.mail.beta",
        area: "paperwork.mail",
        actionClass: "read",
        lifecycle: "preview",
      },
      { id: "orphan.read", area: "nowhere.at-all", actionClass: "read", lifecycle: "active" },
    ];
    const withRetired: AreaCatalogV1 = {
      ...catalog,
      definitions: [...catalog.definitions, ...retired],
    };
    for (const { name, subject } of subjects) {
      const resolved = resolveAreaAuthority(
        subject,
        withRetired,
        retired.map((entry) => entry.id),
        context,
      );
      for (const entry of retired) {
        expect(resolved.use, name).not.toContain(entry.id);
        expect(resolved.handOn, name).not.toContain(entry.id);
        expect(resolved.answer, name).not.toContain(entry.id);
        expect(resolved.classify(entry.id), name).toBe("none");
      }
    }
    // The snapshot's own preview definitions (`paperwork.tasks.read`) follow the same rule.
    expect(resolveAreaAuthority(mail("manager"), catalog).use).not.toContain(
      "paperwork.tasks.read",
    );
    expect(resolveAreaAuthority(mail("manager"), catalog).classify("paperwork.tasks.read")).toBe(
      "none",
    );
  });

  it("is independent of input order and the same on every call", () => {
    for (const { name, subject } of subjects) {
      const first = resolveAreaAuthority(
        subject,
        catalog,
        ["web.search.read", "homelab.inventory.read"],
        context,
      );
      const reversed: AreaCatalogV1 = {
        areas: [...catalog.areas].reverse(),
        definitions: [...catalog.definitions].reverse(),
      };
      const second = resolveAreaAuthority(
        subject,
        reversed,
        ["homelab.inventory.read", "web.search.read"],
        {
          connectedProviders: [...context.connectedProviders].reverse(),
          personReach: "all",
        },
      );
      expect(second.use, name).toEqual(first.use);
      expect(second.handOn, name).toEqual(first.handOn);
      expect(second.answer, name).toEqual(first.answer);
      for (const list of [first.use, first.handOn, first.answer]) {
        expect(list, name).toEqual(sorted(list));
        expect(new Set(list).size, name).toBe(list.length);
      }
      for (const id of everything.slice(0, 40))
        expect(second.classify(id), name).toBe(first.classify(id));
    }
  });

  it("refuses a catalogue that declares a definition twice", () => {
    const twice: AreaCatalogV1 = {
      ...catalog,
      definitions: [...catalog.definitions, { ...definition("paperwork.mail.read") }],
    };
    expect(() => resolveAreaAuthority(mail("manager"), twice)).toThrow(/twice/);
  });
});
