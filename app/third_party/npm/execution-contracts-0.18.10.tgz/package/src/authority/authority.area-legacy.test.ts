import { describe, expect, it } from "vitest";

import { parseAgentRoleTemplateV2 } from "./index.js";
import {
  FROZEN_ROLE_PROJECTIONS_SCHEMA,
  findLegacyRoleProjection,
  legacyRoleProjectionVersionForDigest,
  legacyRoleProjections,
  verifyFrozenRoleProjectionsV2,
} from "./agent-model-catalog/legacy/index.js";
import frozenTable from "./agent-model-catalog/legacy/role-projections.v2.json";

// `scripts/freeze-role-projections.mjs` froze every v2 role projection that resolved on main:
// 12 role records (4 roles at 1.1.0, 1.2.0 and the current 1.3.0) x 8 Offices x 3 agent types = 288,
// and the 12 role records x the Homelab server Office as it was before the Techstack to Homelab
// rename (its binding and Office digests moved with the rename) x 3 agent types = 36 more.
const RESOLVED_ON_MAIN = 288;
const PRE_RENAME_HOMELAB = 36;
const FROZEN_ON_MAIN = RESOLVED_ON_MAIN + PRE_RENAME_HOMELAB;

describe("the frozen legacy role projections", () => {
  const table = legacyRoleProjections();

  it("holds exactly what the freeze script found on main", () => {
    expect(table.count).toBe(FROZEN_ON_MAIN);
    expect(table.projections).toHaveLength(FROZEN_ON_MAIN);
    expect(frozenTable.schema).toBe(FROZEN_ROLE_PROJECTIONS_SCHEMA);
    expect(table.source.commit).toMatch(/^[0-9a-f]{40}$/);
    const roleVersions = new Set(table.projections.map((entry) => entry.version.split("+")[0]));
    expect([...roleVersions].sort()).toEqual(["1.1.0", "1.2.0", "1.3.0"]);
    const homelab = table.projections.filter((entry) => entry.id.includes(".ril-ops.server."));
    // Per role record and type: the Office as it is now and as it was before the rename.
    expect(homelab).toHaveLength(12 * 3 * 2);
    expect(table.projections.length - homelab.length).toBe(RESOLVED_ON_MAIN - 12 * 3);
  });

  it("parses every entry with the v2 parser and matches its digest", () => {
    for (const entry of table.projections) {
      // The loader parsed it already; do it again here from the raw document.
      const reparsed = parseAgentRoleTemplateV2(JSON.parse(JSON.stringify(entry.document)));
      expect(reparsed.digest, `${entry.id}@${entry.version}`).toBe(entry.digest);
      expect(reparsed.id).toBe(entry.id);
      expect(reparsed.version).toBe(entry.version);
      expect(entry.version).toMatch(/^\d+\.\d+\.\d+\+pins\.[0-9a-f]{64}$/);
    }
  });

  it("answers a pin by exact id and version, or by digest, and nothing else", () => {
    const entry = table.projections.find(
      (candidate) => candidate.id === "role.manager.paperwork.mail.permanent",
    )!;
    expect(findLegacyRoleProjection(entry.id, entry.version)?.digest).toBe(entry.digest);
    expect(legacyRoleProjectionVersionForDigest(entry.id, entry.digest)).toBe(entry.version);
    expect(findLegacyRoleProjection(entry.id, "9.9.9+pins.none")).toBeUndefined();
    expect(
      findLegacyRoleProjection("role.manager.paperwork.nowhere.permanent", entry.version),
    ).toBeUndefined();
    expect(
      legacyRoleProjectionVersionForDigest(entry.id, `sha256:${"0".repeat(64)}`),
    ).toBeUndefined();
    // Three versions of each role resolve in each Office: the current one and two superseded.
    const versionsOfOne = table.projections.filter((candidate) => candidate.id === entry.id);
    expect(versionsOfOne).toHaveLength(3);
  });

  it("is the class projection: definition lists, no areas", () => {
    const document = findLegacyRoleProjection(
      "role.specialist.paperwork.mail.permanent",
      table.projections.find((entry) => entry.id === "role.specialist.paperwork.mail.permanent")!
        .version,
    )!;
    expect(document.schemaVersion).toBe("kombify.agent-role-template.v2");
    expect(document.authorityDefaults.use.length).toBeGreaterThan(0);
    expect(JSON.stringify(document)).not.toContain('"authority":');
  });

  it("refuses a table that lies about itself", () => {
    const tampered = structuredClone(frozenTable) as typeof frozenTable;
    (tampered.projections[0]!.document as { description: string }).description += "!";
    expect(() => verifyFrozenRoleProjectionsV2(tampered)).toThrow(/Frozen role projection/);
    const wrongCount = { ...structuredClone(frozenTable), count: FROZEN_ON_MAIN + 1 };
    expect(() => verifyFrozenRoleProjectionsV2(wrongCount)).toThrow(/count/);
    const twice = structuredClone(frozenTable) as typeof frozenTable;
    twice.projections[1] = twice.projections[0]!;
    expect(() => verifyFrozenRoleProjectionsV2(twice)).toThrow(/twice|out of order/);
    expect(() =>
      verifyFrozenRoleProjectionsV2({ ...structuredClone(frozenTable), schema: "x" }),
    ).toThrow(/schema/);
  });
});
