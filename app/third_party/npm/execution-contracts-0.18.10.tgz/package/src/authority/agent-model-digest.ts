/**
 * Digests of the agent model catalog shapes (type profile, role, Factory
 * binding, Office profile, connector catalog) and of the area model records
 * (area index, role v4, Factory profile, Office profile v2, position, role
 * template v3). Same construction as the v2 role-template digest:
 * SHA-256 over `<domain>\n<canonical JSON>\n` of the authored projection,
 * which drops the self-referential digest and the registry-owned lifecycle
 * and trust class. The domain strings match the `platform/` standard §4.2b.
 */

import { AuthorityContractError, canonicalAuthorityDigestV2 } from "./contract.js";
import type { AuthorityDigestV2 } from "./types.js";

const DOMAIN_BY_SCHEMA_VERSION = {
  "kombify.agent-type-profile.v1": "kombify.agent-type-profile.digest.v1",
  "kombify.agent-role.v3": "kombify.agent-role.digest.v3",
  "kombify.factory-role-binding.v1": "kombify.factory-role-binding.digest.v1",
  "kombify.office-profile.v1": "kombify.office-profile.digest.v1",
  "kombify.agent-connector-catalog.v1": "kombify.agent-connector-catalog.digest.v1",
  // The area model (D-2026-11-20-06), beside the class model above.
  "kombify.agent-area-index.v1": "kombify.agent-area-index.digest.v1",
  "kombify.agent-role.v4": "kombify.agent-role.digest.v4",
  "kombify.factory-profile.v1": "kombify.factory-profile.digest.v1",
  "kombify.office-profile.v2": "kombify.office-profile.digest.v2",
  "kombify.agent-position.v1": "kombify.agent-position.digest.v1",
  "kombify.agent-role-template.v3": "kombify.agent-role-template.digest.v3",
} as const;

export type AgentModelSchemaVersionV1 = keyof typeof DOMAIN_BY_SCHEMA_VERSION;

/** Any agent model document, authored or registered; the digest ignores registry facts. */
export interface AgentModelDocumentV1<SchemaVersion extends AgentModelSchemaVersionV1> {
  readonly schemaVersion: SchemaVersion;
}

/** Digest of an agent model document under the domain of its schema version. */
export function agentModelDocumentDigestV1(
  document: AgentModelDocumentV1<AgentModelSchemaVersionV1>,
): AuthorityDigestV2 {
  if (!Object.hasOwn(DOMAIN_BY_SCHEMA_VERSION, document.schemaVersion)) {
    throw new AuthorityContractError("Unsupported agent model schema version.", [
      { code: "schema_invalid", path: "/schemaVersion", message: "unsupported schema version" },
    ]);
  }
  const {
    digest: _digest,
    lifecycle: _lifecycle,
    trustClass: _trustClass,
    ...authored
  } = document as AgentModelDocumentV1<AgentModelSchemaVersionV1> & {
    digest?: unknown;
    lifecycle?: unknown;
    trustClass?: unknown;
  };
  return canonicalAuthorityDigestV2(DOMAIN_BY_SCHEMA_VERSION[document.schemaVersion], authored);
}

/**
 * Digest of a role template v3 (`kombify.agent-role-template.digest.v3`) over
 * its authored projection: the template without digest, lifecycle and trust
 * class. A spawn pins it.
 */
export function agentRoleTemplateDigestV3(
  template: AgentModelDocumentV1<"kombify.agent-role-template.v3">,
): AuthorityDigestV2 {
  return agentModelDocumentDigestV1(template);
}
