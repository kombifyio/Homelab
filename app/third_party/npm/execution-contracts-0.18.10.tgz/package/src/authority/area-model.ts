/**
 * Area model: rights by area, expressed in the agent model records.
 *
 * Decision: workspace `DECISION-RECORD-2026-11-20-agent-rights-areas-and-standard-agents.md`
 * (D-2026-11-20-06 / -07). Schemas: `agent-area-index.v1`, `agent-role.v4`,
 * `factory-profile.v1`, `office-profile.v2`, `agent-position.v1` and
 * `agent-role-template.v3` in the workspace `platform/standards/`.
 *
 * BOUNDARY OF THIS MODULE (package A1). It ADDS the area model beside the class
 * model of `agent-model.ts`; it removes and changes nothing there. Role v3, the
 * Factory binding, Office v1, `composeAgentAuthority`, the capability classes
 * and the v2 role projection stay exactly as `services/agents` and the Gateway
 * read them today. Nothing emits a template v3 until package A2 (spawn)
 * cuts over, and the class types, the v2 composer and the superseded records
 * are deleted by the contract package after that. That is an ordering of
 * packages, not a second path: the Gateway can consume this module first.
 *
 * What a record says, and who decides:
 * - the area index lists every area once (office, factory, tool, companion,
 *   baseline, staff); the Gateway catalogue puts every definition in one;
 * - the role (`AgentRoleV4`) says how far the agent reaches in its Office:
 *   present, active for reversible writes, or active, and what it hands on;
 * - the Factory profile gives presence (all areas of the Factory) and the
 *   tool areas suggested per role;
 * - the Office profile gives action (its home areas plus `alsoActiveIn`),
 *   the one resource, the device and the standard agent;
 * - a position (`AgentPositionV1`) is a fixed agent: Companion, coordinator,
 *   support;
 * - the template v3 projection carries the composed authority in areas only,
 *   so a pinned projection does not change when the catalogue gains a
 *   definition (`area-model-projection.ts`).
 *
 * `resolveAreaAuthority` below is the one resolver that turns a template or a
 * position and the catalogue's `{areas, definitions}` into definition sets.
 * The Gateway and the AI Platform both call it, so both compute the same.
 *
 * Pure: no runtime import beyond the shared mapper kit, so clients bundle only
 * this file. Digests live in `agent-model-digest.ts`; composing and parsing the
 * projection, which needs them, is in `area-model-projection.ts`.
 */

import {
  AGENT_ROLE_IDS,
  AGENT_TYPE_PROVISIONS,
  OFFICE_CUBI_SITE_TYPES,
  OFFICE_CUBI_TEMPLATE_IDS,
  OFFICE_DEVICE_PRODUCT_ID,
  type AgentRoleIdV3,
  type AgentRoleQuotaV3,
  type AgentRoleScopeV3,
  type AgentTypeProvisionV1,
  type OfficeCubiV1,
} from "./agent-model.js";
import {
  closed,
  envelope,
  integer,
  invalid,
  localized,
  oneOf,
  text,
  uniqueList,
  type AgentModelCatalogEnvelopeV1,
  type LocalizedTextV1,
} from "./agent-model-kit.js";

// ── Vocabulary ─────────────────────────────────────────────────────────────

export const AGENT_AREA_INDEX_SCHEMA_VERSION = "kombify.agent-area-index.v1";
export const AGENT_ROLE_SCHEMA_VERSION_V4 = "kombify.agent-role.v4";
export const FACTORY_PROFILE_SCHEMA_VERSION = "kombify.factory-profile.v1";
export const OFFICE_PROFILE_SCHEMA_VERSION_V2 = "kombify.office-profile.v2";
export const AGENT_POSITION_SCHEMA_VERSION = "kombify.agent-position.v1";
export const AGENT_ROLE_TEMPLATE_SCHEMA_VERSION_V3 = "kombify.agent-role-template.v3";

/** An area id: `<product-or-kind>.<name>`, dot separated, lower case. */
export const AREA_ID_PATTERN = /^[a-z][a-z0-9-]*(?:\.[a-z][a-z0-9-]*)+$/;
const POSITION_ID_PATTERN = /^[a-z][a-z0-9-]*(?:\.[a-z][a-z0-9-]*)*$/;
const DEVICE_DEFINITION = /^device\..+$/;

/**
 * Closed area kinds. `office`: home area of one Office. `factory`: Factory-level,
 * no Office. `tool`: outside every area, off by default. `companion`: the
 * Companion only. `baseline`: every agent is present. `staff`: company agents.
 */
export const AGENT_AREA_KINDS = [
  "office",
  "factory",
  "tool",
  "companion",
  "baseline",
  "staff",
] as const;
export type AgentAreaKindV1 = (typeof AGENT_AREA_KINDS)[number];

/** What a role may do in its Office's areas. */
export const AGENT_ROLE_OFFICE_REACH = ["present", "active-reversible", "active"] as const;
export type AgentRoleOfficeReachV4 = (typeof AGENT_ROLE_OFFICE_REACH)[number];

export const AGENT_ROLE_HELPER_HAND_ON = ["none", "held"] as const;
export const AGENT_ROLE_HELPER_ANSWER = ["none", "helpers"] as const;

export const AGENT_ROLE_SCOPES_V4 = [
  "handed-items-or-office-read",
  "office",
  "office-with-helper-handout",
] as const;

/** `reversible`: only what can be undone (action classes read and reversible_write). */
export const AGENT_ACTIVE_WRITES = ["all", "reversible"] as const;
export type AgentActiveWritesV1 = (typeof AGENT_ACTIVE_WRITES)[number];

export const AGENT_POSITION_PRESENT = ["everywhere", "factory", "none"] as const;
export const AGENT_POSITION_SELF_GIVE = ["office-rights", "none"] as const;
export const AGENT_POSITION_HAND_ON = ["person-reach", "factory", "none"] as const;
export const AGENT_POSITION_ANSWER = ["all", "factory", "none"] as const;

export const AGENT_TEMPLATE_KNOWLEDGE_TIERS = ["KT0", "KT1", "KT2", "KT3"] as const;
export const AGENT_TEMPLATE_EXECUTION_CLASSES = [
  "kombify-generic-host",
  "remote-environment",
  "external-harness",
  "execution-node",
] as const;

// ── Shapes ─────────────────────────────────────────────────────────────────

export interface AgentAreaV1 {
  id: string;
  label: LocalizedTextV1;
  kind: AgentAreaKindV1;
  /** Office and factory areas. */
  factoryId?: string;
  /** Office areas: the Office whose home area this is. */
  officeId?: string;
  /** Office areas: the resource dimension the Office binds its agents to. */
  resourceDimension?: string;
}

export interface AgentAreaIndexV1 extends AgentModelCatalogEnvelopeV1<
  typeof AGENT_AREA_INDEX_SCHEMA_VERSION
> {
  /** Every area, sorted by id. */
  areas: AgentAreaV1[];
}

export interface AgentRoleHelpersV4 {
  /** Concurrent helper agents; maps to `maxChildren`. */
  max: number;
  /** `held`: the agent hands on at most what it holds itself, plus tools. */
  handOn: (typeof AGENT_ROLE_HELPER_HAND_ON)[number];
  /** `helpers`: it answers the requests of its own helpers inside what it may hand on. */
  answer: (typeof AGENT_ROLE_HELPER_ANSWER)[number];
}

export interface AgentRoleV4 extends AgentModelCatalogEnvelopeV1<
  typeof AGENT_ROLE_SCHEMA_VERSION_V4
> {
  roleId: AgentRoleIdV3;
  label: LocalizedTextV1;
  description: LocalizedTextV1;
  office: AgentRoleOfficeReachV4;
  helpers: AgentRoleHelpersV4;
  scope: AgentRoleScopeV3;
  quota: AgentRoleQuotaV3;
  requires: AgentTypeProvisionV1[];
}

export interface FactoryProfileV1 extends AgentModelCatalogEnvelopeV1<
  typeof FACTORY_PROFILE_SCHEMA_VERSION
> {
  factoryId: string;
  coordinatorAgentId: string;
  /** Tool areas offered first to each role; switched on only by the person, the agent or its creator. */
  suggestedTools: Record<AgentRoleIdV3, string[]>;
}

export interface OfficeProfileDeviceDefinitionV2 {
  id: string;
  /** true: operates the device (apps, files). false: only observes. */
  write: boolean;
}

export interface OfficeDeviceEquipmentV2 {
  productId: typeof OFFICE_DEVICE_PRODUCT_ID;
  definitions: OfficeProfileDeviceDefinitionV2[];
}

export interface OfficeStandardAgentV2 {
  baseAgentId: string;
  roleId: "manager";
  agentType: "permanent";
}

export interface OfficeProfileV2 extends AgentModelCatalogEnvelopeV1<
  typeof OFFICE_PROFILE_SCHEMA_VERSION_V2
> {
  factoryId: string;
  officeId: string;
  resource: { dimension: string; binding: "office-context" };
  /** Neighbouring office or factory areas of the same Factory, never a home area. Sorted. */
  alsoActiveIn: string[];
  device: OfficeDeviceEquipmentV2 | null;
  space: boolean;
  wiki: boolean;
  knowledge: boolean;
  /** kombify Sites template and SiteType; build-factory Offices only. */
  cubi?: OfficeCubiV1;
  standardAgent: OfficeStandardAgentV2;
}

export type AgentPositionPresentV1 = (typeof AGENT_POSITION_PRESENT)[number];
export type AgentPositionSelfGiveV1 = (typeof AGENT_POSITION_SELF_GIVE)[number];
export type AgentPositionHandOnV1 = (typeof AGENT_POSITION_HAND_ON)[number];
export type AgentPositionAnswerV1 = (typeof AGENT_POSITION_ANSWER)[number];

/** A fixed agent: Companion, coordinator or support level. Not a template. */
export interface AgentPositionV1 extends AgentModelCatalogEnvelopeV1<
  typeof AGENT_POSITION_SCHEMA_VERSION
> {
  positionId: string;
  /** The registered runtime agent; null where a person staffs the position. */
  agentId: string | null;
  present: AgentPositionPresentV1;
  /** Required exactly when `present` is `factory`. */
  factoryId?: string;
  /** false: the position carries out no work itself. */
  executes: boolean;
  /** Kinds of area the position is active in. Sorted. */
  activeAreaKinds: AgentAreaKindV1[];
  selfGive: AgentPositionSelfGiveV1;
  handOn: AgentPositionHandOnV1;
  answer: AgentPositionAnswerV1;
}

export interface AgentActiveAreaV1 {
  area: string;
  writes: AgentActiveWritesV1;
}

/** Authority of a template v3, in areas only. */
export interface AgentTemplateAuthorityV3 {
  /** Areas the agent reads: all areas of its Factory plus the baseline. Sorted. */
  present: string[];
  /** Areas it is active in: the Office's home areas plus `alsoActiveIn`. Sorted by area. */
  active: AgentActiveAreaV1[];
  resource: { dimension: string; areas: string[] };
  helpers: AgentRoleHelpersV4;
}

export interface AgentTemplateLoadoutV3 {
  device: OfficeDeviceEquipmentV2 | null;
  /** Tool areas offered first to this role in its Factory. Sorted. */
  suggestedTools: string[];
}

export interface AgentTemplateBudgetV3 {
  tokens?: number;
  maxActiveLeases?: number;
  maxEquippedDefinitions?: number;
}

/**
 * The projection a spawn pins and the Gateway reads (`kombify.agent-role-template.v3`):
 * the composed authority in areas, never definition ids.
 */
export interface AgentRoleTemplateV3 extends AgentModelCatalogEnvelopeV1<
  typeof AGENT_ROLE_TEMPLATE_SCHEMA_VERSION_V3
> {
  roleId: AgentRoleIdV3;
  factoryId: string;
  officeId: string;
  agentType: "permanent" | "expert" | "ad-hoc";
  label: string;
  description: string;
  baseAgentId: string;
  authority: AgentTemplateAuthorityV3;
  loadout: AgentTemplateLoadoutV3;
  sandboxAllowed: boolean;
  budget: AgentTemplateBudgetV3;
  durableTtlSeconds: number;
  maxTtlSeconds?: number;
  knowledgeTier: (typeof AGENT_TEMPLATE_KNOWLEDGE_TIERS)[number];
  spawnDepth: number;
  maxChildren: number;
  executionClass: (typeof AGENT_TEMPLATE_EXECUTION_CLASSES)[number];
}

// ── Fail-closed mappers ────────────────────────────────────────────────────

const AREA_ID = { pattern: AREA_ID_PATTERN };

/** A list that is strictly ascending: sorted and free of duplicates (standard §4.2b). */
function sortedKeys(keys: readonly string[], shape: string, path: string): void {
  for (let index = 1; index < keys.length; index += 1) {
    if ((keys[index - 1] as string) >= (keys[index] as string)) {
      invalid(shape, `${path} is not sorted and deduplicated`);
    }
  }
}

function areaIdList(value: unknown, shape: string, path: string): string[] {
  const ids = uniqueList(value, shape, path, AREA_ID);
  sortedKeys(ids, shape, path);
  return ids;
}

function nonEmptyText(value: unknown, shape: string, path: string): string {
  const out = text(value);
  if (!out) invalid(shape, path);
  return out;
}

export function mapAgentAreaIndexV1(raw: unknown): AgentAreaIndexV1 {
  const shape = "AgentAreaIndexV1";
  const { item, head } = envelope(raw, AGENT_AREA_INDEX_SCHEMA_VERSION, shape, ["areas"]);
  if (!Array.isArray(item.areas) || item.areas.length === 0) invalid(shape, "areas");
  const areas = item.areas.map((entry, index): AgentAreaV1 => {
    const path = `areas[${index}]`;
    const area = closed(entry, shape, path, [
      "id",
      "label",
      "kind",
      "factoryId",
      "officeId",
      "resourceDimension",
    ]);
    const id = text(area.id);
    const kind = oneOf(area.kind, AGENT_AREA_KINDS);
    if (!id || !AREA_ID_PATTERN.test(id)) invalid(shape, `${path}.id`);
    if (!kind) invalid(shape, `${path}.kind`);
    const factoryId = area.factoryId === undefined ? undefined : text(area.factoryId);
    const officeId = area.officeId === undefined ? undefined : text(area.officeId);
    const resourceDimension =
      area.resourceDimension === undefined ? undefined : text(area.resourceDimension);
    if (
      (area.factoryId !== undefined && !factoryId) ||
      (area.officeId !== undefined && !officeId) ||
      (area.resourceDimension !== undefined && !resourceDimension)
    ) {
      invalid(shape, `${path} has an empty field`);
    }
    // Per kind: office needs factory and Office; factory needs the Factory and
    // no Office or resource; every other kind names none of them.
    if (kind === "office") {
      if (!factoryId || !officeId) invalid(shape, `${path} needs factoryId and officeId`);
    } else if (kind === "factory") {
      if (!factoryId || officeId !== undefined || resourceDimension !== undefined) {
        invalid(shape, `${path} needs factoryId and nothing else`);
      }
    } else if (
      factoryId !== undefined ||
      officeId !== undefined ||
      resourceDimension !== undefined
    ) {
      invalid(shape, `${path} of kind ${kind} names no Factory, Office or resource`);
    }
    return {
      id,
      label: localized(area.label, shape, `${path}.label`),
      kind,
      ...(factoryId === undefined ? {} : { factoryId }),
      ...(officeId === undefined ? {} : { officeId }),
      ...(resourceDimension === undefined ? {} : { resourceDimension }),
    };
  });
  sortedKeys(
    areas.map((area) => area.id),
    shape,
    "areas",
  );
  return { ...head, areas };
}

function mapHelpers(value: unknown, shape: string, path: string): AgentRoleHelpersV4 {
  const raw = closed(value, shape, path, ["max", "handOn", "answer"]);
  const max = integer(raw.max, 0);
  const handOn = oneOf(raw.handOn, AGENT_ROLE_HELPER_HAND_ON);
  const answer = oneOf(raw.answer, AGENT_ROLE_HELPER_ANSWER);
  if (max === undefined || !handOn || !answer) invalid(shape, path);
  return { max, handOn, answer };
}

export function mapAgentRoleV4(raw: unknown): AgentRoleV4 {
  const shape = "AgentRoleV4";
  const { item, head } = envelope(raw, AGENT_ROLE_SCHEMA_VERSION_V4, shape, [
    "roleId",
    "label",
    "description",
    "office",
    "helpers",
    "scope",
    "quota",
    "requires",
  ]);
  const roleId = oneOf(item.roleId, AGENT_ROLE_IDS);
  const office = oneOf(item.office, AGENT_ROLE_OFFICE_REACH);
  const scope = oneOf(item.scope, AGENT_ROLE_SCOPES_V4);
  if (!roleId) invalid(shape, "roleId");
  if (!office) invalid(shape, "office");
  if (!scope) invalid(shape, "scope");
  const helpers = mapHelpers(item.helpers, shape, "helpers");
  const quotaRaw = closed(item.quota, shape, "quota", [
    "loadoutCapacity",
    "concurrentLeases",
    "tokenBudget",
    "helpers",
  ]);
  const loadoutCapacity = integer(quotaRaw.loadoutCapacity, 0);
  const concurrentLeases = integer(quotaRaw.concurrentLeases, 0);
  const tokenBudget = integer(quotaRaw.tokenBudget, 0);
  const quotaHelpers = integer(quotaRaw.helpers, 0);
  if (
    loadoutCapacity === undefined ||
    concurrentLeases === undefined ||
    tokenBudget === undefined ||
    quotaHelpers === undefined
  ) {
    invalid(shape, "quota");
  }
  const requires = uniqueList(item.requires, shape, "requires", { members: AGENT_TYPE_PROVISIONS });
  // The record agrees with itself: helpers are quota and a type provision at once,
  // a role without helpers hands on and answers nothing, and only an active role runs helpers.
  if (quotaHelpers !== helpers.max) invalid(shape, "quota.helpers differs from helpers.max");
  if (requires.includes("helpers") !== helpers.max > 0) {
    invalid(shape, "requires lists helpers exactly when helpers.max > 0");
  }
  if (helpers.max === 0 && (helpers.handOn !== "none" || helpers.answer !== "none")) {
    invalid(shape, "a role without helpers hands on and answers nothing");
  }
  if (helpers.max > 0 && office !== "active") invalid(shape, "only an active role runs helpers");
  return {
    ...head,
    roleId,
    label: localized(item.label, shape, "label"),
    description: localized(item.description, shape, "description"),
    office,
    helpers,
    scope,
    quota: { loadoutCapacity, concurrentLeases, tokenBudget, helpers: quotaHelpers },
    requires,
  };
}

export function mapFactoryProfileV1(raw: unknown): FactoryProfileV1 {
  const shape = "FactoryProfileV1";
  const { item, head } = envelope(raw, FACTORY_PROFILE_SCHEMA_VERSION, shape, [
    "factoryId",
    "coordinatorAgentId",
    "suggestedTools",
  ]);
  const factoryId = nonEmptyText(item.factoryId, shape, "factoryId");
  const coordinatorAgentId = nonEmptyText(item.coordinatorAgentId, shape, "coordinatorAgentId");
  const suggestedRaw = closed(item.suggestedTools, shape, "suggestedTools", [...AGENT_ROLE_IDS]);
  const suggestedTools = {} as Record<AgentRoleIdV3, string[]>;
  for (const roleId of AGENT_ROLE_IDS) {
    suggestedTools[roleId] = areaIdList(suggestedRaw[roleId], shape, `suggestedTools.${roleId}`);
  }
  return { ...head, factoryId, coordinatorAgentId, suggestedTools };
}

/** The Office device, shared by the Office profile v2 and the template v3 loadout. */
function mapDeviceV2(value: unknown, shape: string, path: string): OfficeDeviceEquipmentV2 | null {
  if (value === null) return null;
  const device = closed(value, shape, path, ["productId", "definitions"]);
  if (device.productId !== OFFICE_DEVICE_PRODUCT_ID) invalid(shape, `${path}.productId`);
  if (!Array.isArray(device.definitions) || device.definitions.length === 0) {
    invalid(shape, `${path}.definitions`);
  }
  const definitions = device.definitions.map((entry, index): OfficeProfileDeviceDefinitionV2 => {
    const definition = closed(entry, shape, `${path}.definitions[${index}]`, ["id", "write"]);
    const id = text(definition.id);
    if (!id || !DEVICE_DEFINITION.test(id) || typeof definition.write !== "boolean") {
      invalid(shape, `${path}.definitions[${index}]`);
    }
    return { id, write: definition.write };
  });
  sortedKeys(
    definitions.map((definition) => definition.id),
    shape,
    `${path}.definitions`,
  );
  return { productId: OFFICE_DEVICE_PRODUCT_ID, definitions };
}

export function mapOfficeProfileV2(raw: unknown): OfficeProfileV2 {
  const shape = "OfficeProfileV2";
  const { item, head } = envelope(raw, OFFICE_PROFILE_SCHEMA_VERSION_V2, shape, [
    "factoryId",
    "officeId",
    "resource",
    "alsoActiveIn",
    "device",
    "space",
    "wiki",
    "knowledge",
    "cubi",
    "standardAgent",
  ]);
  const factoryId = nonEmptyText(item.factoryId, shape, "factoryId");
  const officeId = nonEmptyText(item.officeId, shape, "officeId");
  const resourceRaw = closed(item.resource, shape, "resource", ["dimension", "binding"]);
  const dimension = text(resourceRaw.dimension);
  if (!dimension || resourceRaw.binding !== "office-context") invalid(shape, "resource");
  if (
    typeof item.space !== "boolean" ||
    typeof item.wiki !== "boolean" ||
    typeof item.knowledge !== "boolean"
  ) {
    invalid(shape, "space, wiki and knowledge must be booleans");
  }
  let cubi: OfficeCubiV1 | undefined;
  if (item.cubi !== undefined) {
    const cubiRaw = closed(item.cubi, shape, "cubi", ["templateId", "siteType"]);
    const templateId = oneOf(cubiRaw.templateId, OFFICE_CUBI_TEMPLATE_IDS);
    const siteType = oneOf(cubiRaw.siteType, OFFICE_CUBI_SITE_TYPES);
    if (!templateId || !siteType) invalid(shape, "cubi");
    cubi = { templateId, siteType };
  }
  const standardRaw = closed(item.standardAgent, shape, "standardAgent", [
    "baseAgentId",
    "roleId",
    "agentType",
  ]);
  if (standardRaw.roleId !== "manager" || standardRaw.agentType !== "permanent") {
    invalid(shape, "standardAgent is the permanent Manager of the Office");
  }
  return {
    ...head,
    factoryId,
    officeId,
    resource: { dimension, binding: "office-context" },
    alsoActiveIn: areaIdList(item.alsoActiveIn, shape, "alsoActiveIn"),
    device: mapDeviceV2(item.device, shape, "device"),
    space: item.space,
    wiki: item.wiki,
    knowledge: item.knowledge,
    ...(cubi ? { cubi } : {}),
    standardAgent: {
      baseAgentId: nonEmptyText(standardRaw.baseAgentId, shape, "standardAgent.baseAgentId"),
      roleId: "manager",
      agentType: "permanent",
    },
  };
}

export function mapAgentPositionV1(raw: unknown): AgentPositionV1 {
  const shape = "AgentPositionV1";
  const { item, head } = envelope(raw, AGENT_POSITION_SCHEMA_VERSION, shape, [
    "positionId",
    "agentId",
    "present",
    "factoryId",
    "executes",
    "activeAreaKinds",
    "selfGive",
    "handOn",
    "answer",
  ]);
  const positionId = text(item.positionId);
  if (!positionId || !POSITION_ID_PATTERN.test(positionId)) invalid(shape, "positionId");
  if (positionId !== head.id) invalid(shape, "positionId differs from id");
  let agentId: string | null;
  if (item.agentId === null) agentId = null;
  else {
    const agent = text(item.agentId);
    if (!agent) invalid(shape, "agentId");
    agentId = agent;
  }
  const present = oneOf(item.present, AGENT_POSITION_PRESENT);
  const selfGive = oneOf(item.selfGive, AGENT_POSITION_SELF_GIVE);
  const handOn = oneOf(item.handOn, AGENT_POSITION_HAND_ON);
  const answer = oneOf(item.answer, AGENT_POSITION_ANSWER);
  if (!present) invalid(shape, "present");
  if (!selfGive) invalid(shape, "selfGive");
  if (!handOn) invalid(shape, "handOn");
  if (!answer) invalid(shape, "answer");
  if (typeof item.executes !== "boolean") invalid(shape, "executes");
  const factoryId = item.factoryId === undefined ? undefined : text(item.factoryId);
  if (item.factoryId !== undefined && !factoryId) invalid(shape, "factoryId");
  if ((present === "factory") !== (factoryId !== undefined)) {
    invalid(shape, "factoryId belongs to a factory-present position only");
  }
  const activeAreaKinds = uniqueList(item.activeAreaKinds, shape, "activeAreaKinds", {
    members: AGENT_AREA_KINDS,
  });
  sortedKeys(activeAreaKinds, shape, "activeAreaKinds");
  if (!item.executes && activeAreaKinds.length > 0) {
    invalid(shape, "a position that executes nothing is active nowhere");
  }
  if (present !== "everywhere" && activeAreaKinds.includes("companion")) {
    invalid(shape, "only an everywhere-present position is active in companion areas");
  }
  return {
    ...head,
    positionId,
    agentId,
    present,
    ...(factoryId === undefined ? {} : { factoryId }),
    executes: item.executes,
    activeAreaKinds,
    selfGive,
    handOn,
    answer,
  };
}

/**
 * Shape of a template v3. The digest is carried, not checked here: a client
 * bundling this file has no hashing. `parseAgentRoleTemplateV3` in
 * `area-model-projection.ts` also recomputes it.
 */
export function mapAgentRoleTemplateV3(raw: unknown): AgentRoleTemplateV3 {
  const shape = "AgentRoleTemplateV3";
  const { item, head } = envelope(raw, AGENT_ROLE_TEMPLATE_SCHEMA_VERSION_V3, shape, [
    "roleId",
    "factoryId",
    "officeId",
    "agentType",
    "label",
    "description",
    "baseAgentId",
    "authority",
    "loadout",
    "sandboxAllowed",
    "budget",
    "durableTtlSeconds",
    "maxTtlSeconds",
    "knowledgeTier",
    "spawnDepth",
    "maxChildren",
    "executionClass",
  ]);
  const roleId = oneOf(item.roleId, AGENT_ROLE_IDS);
  const agentType = oneOf(item.agentType, ["permanent", "expert", "ad-hoc"] as const);
  const knowledgeTier = oneOf(item.knowledgeTier, AGENT_TEMPLATE_KNOWLEDGE_TIERS);
  const executionClass = oneOf(item.executionClass, AGENT_TEMPLATE_EXECUTION_CLASSES);
  if (!roleId) invalid(shape, "roleId");
  if (!agentType) invalid(shape, "agentType");
  if (!knowledgeTier) invalid(shape, "knowledgeTier");
  if (!executionClass) invalid(shape, "executionClass");
  if (typeof item.description !== "string") invalid(shape, "description");
  if (typeof item.sandboxAllowed !== "boolean") invalid(shape, "sandboxAllowed");
  const authorityRaw = closed(item.authority, shape, "authority", [
    "present",
    "active",
    "resource",
    "helpers",
  ]);
  if (!Array.isArray(authorityRaw.active)) invalid(shape, "authority.active");
  const active = authorityRaw.active.map((entry, index): AgentActiveAreaV1 => {
    const path = `authority.active[${index}]`;
    const area = closed(entry, shape, path, ["area", "writes"]);
    const id = text(area.area);
    const writes = oneOf(area.writes, AGENT_ACTIVE_WRITES);
    if (!id || !AREA_ID_PATTERN.test(id) || !writes) invalid(shape, path);
    return { area: id, writes };
  });
  sortedKeys(
    active.map((entry) => entry.area),
    shape,
    "authority.active",
  );
  const resourceRaw = closed(authorityRaw.resource, shape, "authority.resource", [
    "dimension",
    "areas",
  ]);
  const loadoutRaw = closed(item.loadout, shape, "loadout", ["device", "suggestedTools"]);
  const budgetRaw = closed(item.budget, shape, "budget", [
    "tokens",
    "maxActiveLeases",
    "maxEquippedDefinitions",
  ]);
  const budget: AgentTemplateBudgetV3 = {};
  for (const key of ["tokens", "maxActiveLeases", "maxEquippedDefinitions"] as const) {
    if (budgetRaw[key] === undefined) continue;
    const value = integer(budgetRaw[key], 0);
    if (value === undefined) invalid(shape, `budget.${key}`);
    budget[key] = value;
  }
  const durableTtlSeconds = integer(item.durableTtlSeconds, 0);
  const spawnDepth = integer(item.spawnDepth, 0);
  const maxChildren = integer(item.maxChildren, 0);
  const maxTtlSeconds =
    item.maxTtlSeconds === undefined ? undefined : integer(item.maxTtlSeconds, 0);
  if (durableTtlSeconds === undefined || spawnDepth === undefined || maxChildren === undefined) {
    invalid(shape, "durableTtlSeconds, spawnDepth and maxChildren must be non-negative integers");
  }
  if (item.maxTtlSeconds !== undefined && maxTtlSeconds === undefined)
    invalid(shape, "maxTtlSeconds");
  return {
    ...head,
    roleId,
    factoryId: nonEmptyText(item.factoryId, shape, "factoryId"),
    officeId: nonEmptyText(item.officeId, shape, "officeId"),
    agentType,
    label: nonEmptyText(item.label, shape, "label"),
    description: item.description,
    baseAgentId: nonEmptyText(item.baseAgentId, shape, "baseAgentId"),
    authority: {
      present: areaIdList(authorityRaw.present, shape, "authority.present"),
      active,
      resource: {
        dimension: nonEmptyText(resourceRaw.dimension, shape, "authority.resource.dimension"),
        areas: areaIdList(resourceRaw.areas, shape, "authority.resource.areas"),
      },
      helpers: mapHelpers(authorityRaw.helpers, shape, "authority.helpers"),
    },
    loadout: {
      device: mapDeviceV2(loadoutRaw.device, shape, "loadout.device"),
      suggestedTools: areaIdList(loadoutRaw.suggestedTools, shape, "loadout.suggestedTools"),
    },
    sandboxAllowed: item.sandboxAllowed,
    budget,
    durableTtlSeconds,
    ...(maxTtlSeconds === undefined ? {} : { maxTtlSeconds }),
    knowledgeTier,
    spawnDepth,
    maxChildren,
    executionClass,
  };
}

// ── Composition ────────────────────────────────────────────────────────────

/** Sort by value (standard §4.2b); the ES2022 lib has no toSorted. */
function sortedUnique(values: Iterable<string>): string[] {
  const out = [...new Set(values)];
  // oxlint-disable-next-line unicorn/no-array-sort
  out.sort();
  return out;
}

/** The areas of one Office's own: office areas that name it. */
export function officeHomeAreas(
  areaIndex: Pick<AgentAreaIndexV1, "areas">,
  factoryId: string,
  officeId: string,
): string[] {
  return sortedUnique(
    areaIndex.areas
      .filter(
        (area) =>
          area.kind === "office" && area.factoryId === factoryId && area.officeId === officeId,
      )
      .map((area) => area.id),
  );
}

/** What a role may do in one Office, in areas. No definition ids: those come from the catalogue. */
export interface ComposedAgentAuthorityV2 {
  roleId: AgentRoleIdV3;
  factoryId: string;
  officeId: string;
  /** Every area of the Factory plus the baseline areas. Sorted. */
  present: string[];
  /** Home areas plus `alsoActiveIn`, with how freely the role writes. Empty for the researcher. */
  active: AgentActiveAreaV1[];
  /** The one resource the active rights are bound to, and the home areas it applies to. */
  resource: { dimension: string; areas: string[] };
  helpers: AgentRoleHelpersV4;
  /** The Office device and the tool areas suggested to the role first. */
  loadout: AgentTemplateLoadoutV3;
  /** Whether the role may run code in a sandbox (`office` is `active`). */
  sandboxAllowed: boolean;
}

/**
 * Compose a role with its Factory profile, Office profile and the area index.
 * Throws when the records do not fit together: an Office of another Factory,
 * no home area, an `alsoActiveIn` that is unknown, not an office or factory
 * area of the Factory or the Office's own, a resource dimension the home
 * areas do not bind, or a suggested tool that is no tool area.
 */
export function composeAgentAuthorityV2(
  role: AgentRoleV4,
  factory: FactoryProfileV1,
  office: OfficeProfileV2,
  areaIndex: AgentAreaIndexV1,
): ComposedAgentAuthorityV2 {
  if (office.factoryId !== factory.factoryId) {
    throw new TypeError(`Office ${office.id} belongs to Factory ${office.factoryId}`);
  }
  const areas = new Map(areaIndex.areas.map((area) => [area.id, area]));
  const home = officeHomeAreas(areaIndex, office.factoryId, office.officeId);
  if (home.length === 0) throw new TypeError(`Office ${office.id} has no home area`);
  for (const id of home) {
    const dimension = areas.get(id)?.resourceDimension;
    if (dimension !== office.resource.dimension) {
      throw new TypeError(
        `Office ${office.id}: home area ${id} binds ${String(dimension)}, the profile ${office.resource.dimension}`,
      );
    }
  }
  for (const id of office.alsoActiveIn) {
    const area = areas.get(id);
    if (!area)
      throw new TypeError(`Office ${office.id}: alsoActiveIn names the unknown area ${id}`);
    if (!["office", "factory"].includes(area.kind) || area.factoryId !== office.factoryId) {
      throw new TypeError(
        `Office ${office.id}: alsoActiveIn ${id} is not an office or factory area of ${office.factoryId}`,
      );
    }
    if (home.includes(id)) {
      throw new TypeError(`Office ${office.id}: alsoActiveIn lists its own home area ${id}`);
    }
  }
  const suggestedTools = sortedUnique(factory.suggestedTools[role.roleId] ?? []);
  for (const id of suggestedTools) {
    if (areas.get(id)?.kind !== "tool") {
      throw new TypeError(
        `Factory ${factory.factoryId}: suggestedTools.${role.roleId} names ${id}, which is not a tool area`,
      );
    }
  }
  const present = sortedUnique(
    areaIndex.areas
      .filter(
        (area) =>
          area.kind === "baseline" ||
          ((area.kind === "office" || area.kind === "factory") &&
            area.factoryId === office.factoryId),
      )
      .map((area) => area.id),
  );
  const writes: AgentActiveWritesV1 = role.office === "active-reversible" ? "reversible" : "all";
  const active: AgentActiveAreaV1[] =
    role.office === "present"
      ? []
      : sortedUnique([...home, ...office.alsoActiveIn]).map((area) => ({ area, writes }));
  return {
    roleId: role.roleId,
    factoryId: office.factoryId,
    officeId: office.officeId,
    present,
    active,
    resource: { dimension: office.resource.dimension, areas: home },
    helpers: { ...role.helpers },
    loadout: {
      device: office.device
        ? {
            productId: office.device.productId,
            definitions: office.device.definitions.map((definition) => ({ ...definition })),
          }
        : null,
      suggestedTools,
    },
    sandboxAllowed: role.office === "active",
  };
}

// ── The one resolver ───────────────────────────────────────────────────────

/**
 * Definitions that open access to people outside the household or organisation (decision record 2026-11-20
 * section 4: a public link, an invitation, access for somebody else's agent). A person decides them: no agent
 * hands them on, answers for them or gives them to itself. The catalogue does not mark them yet (it will carry
 * `humanReason`); until then this is the one list, shared by the Gateway and the AI Platform.
 */
export const OUTSIDE_ACCESS_DEFINITIONS: ReadonlySet<string> = new Set([
  "paperwork.document-shares.create",
  "paperwork.shares.create",
  "cloud.household.grant",
  "kombifyme.access.grant",
]);

/** The catalogue's own classification of a definition (`actionClass`). */
export type AreaActionClassV1 =
  | "read"
  | "reversible_write"
  | "external_write"
  | "destructive"
  | "cost_bearing";

/** The slice of a catalogue definition the resolver reads. A plain data shape, no Gateway import. */
export interface AreaCatalogDefinitionV1 {
  id: string;
  area: string;
  actionClass: AreaActionClassV1;
  /** Only `active` definitions are ever in a result. */
  lifecycle: string;
  /** Present when a person is asked: nobody hands such a definition on or answers it. */
  humanReason?: string;
}

/** The slice of the area index the resolver reads. The manifest's `areas` fit as they are. */
export interface AreaCatalogAreaV1 {
  id: string;
  kind: AgentAreaKindV1;
  factoryId?: string;
  officeId?: string;
}

export interface AreaCatalogV1 {
  areas: readonly AreaCatalogAreaV1[];
  definitions: readonly AreaCatalogDefinitionV1[];
}

/** How a definition stands for the subject that asks to switch it on (self-activation). */
export type AreaDefinitionClassV1 = "standard" | "tool" | "office-right" | "none";

/**
 * Facts the subject's records cannot know. Always explicit, never ambient: a
 * caller that leaves one out gets the closed answer, not a guess.
 */
export interface AreaAuthorityContextV1 {
  /**
   * Provider ids the person has connected (`GET /v1/connectors/providers`, also
   * attached, Composio and direct providers). The area of a provider is
   * `tool.provider.<id>`. Only the Companion's `use` follows them; absent means
   * none connected.
   */
  connectedProviders?: readonly string[];
  /**
   * What the person may do, as definition ids, or `"all"` where the caller has
   * no narrower fact. Bounds the Companion's `handOn`, `answer` and
   * `office-right`; absent means no reach: the Companion then hands on and
   * answers nothing and classifies no Office right.
   */
  personReach?: readonly string[] | "all";
}

export interface ResolvedAreaAuthorityV1 {
  /** Definitions the subject may use as its standard. Sorted. */
  use: string[];
  /** Definitions it may hand on to an agent it creates. Never a `humanReason` definition. Sorted. */
  handOn: string[];
  /** Definitions it may answer a request for. Never a `humanReason` definition. Sorted. */
  answer: string[];
  /** How one definition stands for self-activation by the subject. */
  classify(definitionId: string): AreaDefinitionClassV1;
}

const PROVIDER_AREA_PREFIX = "tool.provider.";
const WRITE_CLASSES_REVERSIBLE: ReadonlySet<string> = new Set(["read", "reversible_write"]);

function isTemplate(
  subject: AgentRoleTemplateV3 | AgentPositionV1,
): subject is AgentRoleTemplateV3 {
  return subject.schemaVersion === AGENT_ROLE_TEMPLATE_SCHEMA_VERSION_V3;
}

/**
 * Resolve what a template v3 or a position may use, hand on and answer, and
 * classify a definition for self-activation. Pure, deterministic and sorted.
 *
 * Rules (decision record §2, design §2):
 * - `use` is every read definition of a `present` area plus every definition
 *   of an `active` area; a Drafter's `reversible` areas keep only `read` and
 *   `reversible_write`.
 * - A Manager (`helpers.handOn: "held"`) hands on `use` plus `held` (what it
 *   holds beyond the standard) plus the definitions of every tool area, and
 *   answers the same for its helpers. A role without helpers hands on nothing.
 * - A coordinator position uses reads of its Factory's areas; it hands on and
 *   answers every definition of the Factory's office and factory areas plus
 *   tool areas.
 * - The Companion uses reads everywhere except `staff` and the tool areas,
 *   all definitions of `companion` areas and of connected provider areas; any
 *   office or factory definition it does not use classifies `office-right`
 *   within the person's reach; it hands on and answers within that reach.
 * - Nobody hands on or answers a definition with a `humanReason`.
 * - A definition whose lifecycle is not `active`, or whose area is unknown,
 *   is never in a result and classifies `none`.
 *
 * `classify`: `standard` for a definition in `use`; `tool` for a definition of
 * a tool area outside it that the subject may switch on (every template; a
 * position that executes and may give itself rights); `office-right` for the
 * Companion as above; `none` otherwise, which routes the request up the chain.
 *
 * `held` applies to a template only. It never widens `use`, which is the
 * standard, and entries that are not live definitions or carry a `humanReason`
 * are dropped.
 */
export function resolveAreaAuthority(
  subject: AgentRoleTemplateV3 | AgentPositionV1,
  catalog: AreaCatalogV1,
  held: readonly string[] = [],
  context: AreaAuthorityContextV1 = {},
): ResolvedAreaAuthorityV1 {
  const areas = new Map<string, AreaCatalogAreaV1>();
  for (const area of catalog.areas) areas.set(area.id, area);
  const live = new Map<string, AreaCatalogDefinitionV1>();
  const byArea = new Map<string, AreaCatalogDefinitionV1[]>();
  const seen = new Set<string>();
  for (const definition of catalog.definitions) {
    if (seen.has(definition.id)) {
      throw new TypeError(`Catalogue declares definition ${definition.id} twice.`);
    }
    seen.add(definition.id);
    // A retired or preview definition, or one in an unknown area, is in no result.
    if (definition.lifecycle !== "active" || !areas.has(definition.area)) continue;
    live.set(definition.id, definition);
    const list = byArea.get(definition.area) ?? [];
    list.push(definition);
    byArea.set(definition.area, list);
  }
  const inAreas = (
    areaIds: Iterable<string>,
    keep: (definition: AreaCatalogDefinitionV1) => boolean = () => true,
  ): string[] => {
    const out: string[] = [];
    for (const areaId of areaIds) {
      for (const definition of byArea.get(areaId) ?? [])
        if (keep(definition)) out.push(definition.id);
    }
    return out;
  };
  const areaIdsWhere = (keep: (area: AreaCatalogAreaV1) => boolean): string[] =>
    catalog.areas.filter(keep).map((area) => area.id);
  const isRead = (definition: AreaCatalogDefinitionV1) => definition.actionClass === "read";
  const noHumanReason = (id: string) => {
    const definition = live.get(id);
    return definition !== undefined && definition.humanReason === undefined;
  };
  const sortedSet = (ids: Iterable<string>): Set<string> => new Set(sortedUnique(ids));
  const toolAreaIds = areaIdsWhere((area) => area.kind === "tool");

  if (isTemplate(subject)) {
    const use: string[] = [...inAreas(subject.authority.present, isRead)];
    for (const entry of subject.authority.active) {
      use.push(
        ...inAreas(
          [entry.area],
          entry.writes === "all"
            ? () => true
            : (definition) => WRITE_CLASSES_REVERSIBLE.has(definition.actionClass),
        ),
      );
    }
    const useSet = sortedSet(use);
    const handOn =
      subject.authority.helpers.handOn === "held"
        ? sortedUnique([...useSet, ...held, ...inAreas(toolAreaIds)].filter(noHumanReason))
        : [];
    const answer = subject.authority.helpers.answer === "helpers" ? handOn : [];
    return {
      use: [...useSet],
      handOn,
      answer: [...answer],
      classify(definitionId) {
        const definition = live.get(definitionId);
        if (!definition) return "none";
        if (useSet.has(definitionId)) return "standard";
        return areas.get(definition.area)?.kind === "tool" ? "tool" : "none";
      },
    };
  }

  // A position. Presence first, then what it is active in.
  const factoryScoped = (area: AreaCatalogAreaV1) =>
    (area.kind === "office" || area.kind === "factory") && area.factoryId === subject.factoryId;
  const connected = new Set(
    (context.connectedProviders ?? []).map((id) => PROVIDER_AREA_PREFIX + id),
  );
  const providerAreas = areaIdsWhere(
    (area) => area.kind === "tool" && area.id.startsWith(PROVIDER_AREA_PREFIX),
  );
  const connectedProviderAreas = providerAreas.filter((id) => connected.has(id));
  const presentAreas =
    subject.present === "everywhere"
      ? areaIdsWhere((area) => ["office", "factory", "baseline", "companion"].includes(area.kind))
      : subject.present === "factory"
        ? areaIdsWhere((area) => area.kind === "baseline" || factoryScoped(area))
        : [];
  const use: string[] = [...inAreas(presentAreas, isRead)];
  if (subject.executes) {
    for (const kind of subject.activeAreaKinds) {
      if (kind === "tool") {
        // Tools are off by default (DR §2.5); only a provider the person connected is standard.
        use.push(...inAreas(connectedProviderAreas));
      } else if (kind === "office" || kind === "factory") {
        use.push(
          ...inAreas(
            areaIdsWhere(
              (area) =>
                area.kind === kind &&
                (subject.present === "everywhere" || area.factoryId === subject.factoryId),
            ),
          ),
        );
      } else {
        use.push(...inAreas(areaIdsWhere((area) => area.kind === kind)));
      }
    }
  }
  const useSet = sortedSet(use);
  const reach = context.personReach;
  const withinReach = (id: string) =>
    reach === "all" || (reach !== undefined && reach.includes(id));
  const handOnIds =
    subject.handOn === "factory"
      ? inAreas([...areaIdsWhere(factoryScoped), ...toolAreaIds])
      : subject.handOn === "person-reach"
        ? reach === undefined
          ? []
          : inAreas(areaIdsWhere((area) => area.kind !== "staff")).filter(withinReach)
        : [];
  const handOn = sortedUnique(handOnIds.filter(noHumanReason));
  const answer = subject.answer === "none" ? [] : handOn;
  const mayGive = subject.executes && subject.selfGive === "office-rights";
  return {
    use: [...useSet],
    handOn,
    answer,
    classify(definitionId) {
      const definition = live.get(definitionId);
      if (!definition) return "none";
      if (useSet.has(definitionId)) return "standard";
      const kind = areas.get(definition.area)?.kind;
      if (kind === "tool") {
        // A provider the person has not connected cannot be switched on from here.
        if (definition.area.startsWith(PROVIDER_AREA_PREFIX)) return "none";
        return subject.executes && subject.selfGive !== "none" ? "tool" : "none";
      }
      if (mayGive && (kind === "office" || kind === "factory") && withinReach(definitionId)) {
        return "office-right";
      }
      return "none";
    },
  };
}
