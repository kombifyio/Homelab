import { describe, expect, it } from "vitest";

import { agentModelDocumentDigestV1 } from "./agent-model-digest.js";
import {
  connectorDeclarationsFor,
  mapAgentConnectorCatalogV1,
  mergeConnectorDeclarations,
} from "./agent-model.js";
import { FIRST_PARTY_AGENT_MODEL, checkConnectorReferences } from "./agent-model-catalog/index.js";
import connectorCatalog from "./agent-model-catalog/agent-connector-catalog.json";

/** Re-seal a changed document so only the rule under test can refuse it. */
function sealed<T extends { schemaVersion: string }>(record: T): T {
  const digest = agentModelDocumentDigestV1(record as never);
  return { ...record, digest };
}

const rebuilt = (document: unknown) => ({
  ...FIRST_PARTY_AGENT_MODEL,
  connectors: mapAgentConnectorCatalogV1(document),
});

const refuseList = (list: unknown) =>
  expect(() => mapAgentConnectorCatalogV1(withRoles({ researcher: list }))).toThrow();

function withRoles(roles: unknown) {
  return sealed({ ...connectorCatalog, roles } as never) as never;
}

describe("the connector declarations document", () => {
  // The four pinned records keep the versions and digests every existing agent's
  // projection version was composed from: a declaration never republishes them.
  it("leaves the pinned role and binding records as they were", () => {
    const roles = Object.fromEntries(
      FIRST_PARTY_AGENT_MODEL.roles.map((role) => [role.roleId, `${role.version} ${role.digest}`]),
    );
    expect(roles).toEqual({
      researcher: "1.3.0 sha256:c903055af66751112aa2d3ad1e7f3c6344f8da2c699559e44297e5b7b632b741",
      drafter: "1.3.0 sha256:c1c9b267c03dd3a46468ff8dcf6ed2a9e87004431ac49334179df37820931794",
      specialist: "1.3.0 sha256:62c1fa1cb03e8297ed0dfc1698d887c3227f56f69be0e031c279b6c8501d3dc8",
      manager: "1.3.0 sha256:939c7ceda656d712f4a0d682fede59cc0a32ce7a920913dd8c2aa4e5ede6417f",
    });
    const bindings = Object.fromEntries(
      FIRST_PARTY_AGENT_MODEL.bindings.map((binding) => [binding.factoryId, `${binding.version} ${binding.digest}`]),
    );
    expect(bindings).toEqual({
      paperwork: "1.1.0 sha256:36e53fa9825bd181543c71c77e50f75420f26cd07b2a1a8eeca4143187a88862",
      "ril-ops": "1.0.0 sha256:20f4c4fcdd7e6713aebef544c3e66ad253079863f8ad2ed741d99d7175e155c0",
      "build-factory": "1.0.0 sha256:40373b920393313cb6793a16fb5ef9b62fce133a9ec24dfc44f32e5094313812",
      workbench: "1.0.0 sha256:f5a602992cbb88f40de0127abd142be764892bddea7a75c6cec82425777a2748",
    });
    expect(JSON.stringify(FIRST_PARTY_AGENT_MODEL.roles)).not.toContain('"connectors"');
    expect(JSON.stringify(FIRST_PARTY_AGENT_MODEL.bindings)).not.toContain('"connectors"');
  });

  it("is verified at load and merges role and Factory declarations", () => {
    expect(FIRST_PARTY_AGENT_MODEL.connectors?.digest).toBe(connectorCatalog.digest);
    const catalog = FIRST_PARTY_AGENT_MODEL.connectors;
    expect(connectorDeclarationsFor(catalog, "researcher", "build-factory")).toEqual([
      { use: "search", level: "read", need: "recommended" },
    ]);
    expect(connectorDeclarationsFor(catalog, "specialist", "paperwork").map((entry) => entry.use)).toEqual([
      "calendar",
      "documents",
      "mail",
    ]);
    expect(connectorDeclarationsFor(catalog, "researcher", "ril-ops").map((entry) => entry.use)).toEqual([
      "search",
      "smart-home",
    ]);
    expect(connectorDeclarationsFor(catalog, "specialist", "constructor")).toEqual([]);
    expect(connectorDeclarationsFor(undefined, "specialist", "paperwork")).toEqual([]);
  });

  it("refuses a declaration with both or neither of provider and use", () => {
    for (const entry of [
      { provider: "notion", use: "documents", level: "read", need: "required" },
      { level: "read", need: "required" },
    ]) {
      expect(() => mapAgentConnectorCatalogV1(withRoles({ researcher: [entry] }))).toThrow(/exactly one/u);
    }
  });

  it("refuses unknown fields, a bad level, repeats and unsorted lists", () => {
    const base = { use: "search", level: "read", need: "recommended" };
    const refuse = refuseList;
    refuse([{ ...base, extra: true }]);
    refuse([{ ...base, level: "admin" }]);
    refuse([{ ...base, need: "optional" }]);
    refuse([base, base]);
    refuse([{ ...base, use: "search" }, { ...base, use: "mail" }]);
    refuse([{ provider: "Not A Provider", level: "read", need: "required" }]);
    expect(() => mapAgentConnectorCatalogV1(withRoles({ intruder: [base] }))).toThrow(/not a role/u);
  });

  it("refuses a write request from a role that can change nothing, or where nothing is classified", () => {
    const write = [{ use: "mail", level: "write", need: "recommended" }];
    expect(() => checkConnectorReferences(rebuilt(withRoles({ researcher: write })))).toThrow(/cannot do/u);
    expect(() =>
      checkConnectorReferences(
        rebuilt(sealed({ ...connectorCatalog, bindings: { nowhere: { specialist: write } } } as never)),
      ),
    ).toThrow(/unknown Factory/u);
    expect(() =>
      checkConnectorReferences(
        rebuilt(sealed({ ...connectorCatalog, bindings: { "ril-ops": { researcher: write } } } as never)),
      ),
    ).toThrow(/write/u);
    expect(() => checkConnectorReferences(FIRST_PARTY_AGENT_MODEL)).not.toThrow();
  });

  it("merges the stronger level and need", () => {
    expect(
      mergeConnectorDeclarations(
        [{ use: "mail", level: "read", need: "recommended" }],
        [{ use: "mail", level: "write", need: "required" }, { provider: "notion", level: "read", need: "recommended" }],
      ),
    ).toEqual([
      { provider: "notion", level: "read", need: "recommended" },
      { use: "mail", level: "write", need: "required" },
    ]);
  });
});
