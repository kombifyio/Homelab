import { expect, it } from "vitest";
import {
  ed25519PublicKeyFromSeed,
  signWorkbenchHostMcpLeaseV1,
  verifyWorkbenchHostMcpLeaseV1,
  workbenchHostMcpBodyDigestV1,
} from "../connect/index.js";

it("binds an MCP lease to one host, generation, caller and exact body", () => {
  const seed = new Uint8Array(32).fill(7);
  const publicKey = ed25519PublicKeyFromSeed(seed);
  const body = JSON.stringify({ jsonrpc: "2.0", id: 1, method: "tools/call", params: { name: "t3_thread_list", arguments: {} } });
  const now = 1_800_000_000;
  const claims = {
    iss: "https://connect.kombify.io", aud: "t3-env:env-1", sub: "auth0|owner", iat: now, exp: now + 60, jti: "lease-1",
    environmentId: "env-1", orgId: "org-1", method: "POST", path: "/mcp", capability: "workbench.host.use", form: "mcp",
    caller: { kind: "agent", agentInstanceId: "hi_companion", runId: "run-1" }, requestId: "req-1", commandId: "req-1",
    bodyDigest: workbenchHostMcpBodyDigestV1(body),
    kombify_connect: { installation_id: "inst-1", installation_epoch: 1, grant_id: "grt-1", grant_revision: 1, grant_version: 1,
      host_generation: 3, profile: "full-environment", capabilities: ["terminal"], t3_scopes: ["orchestration:read"], session_expires_at: now + 900 },
  } as const;
  const token = signWorkbenchHostMcpLeaseV1({ seed, claims });
  const check = (overrides: Record<string, unknown>) => verifyWorkbenchHostMcpLeaseV1({
    token, publicKey, issuer: claims.iss, environmentId: "env-1", hostGeneration: 3, body, now: now + 1, ...overrides });
  expect(check({})).toMatchObject({ ok: true, claims: { caller: { kind: "agent", runId: "run-1" } } });
  expect(check({ body: body.replace("t3_thread_list", "t3_thread_send") })).toEqual({ ok: false, reason: "workbench_host_mcp_lease_body" });
  expect(check({ hostGeneration: 4 })).toEqual({ ok: false, reason: "workbench_host_mcp_lease_generation" });
  expect(check({ environmentId: "env-2" })).toEqual({ ok: false, reason: "workbench_host_mcp_lease_audience" });
  expect(check({ now: now + 61 })).toEqual({ ok: false, reason: "workbench_host_mcp_lease_expired" });
  expect(check({ now: now + 61, allowExpired: true, body: undefined }).ok).toBe(true);
  expect(check({ publicKey: ed25519PublicKeyFromSeed(new Uint8Array(32).fill(8)) })).toEqual({ ok: false, reason: "workbench_host_mcp_lease_invalid" });
  expect(() => signWorkbenchHostMcpLeaseV1({ seed, claims: { ...claims, exp: now + 61 } })).toThrow();
});
