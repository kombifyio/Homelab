import { describe, expect, it } from "vitest";

import {
  agentModelDocumentDigestV1,
  agentModelPinsDigestV3,
  agentRoleTemplateDigestV3,
  agentRoleTemplateIdV3,
  agentRoleTemplateVersionV3,
  composeAgentAuthorityV2,
  composeAgentRoleTemplateV3,
  mapAgentAreaIndexV1,
  mapAgentPositionV1,
  mapAgentRoleV4,
  mapAgentRoleTemplateV3,
  mapFactoryProfileV1,
  mapOfficeProfileV2,
  parseAgentRoleTemplateV3,
  type AgentRoleTemplateV3,
} from "./index.js";
import {
  FIRST_PARTY_AREA_MODEL,
  areaModelCatalog,
  areaModelReferenceErrors,
  composeFirstPartyRoleTemplateV3,
  describeRoleInOffice,
} from "./agent-model-catalog/area-model.js";

import areaIndexJson from "./agent-model-catalog/agent-area-index.json";
import managerRoleJson from "./agent-model-catalog/agent-role.v4.manager.json";
import paperworkFactoryJson from "./agent-model-catalog/factory-profile.paperwork.json";
import mailOfficeJson from "./agent-model-catalog/office-profile.v2.paperwork.mail.json";
import companionJson from "./agent-model-catalog/agent-position.companion.json";
import workspaceTemplates from "./test-fixtures/agent-role-template.v3.workspace.json";

// The records of the workspace contract fixtures (`kombify-workspace` PR #5774,
// `internal/standards-enforcement/agent-model-fixtures/`), copied byte for byte.
const model = areaModelCatalog();
const role = (roleId: string) => model.roles.find((entry) => entry.roleId === roleId)!;
const office = (officeId: string, factoryId = "paperwork") =>
  model.offices.find((entry) => entry.factoryId === factoryId && entry.officeId === officeId)!;
const factory = (factoryId: string) =>
  model.factories.find((entry) => entry.factoryId === factoryId)!;
const permanent = model.typeProfiles.find((type) => type.agentType === "permanent")!;

describe("the bundled area model", () => {
  it("loads with every record verified against the digest it carries", () => {
    expect(model).toBe(FIRST_PARTY_AREA_MODEL);
    expect(model.roles.map((entry) => entry.roleId)).toEqual([
      "researcher",
      "drafter",
      "specialist",
      "manager",
    ]);
    expect(model.factories.map((entry) => entry.factoryId).sort()).toEqual([
      "build-factory",
      "paperwork",
      "ril-ops",
    ]);
    expect(model.offices).toHaveLength(9);
    expect(model.positions.map((entry) => entry.positionId).sort()).toEqual([
      "companion",
      "coordinator.build-factory",
      "coordinator.paperwork",
      "coordinator.ril-ops",
      "support.l1",
      "support.l2",
      "support.l3",
    ]);
    expect(model.areaIndex.areas).toHaveLength(68);
    expect(areaModelReferenceErrors(model)).toEqual([]);
  });

  it("computes the digests the workspace contract check carries", () => {
    // Pinned literals of the workspace fixtures: a drifted copy changes one of them.
    expect(model.areaIndex.digest).toBe(
      "sha256:9bef96e7134d3c31cbe0bb3752be4789cbe33179480b07e28975d179d9533c5b",
    );
    expect(role("manager").digest).toBe(
      "sha256:bf86def071d6f7edbd3648e5f8c0c1a70e50d0fd52d720eb0f9e08fcb5c1aefb",
    );
    expect(role("drafter").digest).toBe(
      "sha256:4ac0fb68b85d8b1bc4714fa333c36d9d434954c31c1506ec278ed9dd4ea12495",
    );
    expect(factory("paperwork").digest).toBe(
      "sha256:b1c5f324bfae98bf5a68d9be5b773bd624046323bfc01f84b405342f97fded11",
    );
    expect(office("mail").digest).toBe(
      "sha256:8045f92c0b046e14d8d9a23a56efa1dfeda0e7fc42277f6a04e2812efb4495ff",
    );
    expect(model.positions.find((p) => p.id === "companion")!.digest).toBe(
      "sha256:d1b8a2e2d46f8be068f4c14bede9611b61b3001aa8882ac76c4b86a29d0f54e5",
    );
    expect(model.positions.find((p) => p.id === "coordinator.paperwork")!.digest).toBe(
      "sha256:78ad056f9973cbb3c3e077b095843ebd2afd12171bd5cf48e00a7edfc00c1849",
    );
    for (const record of [
      areaIndexJson,
      managerRoleJson,
      paperworkFactoryJson,
      mailOfficeJson,
      companionJson,
    ]) {
      expect(agentModelDocumentDigestV1(record as never)).toBe(record.digest);
    }
  });

  it("refuses a record that lies about its digest or carries an unknown field", () => {
    const stale = { ...mailOfficeJson, digest: `sha256:${"0".repeat(64)}` };
    expect(() => mapOfficeProfileV2({ ...stale, alsoActiveIn: ["b.x", "a.x"] })).toThrow(/sorted/);
    expect(() => mapOfficeProfileV2({ ...mailOfficeJson, extra: true })).toThrow(/unknown field/);
    expect(() => mapAgentRoleV4({ ...managerRoleJson, office: "release" })).toThrow(/office/);
    // helpers.max and quota.helpers must agree, and a role without helpers hands on nothing.
    expect(() =>
      mapAgentRoleV4({ ...managerRoleJson, quota: { ...managerRoleJson.quota, helpers: 1 } }),
    ).toThrow(/quota\.helpers/);
    expect(() =>
      mapAgentRoleV4({
        ...managerRoleJson,
        helpers: { max: 0, handOn: "held", answer: "none" },
        requires: [],
        quota: { ...managerRoleJson.quota, helpers: 0 },
      }),
    ).toThrow(/hands on/);
    expect(() => mapAgentPositionV1({ ...companionJson, present: "factory" })).toThrow(/factoryId/);
    expect(() => mapFactoryProfileV1({ ...paperworkFactoryJson, suggestedTools: {} })).toThrow();
    // Area kinds name exactly what their kind allows.
    const areas = structuredClone(areaIndexJson) as unknown as { areas: Record<string, unknown>[] };
    areas.areas[0] = { ...areas.areas[0], factoryId: "paperwork" };
    expect(() => mapAgentAreaIndexV1(areas)).toThrow(/names no Factory/);
  });

  it("reports a broken copy as the workspace check does", () => {
    const broken = {
      ...model,
      offices: model.offices.map((entry) =>
        entry.officeId === "mail"
          ? { ...entry, alsoActiveIn: [...entry.alsoActiveIn, "paperwork.nowhere"] }
          : entry,
      ),
    };
    expect(areaModelReferenceErrors(broken).join("\n")).toMatch(/unknown area paperwork\.nowhere/);
    const noOffice = {
      ...model,
      offices: model.offices.filter((entry) => entry.officeId !== "meetings"),
    };
    expect(areaModelReferenceErrors(noOffice).join("\n")).toMatch(
      /has no office-profile\.v2 record/,
    );
  });
});

describe("composeAgentAuthorityV2 in the Paperwork Mail Office", () => {
  const paperworkAreas = [
    "baseline.knowledge",
    "paperwork.automations",
    "paperwork.documents",
    "paperwork.lists",
    "paperwork.mail",
    "paperwork.meetings",
    "paperwork.notes",
    "paperwork.setup",
    "paperwork.tags",
  ];
  const compose = (roleId: string) =>
    composeAgentAuthorityV2(role(roleId), factory("paperwork"), office("mail"), model.areaIndex);
  const homeAndNeighbours = [
    "paperwork.automations",
    "paperwork.documents",
    "paperwork.lists",
    "paperwork.mail",
    "paperwork.tags",
  ];

  it("makes the Researcher present everywhere in the Factory and active nowhere", () => {
    const composed = compose("researcher");
    expect(composed.present).toEqual(paperworkAreas);
    expect(composed.active).toEqual([]);
    expect(composed.sandboxAllowed).toBe(false);
    expect(composed.helpers).toEqual({ max: 0, handOn: "none", answer: "none" });
    expect(composed.resource).toEqual({
      dimension: "paperwork.mailbox",
      areas: ["paperwork.automations", "paperwork.mail"],
    });
  });

  it("makes the Drafter active for reversible writes in mail, automations and the neighbouring areas", () => {
    const composed = compose("drafter");
    expect(composed.present).toEqual(paperworkAreas);
    expect(composed.active).toEqual(
      homeAndNeighbours.map((area) => ({ area, writes: "reversible" })),
    );
    expect(composed.sandboxAllowed).toBe(false);
  });

  it("makes the Specialist active for all writes in the same areas", () => {
    const composed = compose("specialist");
    expect(composed.active).toEqual(homeAndNeighbours.map((area) => ({ area, writes: "all" })));
    expect(composed.sandboxAllowed).toBe(true);
    expect(composed.helpers.max).toBe(0);
  });

  it("gives the Manager helpers it hands on to and answers for", () => {
    const composed = compose("manager");
    expect(composed.active).toEqual(homeAndNeighbours.map((area) => ({ area, writes: "all" })));
    expect(composed.helpers).toEqual({ max: 2, handOn: "held", answer: "helpers" });
    expect(composed.sandboxAllowed).toBe(true);
    expect(composed.loadout.suggestedTools).toEqual(["tool.web-search"]);
    expect(composed.loadout.device?.definitions.map((definition) => definition.id)).toEqual([
      "device.app.files",
      "device.runtime",
    ]);
  });

  it("describes a role in an Office and refuses unknown ids", () => {
    const view = describeRoleInOffice("manager", "paperwork", "mail");
    expect(view.authority.active.map((entry) => entry.area)).toContain("paperwork.documents");
    // A Manager needs helpers, which every creatable type provides here.
    expect(view.allowedTypes.map((type) => type.agentType)).toEqual([
      "permanent",
      "expert",
      "ad-hoc",
    ]);
    expect(view.allowedTypes.every((type) => type.provides.includes("helpers"))).toBe(true);
    expect(() => describeRoleInOffice("manager", "paperwork", "nowhere")).toThrow(/no Office/);
    expect(() => describeRoleInOffice("boss", "paperwork", "mail")).toThrow(/Unknown agent role/);
  });

  it("refuses records that do not fit together", () => {
    expect(() =>
      composeAgentAuthorityV2(role("manager"), factory("ril-ops"), office("mail"), model.areaIndex),
    ).toThrow(/belongs to Factory/);
    expect(() =>
      composeAgentAuthorityV2(
        role("manager"),
        factory("paperwork"),
        { ...office("mail"), alsoActiveIn: ["homelab.server"] },
        model.areaIndex,
      ),
    ).toThrow(/not an office or factory area/);
    expect(() =>
      composeAgentAuthorityV2(
        role("manager"),
        factory("paperwork"),
        { ...office("mail"), alsoActiveIn: ["paperwork.mail"] },
        model.areaIndex,
      ),
    ).toThrow(/own home area/);
    expect(() =>
      composeAgentAuthorityV2(
        role("manager"),
        {
          ...factory("paperwork"),
          suggestedTools: { ...factory("paperwork").suggestedTools, manager: ["paperwork.mail"] },
        },
        office("mail"),
        model.areaIndex,
      ),
    ).toThrow(/not a tool area/);
  });
});

describe("the role template v3 projection", () => {
  const sortedUnique = (values: string[]) => [...new Set(values)].sort();

  it("carries the digest the workspace check script computes for every role in every Office", () => {
    expect(workspaceTemplates).toHaveLength(36);
    for (const reference of workspaceTemplates) {
      // 1. Digest function: the workspace's document parses here, digest included.
      const parsed = parseAgentRoleTemplateV3(reference);
      expect(agentRoleTemplateDigestV3(parsed)).toBe(reference.digest);
      // 2. Composition: ours is the workspace's, field for field, once the four
      //    values its example fixes (version suffix, label, lease horizon,
      //    knowledge tier) are the workspace's. Ours follow the v2 projection's
      //    rules: the role's label, the type's lease horizon, KT2 for a role that writes.
      const mine = composeAgentRoleTemplateV3({
        role: role(reference.roleId),
        type: permanent,
        factory: factory(reference.factoryId),
        office: office(reference.officeId, reference.factoryId),
        areaIndex: model.areaIndex,
      });
      const aligned = {
        ...mine,
        version: reference.version,
        label: reference.label,
        durableTtlSeconds: reference.durableTtlSeconds,
        knowledgeTier: reference.knowledgeTier,
      };
      const { digest: _digest, lifecycle: _lifecycle, trustClass: _trust, ...authored } = aligned;
      expect(agentRoleTemplateDigestV3(authored as never)).toBe(reference.digest);
      const {
        digest: _d,
        lifecycle: _l,
        trustClass: _t,
        ...referenceAuthored
      } = reference as unknown as Record<string, unknown>;
      expect(authored).toEqual(referenceAuthored);
      expect(mine.id).toBe(reference.id);
    }
  });

  it("composes first-party templates with the id and version scheme of the v2 projection", () => {
    const template = composeFirstPartyRoleTemplateV3("drafter", "paperwork", "mail", "permanent");
    expect(template.id).toBe("role.drafter.paperwork.mail.permanent");
    expect(
      agentRoleTemplateIdV3({
        roleId: "drafter",
        factoryId: "paperwork",
        officeId: "mail",
        agentType: "permanent",
      }),
    ).toBe(template.id);
    expect(template.version).toMatch(/^2\.0\.0\+pins\.[0-9a-f]{64}$/);
    const pins = {
      roleDigest: role("drafter").digest,
      typeProfileDigest: permanent.digest,
      factoryProfileDigest: factory("paperwork").digest,
      officeProfileDigest: office("mail").digest,
      areaIndexDigest: model.areaIndex.digest,
    };
    expect(template.version).toBe(agentRoleTemplateVersionV3("2.0.0", pins));
    // Any record moving moves the version, nothing else does.
    expect(
      agentModelPinsDigestV3({ ...pins, areaIndexDigest: `sha256:${"1".repeat(64)}` }),
    ).not.toBe(agentModelPinsDigestV3(pins));
    expect(template.authority.present).toEqual(sortedUnique(template.authority.present));
    expect(template.authority.active.every((entry) => entry.writes === "reversible")).toBe(true);
    expect(template.knowledgeTier).toBe("KT2");
    expect(
      composeFirstPartyRoleTemplateV3("researcher", "paperwork", "mail", "permanent").knowledgeTier,
    ).toBe("KT1");
    expect(template.lifecycle).toBe("active");
    // Notes is a preview Office: the projection is as available as its weakest record.
    expect(
      composeFirstPartyRoleTemplateV3("manager", "paperwork", "notes", "permanent").lifecycle,
    ).toBe("preview");
    expect(template.spawnDepth).toBe(0);
    expect(
      composeFirstPartyRoleTemplateV3("manager", "paperwork", "mail", "permanent"),
    ).toMatchObject({
      spawnDepth: 1,
      maxChildren: 2,
      baseAgentId: "paperwork-mail-expert",
    });
  });

  it("composes the same bytes every time and holds no definition id", () => {
    const first = composeFirstPartyRoleTemplateV3("specialist", "paperwork", "documents", "expert");
    const second = composeFirstPartyRoleTemplateV3(
      "specialist",
      "paperwork",
      "documents",
      "expert",
    );
    expect(JSON.stringify(first)).toBe(JSON.stringify(second));
    expect(first.digest).toBe(second.digest);
    expect(JSON.stringify(first.authority)).not.toMatch(/paperwork\.mail\.send/);
    expect(Object.keys(first)).not.toContain("authorityDefaults");
  });

  it("is parsed fail closed and refuses a template whose digest lies", () => {
    const template = composeFirstPartyRoleTemplateV3(
      "manager",
      "build-factory",
      "website",
      "permanent",
    );
    expect(parseAgentRoleTemplateV3(JSON.parse(JSON.stringify(template)))).toEqual(template);
    const tampered: AgentRoleTemplateV3 = {
      ...template,
      authority: { ...template.authority, present: [...template.authority.present, "zzz.extra"] },
    };
    expect(() => parseAgentRoleTemplateV3(tampered)).toThrow(/digest/);
    expect(() => mapAgentRoleTemplateV3({ ...template, authorityDefaults: { use: [] } })).toThrow(
      /unknown field/,
    );
    expect(() =>
      mapAgentRoleTemplateV3({
        ...template,
        authority: {
          ...template.authority,
          active: [{ area: "paperwork.mail", writes: "everything" }],
        },
      }),
    ).toThrow(/authority\.active/);
    expect(() =>
      mapAgentRoleTemplateV3({ ...template, schemaVersion: "kombify.agent-role-template.v2" }),
    ).toThrow(/schemaVersion/);
  });
});
