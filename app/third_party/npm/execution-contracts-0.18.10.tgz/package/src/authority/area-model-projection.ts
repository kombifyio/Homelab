/**
 * The area projection: `kombify.agent-role-template.v3`.
 *
 * Composes a role v4, a type profile, a Factory profile, an Office profile v2
 * and the area index into the one template a spawn pins and the Gateway reads
 * (same id scheme `role.<roleId>.<factoryId>.<officeId>.<agentType>` and the
 * same version scheme as the v2 role projection: the role's semver plus build
 * metadata that binds the records the projection is composed from).
 *
 * Package A2 cut the spawn over: `services/agents` composes this template for
 * every new role spawn (`agent-role-spawn.ts`) and serves frozen v2 projections
 * only for pins that resolved before. See `area-model.ts`.
 *
 * Needs the digest, so it is kept apart from the pure `area-model.ts` that
 * clients bundle.
 */

import { agentModelDocumentDigestV1 } from "./agent-model-digest.js";
import type { AgentTypeProfileV1 } from "./agent-model.js";
import {
  AGENT_ROLE_TEMPLATE_SCHEMA_VERSION_V3,
  composeAgentAuthorityV2,
  mapAgentRoleTemplateV3,
  type AgentAreaIndexV1,
  type AgentRoleTemplateV3,
  type AgentRoleV4,
  type FactoryProfileV1,
  type OfficeProfileV2,
} from "./area-model.js";
import { canonicalAuthorityDigestV2 } from "./contract.js";
import type { AgentRoleTemplateLifecycleV1 } from "./agent-model-kit.js";

const TEMPLATE_PREFIX = "role";
const PINS_DIGEST_DOMAIN_V2 = "kombify.agent-role-projection.pins.v2";

/** The five records one template v3 is composed from, by digest. */
export interface AgentModelPinsV3 {
  roleDigest: string;
  typeProfileDigest: string;
  factoryProfileDigest: string;
  officeProfileDigest: string;
  areaIndexDigest: string;
}

/** One digest over the five record digests, the build metadata of the projection version. */
export function agentModelPinsDigestV3(pins: AgentModelPinsV3): string {
  return canonicalAuthorityDigestV2(PINS_DIGEST_DOMAIN_V2, {
    roleDigest: pins.roleDigest,
    typeProfileDigest: pins.typeProfileDigest,
    factoryProfileDigest: pins.factoryProfileDigest,
    officeProfileDigest: pins.officeProfileDigest,
    areaIndexDigest: pins.areaIndexDigest,
  });
}

/** `<role.version>+pins.<hex of the pins digest>`: any of the five records moving moves the version. */
export function agentRoleTemplateVersionV3(roleVersion: string, pins: AgentModelPinsV3): string {
  return `${roleVersion}+pins.${agentModelPinsDigestV3(pins).slice("sha256:".length)}`;
}

/** `role.<roleId>.<factoryId>.<officeId>.<agentType>`; every part is a dot-free catalog id. */
export function agentRoleTemplateIdV3(input: {
  roleId: string;
  factoryId: string;
  officeId: string;
  agentType: string;
}): string {
  return [TEMPLATE_PREFIX, input.roleId, input.factoryId, input.officeId, input.agentType].join(
    ".",
  );
}

const LIFECYCLE_ORDER: Readonly<Record<AgentRoleTemplateLifecycleV1, number>> = {
  active: 0,
  preview: 1,
  draft: 2,
  revoked: 3,
};

/** The least available lifecycle of the composed records; a template is as published as its weakest part. */
function weakestLifecycle(
  records: readonly { lifecycle: AgentRoleTemplateLifecycleV1 }[],
): AgentRoleTemplateLifecycleV1 {
  return records
    .map((record) => record.lifecycle)
    .reduce((weakest, next) => (LIFECYCLE_ORDER[next] > LIFECYCLE_ORDER[weakest] ? next : weakest));
}

export interface AgentRoleTemplateV3Input {
  role: AgentRoleV4;
  type: AgentTypeProfileV1;
  factory: FactoryProfileV1;
  office: OfficeProfileV2;
  areaIndex: AgentAreaIndexV1;
}

export function agentModelPinsV3Of(input: AgentRoleTemplateV3Input): AgentModelPinsV3 {
  return {
    roleDigest: input.role.digest,
    typeProfileDigest: input.type.digest,
    factoryProfileDigest: input.factory.digest,
    officeProfileDigest: input.office.digest,
    areaIndexDigest: input.areaIndex.digest,
  };
}

/**
 * Compose the template v3 of one role in one Office as one type. Deterministic;
 * the digest binds the composed content, the version binds the five records.
 * Throws as `composeAgentAuthorityV2` does when the records do not fit.
 */
export function composeAgentRoleTemplateV3(input: AgentRoleTemplateV3Input): AgentRoleTemplateV3 {
  const { role, type, factory, office, areaIndex } = input;
  const composed = composeAgentAuthorityV2(role, factory, office, areaIndex);
  const maxTtlSeconds = type.lifetime.kind === "bounded" ? type.lifetime.maxTtlSeconds : undefined;
  const authored = {
    schemaVersion: AGENT_ROLE_TEMPLATE_SCHEMA_VERSION_V3,
    id: agentRoleTemplateIdV3({
      roleId: role.roleId,
      factoryId: office.factoryId,
      officeId: office.officeId,
      agentType: type.agentType,
    }),
    version: agentRoleTemplateVersionV3(role.version, agentModelPinsV3Of(input)),
    publisher: { ...role.publisher },
    roleId: role.roleId,
    factoryId: office.factoryId,
    officeId: office.officeId,
    agentType: type.agentType,
    label: role.label.en,
    description: role.description.en,
    baseAgentId: office.standardAgent.baseAgentId,
    authority: {
      present: composed.present,
      active: composed.active,
      resource: composed.resource,
      helpers: composed.helpers,
    },
    loadout: composed.loadout,
    sandboxAllowed: composed.sandboxAllowed,
    budget: {
      tokens: role.quota.tokenBudget,
      maxActiveLeases: role.quota.concurrentLeases,
      maxEquippedDefinitions: role.quota.loadoutCapacity,
    },
    // The type's routine-read lease horizon; a task-bound type holds its
    // leases for the task, which is its lifetime (as the v2 projection).
    durableTtlSeconds: type.routineReadLeaseSeconds ?? 3600,
    ...(maxTtlSeconds === undefined ? {} : { maxTtlSeconds }),
    // A read-out, not a setting: KT2 for a role that writes, else KT1 (as the v2 projection).
    knowledgeTier: role.office === "present" ? "KT1" : "KT2",
    spawnDepth: role.helpers.max > 0 ? 1 : 0,
    maxChildren: role.helpers.max,
    executionClass: "kombify-generic-host",
  } as const;
  return mapAgentRoleTemplateV3({
    ...authored,
    digest: agentModelDocumentDigestV1(authored),
    lifecycle: weakestLifecycle([role, type, factory, office, areaIndex]),
    trustClass: "catalog-verified",
  });
}

/** Parse a template v3 and recompute its digest: a template that lies about itself is refused. */
export function parseAgentRoleTemplateV3(raw: unknown): AgentRoleTemplateV3 {
  const template = mapAgentRoleTemplateV3(raw);
  const computed = agentModelDocumentDigestV1(template);
  if (template.digest !== computed) {
    throw new TypeError(
      `AgentRoleTemplateV3 ${template.id} is invalid: digest ${template.digest} does not match ${computed}`,
    );
  }
  return template;
}
