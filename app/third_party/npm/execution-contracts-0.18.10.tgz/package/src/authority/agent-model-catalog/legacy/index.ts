/**
 * Frozen legacy role projections (`kombify.agent-role-template.v2`).
 *
 * Every v2 role projection that resolved when the area model was introduced:
 * the current roles and every superseded role record, in every Office and for
 * every agent type (and the pre-rename Homelab server Office), each with id, version, digest and the full projection.
 * `scripts/freeze-role-projections.mjs` (now only a verifier) wrote `role-projections.v2.json` from
 * the class composer of `services/agents`, which package A2 removes; this
 * table is what keeps every pin that resolved then resolving byte for byte
 * afterwards (D-2026-11-20-06 design step 3.2). It is history, not a
 * contract: it lives only in this repository and is deleted together with the
 * v2 role-projection handling at the contract step.
 *
 * `withRoleProjections`, `roleProjectionVersionForDigest` and
 * `pinnedRoleProjectionVersion` in `services/agents` answer legacy pins from it
 * (package A2). The table also holds the Homelab server projections composed
 * against the Factory binding and Office profile as they were before the
 * Techstack to Homelab rename (36 of 324 entries; `legacy/records/` keeps those two
 * records byte for byte): their digests moved with the rename, so agents pinned
 * before it had stopped resolving.
 *
 * Loading is lazy and cached: the first call parses the JSON and re-verifies
 * every entry with `parseAgentRoleTemplateV2` (schema and digest), so a Worker
 * that never reads a legacy pin pays nothing. A table that fails its own
 * verification throws, naming the entry.
 */

import { parseAgentRoleTemplateV2 } from "../../contract.js";
import type { AgentRoleTemplateV2 } from "../../types.js";

import table from "./role-projections.v2.json";

export const FROZEN_ROLE_PROJECTIONS_SCHEMA = "kombify.frozen-role-projections.v2";

/** One frozen projection: the identity a pin names, and the document it resolves to. */
export interface FrozenRoleProjectionV2 {
  readonly id: string;
  readonly version: string;
  readonly digest: string;
  readonly document: AgentRoleTemplateV2;
}

export interface FrozenRoleProjectionsV2 {
  readonly source: { readonly repository: string; readonly commit: string };
  /** The number of projections the freeze found; the loader refuses a table of another size. */
  readonly count: number;
  /** Sorted by id, then version. */
  readonly projections: readonly FrozenRoleProjectionV2[];
}

const ROLE_PROJECTION_ID = /^role\.[^.]+\.[^.]+\.[^.]+\.[^.]+$/;

/** Verify a table of frozen projections; the loader runs it on the bundled one. Throws naming the entry. */
export function verifyFrozenRoleProjectionsV2(raw: unknown): FrozenRoleProjectionsV2 {
  const input = raw as {
    schema?: unknown;
    source?: { repository?: unknown; commit?: unknown };
    count?: unknown;
    projections?: unknown;
  };
  if (input.schema !== FROZEN_ROLE_PROJECTIONS_SCHEMA) {
    throw new TypeError("Frozen role projections: unknown schema.");
  }
  if (!Array.isArray(input.projections) || input.projections.length !== input.count) {
    throw new TypeError("Frozen role projections: count differs from the entries.");
  }
  const source = input.source;
  if (typeof source?.repository !== "string" || typeof source.commit !== "string") {
    throw new TypeError("Frozen role projections: source is missing.");
  }
  const seen = new Set<string>();
  let previous = "";
  const projections = input.projections.map((entry: unknown): FrozenRoleProjectionV2 => {
    const item = entry as { id?: unknown; version?: unknown; digest?: unknown; document?: unknown };
    const where = `${String(item.id)}@${String(item.version)}`;
    if (typeof item.id !== "string" || !ROLE_PROJECTION_ID.test(item.id)) {
      throw new TypeError(`Frozen role projection ${where}: not a role projection id.`);
    }
    if (typeof item.version !== "string" || typeof item.digest !== "string") {
      throw new TypeError(`Frozen role projection ${where}: version and digest are required.`);
    }
    let document: AgentRoleTemplateV2;
    try {
      // The one schema and digest authority of the v2 projection.
      document = parseAgentRoleTemplateV2(item.document);
    } catch (error) {
      throw new TypeError(
        `Frozen role projection ${where}: ${error instanceof Error ? error.message : "invalid"}`,
        { cause: error },
      );
    }
    if (
      document.id !== item.id ||
      document.version !== item.version ||
      document.digest !== item.digest
    ) {
      throw new TypeError(
        `Frozen role projection ${where}: id, version and digest differ from the document.`,
      );
    }
    const key = `${item.id}@${item.version}`;
    if (seen.has(key)) throw new TypeError(`Frozen role projection ${key} is declared twice.`);
    seen.add(key);
    if (key < previous) throw new TypeError(`Frozen role projection ${key} is out of order.`);
    previous = key;
    return { id: item.id, version: item.version, digest: item.digest, document };
  });
  return Object.freeze({
    source: { repository: source.repository, commit: source.commit },
    count: input.count as number,
    projections: Object.freeze(projections),
  });
}

let cached: FrozenRoleProjectionsV2 | undefined;

/** The frozen table, parsed and verified on first use. */
export function legacyRoleProjections(): FrozenRoleProjectionsV2 {
  cached ??= verifyFrozenRoleProjectionsV2(table);
  return cached;
}

/**
 * The frozen projection of an exact pin (`templateId` and `version`);
 * `undefined` when none matches. A pin names its version, so there is no
 * "newest" answer: the frozen table holds history, never a current record.
 */
export function findLegacyRoleProjection(
  templateId: string,
  version: string,
): AgentRoleTemplateV2 | undefined {
  return legacyRoleProjections().projections.find(
    (entry) => entry.id === templateId && entry.version === version,
  )?.document;
}

/** The frozen version whose digest is `digest`; `undefined` when none is. */
export function legacyRoleProjectionVersionForDigest(
  templateId: string,
  digest: string,
): string | undefined {
  return legacyRoleProjections().projections.find(
    (entry) => entry.id === templateId && entry.digest === digest,
  )?.version;
}
