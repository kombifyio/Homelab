/**
 * First-party agent model catalog: the three type profiles, the four roles,
 * one Factory binding per Factory and the eight Office profiles
 * (`DECISION-RECORD-2026-09-25-agent-model-type-role-factory-office.md`,
 * `AGENT-CAPABILITY-PROVISIONING-STANDARD.md` §3c).
 *
 * The JSON files next to this module mirror the kombify-workspace contract
 * fixtures in `internal/standards-enforcement/agent-model-fixtures/`, which
 * stay the source of truth; refresh them by copying byte for byte, never by
 * editing here. Loading this module recomputes every digest, refuses a
 * record whose carried digest differs, parses each record with the agent
 * model mappers and checks references between records. Any failure throws at
 * import: a partially valid catalog would offer roles it cannot explain.
 *
 * Older role records an agent may have been hired against no longer live here: every
 * projection of them that resolved when the area model was introduced is frozen in
 * `legacy/role-projections.v2.json` (history, not a contract), which answers those pins.
 * This class model remains as the display model the roles route still serves to its
 * consumers; nothing composes a spawn from it.
 *
 * Kept out of the `authority` entry so importing the contracts alone does not
 * pay for loading and verifying the catalog.
 */

import {
  allowedAgentTypes,
  composeAgentAuthority,
  mapAgentConnectorCatalogV1,
  mapAgentRoleV3,
  mapAgentTypeProfileV1,
  mapFactoryRoleBindingV1,
  mapOfficeProfileV1,
  offeredRoles,
  type AgentConnectorCatalogV1,
  type AgentRoleV3,
  type AgentTypeProfileV1,
  type ComposedAgentAuthorityV1,
  type FactoryRoleBindingV1,
  type OfficeProfileV1,
} from "../agent-model.js";
import { unique, verified } from "./verified.js";

import connectorCatalog from "./agent-connector-catalog.json";
import drafterRole from "./agent-role.drafter.json";
import managerRole from "./agent-role.manager.json";
import researcherRole from "./agent-role.researcher.json";
import specialistRole from "./agent-role.specialist.json";
import adHocType from "./agent-type-profile.ad-hoc.json";
import expertType from "./agent-type-profile.expert.json";
import permanentType from "./agent-type-profile.permanent.json";
import buildFactoryBinding from "./factory-role-binding.build-factory.json";
import paperworkBinding from "./factory-role-binding.paperwork.json";
import rilOpsBinding from "./factory-role-binding.ril-ops.json";
import workbenchBinding from "./factory-role-binding.workbench.json";
import appsOffice from "./office-profile.build-factory.apps.json";
import slidesOffice from "./office-profile.build-factory.slides.json";
import topicArtifactsOffice from "./office-profile.build-factory.topic-artifacts.json";
import websiteOffice from "./office-profile.build-factory.website.json";
import documentsOffice from "./office-profile.paperwork.documents.json";
import mailOffice from "./office-profile.paperwork.mail.json";
import meetingsOffice from "./office-profile.paperwork.meetings.json";
import serverOffice from "./office-profile.ril-ops.server.json";

export interface AgentModelCatalogV1 {
  readonly typeProfiles: readonly AgentTypeProfileV1[];
  readonly roles: readonly AgentRoleV3[];
  readonly bindings: readonly FactoryRoleBindingV1[];
  readonly offices: readonly OfficeProfileV1[];
  /**
   * The connections roles work with (`AGENT-PLUGINS-STANDARD.md` §12.2g), one
   * document with its own digest, outside every pinned record above.
   */
  readonly connectors?: AgentConnectorCatalogV1;
}

const writes = (entries: readonly { level: string }[] | undefined) =>
  entries?.some((entry) => entry.level === "write") === true;
const canChange = (role: AgentRoleV3) =>
  role.authority.use.some((cls) => cls === "draft" || cls === "act");

/**
 * A declaration asks for `write` only for a role that can change something
 * here: `draft` or `act` in its `use`, and, for a Factory entry, a class of
 * that kind the Factory binding fills or lets stay empty (`roleOverrides`).
 */
export function checkConnectorReferences(catalog: AgentModelCatalogV1): void {
  const document = catalog.connectors;
  if (!document) return;
  const roleOf = (roleId: string, where: string): AgentRoleV3 => {
    const role = catalog.roles.find((candidate) => candidate.roleId === roleId);
    if (!role) throw new TypeError(`${document.id} ${where} names unknown role ${roleId}.`);
    return role;
  };
  for (const [roleId, entries] of Object.entries(document.roles)) {
    const role = roleOf(roleId, "roles");
    if (writes(entries) && !canChange(role)) {
      throw new TypeError(`${document.id} asks ${roleId} to write, which its role cannot do.`);
    }
  }
  for (const [factoryId, perRole] of Object.entries(document.bindings)) {
    const binding = catalog.bindings.find((candidate) => candidate.factoryId === factoryId);
    if (!binding) throw new TypeError(`${document.id} names unknown Factory ${factoryId}.`);
    for (const [roleId, entries] of Object.entries(perRole)) {
      const role = roleOf(roleId, `bindings.${factoryId}`);
      if (!writes(entries)) continue;
      const emptyAllowed = binding.roleOverrides?.[role.roleId]?.offerWithEmptyClasses ?? [];
      const writable = role.authority.use.some(
        (cls) =>
          (cls === "draft" || cls === "act") &&
          ((binding.classes[cls]?.length ?? 0) > 0 || emptyAllowed.includes(cls)),
      );
      if (!writable) {
        throw new TypeError(
          `${document.id} asks ${roleId} to write in ${factoryId}, where nothing of that kind is classified.`,
        );
      }
    }
  }
}

/** Check what no single mapper can: references between records. */
function checkReferences(catalog: AgentModelCatalogV1): void {
  unique(
    catalog.typeProfiles.map((type) => type.agentType),
    "Agent type",
  );
  unique(
    catalog.roles.map((role) => role.roleId),
    "Role",
  );
  unique(
    catalog.bindings.map((binding) => binding.factoryId),
    "Factory binding",
  );
  unique(
    catalog.offices.map((office) => `${office.factoryId}.${office.officeId}`),
    "Office profile",
  );
  checkConnectorReferences(catalog);
  for (const office of catalog.offices) {
    const binding = catalog.bindings.find((entry) => entry.factoryId === office.factoryId);
    if (!binding) throw new TypeError(`${office.id} has no Factory binding.`);
    const classified = new Set(Object.values(binding.classes).flat());
    const deviceIds = new Set(office.device?.definitions.map((definition) => definition.id) ?? []);
    // Office tools are classified through the binding and device definitions
    // carry their own class; anything else could never pass the role filter.
    const unclassified = [
      ...office.tools.flatMap((tool) => tool.definitionIds),
      ...office.preselect.filter((definitionId) => !deviceIds.has(definitionId)),
    ].find((definitionId) => !classified.has(definitionId));
    if (unclassified) {
      throw new TypeError(
        `${office.id} names ${unclassified}, which ${binding.id} does not classify.`,
      );
    }
    // A device definition classifies itself; the binding must not classify it too.
    const doublyClassified = [...deviceIds].find((definitionId) => classified.has(definitionId));
    if (doublyClassified) {
      throw new TypeError(
        `${office.id} device definition ${doublyClassified} is also classified by ${binding.id}.`,
      );
    }
  }
}

function buildAgentModelCatalog(documents: {
  readonly [Shape in Exclude<keyof AgentModelCatalogV1, "connectors">]-?: readonly unknown[];
} & { readonly connectors: unknown }): AgentModelCatalogV1 {
  const catalog: AgentModelCatalogV1 = Object.freeze({
    typeProfiles: Object.freeze(
      documents.typeProfiles.map((doc) => verified(doc, mapAgentTypeProfileV1)),
    ),
    roles: Object.freeze(documents.roles.map((doc) => verified(doc, mapAgentRoleV3))),
    bindings: Object.freeze(
      documents.bindings.map((doc) => verified(doc, mapFactoryRoleBindingV1)),
    ),
    offices: Object.freeze(documents.offices.map((doc) => verified(doc, mapOfficeProfileV1))),
    connectors: verified(documents.connectors, mapAgentConnectorCatalogV1),
  });
  checkReferences(catalog);
  return catalog;
}

/** The shipped first-party catalog, parsed and verified at module load. */
export const FIRST_PARTY_AGENT_MODEL: AgentModelCatalogV1 = buildAgentModelCatalog({
  typeProfiles: [permanentType, expertType, adHocType],
  roles: [researcherRole, drafterRole, specialistRole, managerRole],
  bindings: [rilOpsBinding, paperworkBinding, buildFactoryBinding, workbenchBinding],
  offices: [
    serverOffice,
    mailOffice,
    documentsOffice,
    meetingsOffice,
    websiteOffice,
    slidesOffice,
    topicArtifactsOffice,
    appsOffice,
  ],
  connectors: connectorCatalog,
});

/** A role seen from one Factory (and Office): the "What this agent can do" view. */
export interface AgentRoleInFactoryV1 {
  /** Whether the Factory offers the role at all (standard §3c, `offeredRoles`). */
  offered: boolean;
  authority: ComposedAgentAuthorityV1;
  /** The type profiles the role may run as. */
  allowedTypes: AgentTypeProfileV1[];
}

/**
 * Describe a first-party role in a Factory and, optionally, one of its
 * Offices. Throws on an id the catalog does not know.
 */
export function describeRoleInFactory(
  roleId: string,
  factoryId: string,
  officeId?: string,
): AgentRoleInFactoryV1 {
  const catalog = FIRST_PARTY_AGENT_MODEL;
  const role = catalog.roles.find((entry) => entry.roleId === roleId);
  if (!role) throw new TypeError(`Unknown agent role ${roleId}.`);
  const binding = catalog.bindings.find((entry) => entry.factoryId === factoryId);
  if (!binding) throw new TypeError(`Unknown Factory ${factoryId}.`);
  let office: OfficeProfileV1 | undefined;
  if (officeId !== undefined) {
    office = catalog.offices.find(
      (entry) => entry.factoryId === factoryId && entry.officeId === officeId,
    );
    if (!office) throw new TypeError(`Factory ${factoryId} has no Office ${officeId}.`);
  }
  return {
    offered: offeredRoles(binding, [role]).length > 0,
    authority: composeAgentAuthority(role, binding, office),
    allowedTypes: allowedAgentTypes(role, catalog.typeProfiles),
  };
}
