/**
 * Load-time verification shared by the catalog loaders: recompute the digest
 * first, so a mapper never sees a record that lies about itself.
 */

import {
  agentModelDocumentDigestV1,
  type AgentModelDocumentV1,
  type AgentModelSchemaVersionV1,
} from "../agent-model-digest.js";

export function verified<T>(document: unknown, map: (raw: unknown) => T): T {
  const carried =
    document && typeof document === "object" && "digest" in document
      ? (document as { digest: unknown }).digest
      : undefined;
  const computed = agentModelDocumentDigestV1(
    document as AgentModelDocumentV1<AgentModelSchemaVersionV1>,
  );
  if (carried !== computed) {
    const id = (document as { id?: unknown }).id;
    throw new TypeError(`${String(id)}: digest ${String(carried)} does not match ${computed}.`);
  }
  return map(document);
}

/** Every id appears once. */
export function unique(ids: readonly string[], shape: string): void {
  const seen = new Set<string>();
  for (const id of ids) {
    if (seen.has(id)) throw new TypeError(`${shape} ${id} is declared twice.`);
    seen.add(id);
  }
}
