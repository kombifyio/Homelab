/**
 * First-party area model catalog: the area index, the four roles v4, one
 * Factory profile per Factory, the nine Office profiles v2 and the seven
 * positions (`DECISION-RECORD-2026-11-20-agent-rights-areas-and-standard-agents.md`).
 *
 * This is the area model BESIDE the class model of `index.ts`, which remains only
 * as the display model of the roles route until its consumers move. It loads on its
 * own, so the Gateway reads it without loading the class records; `services/agents`
 * composes every role spawn from it (package A2).
 *
 * The JSON files next to this module mirror the kombify-workspace contract
 * fixtures in `internal/standards-enforcement/agent-model-fixtures/`, which
 * stay the source of truth; refresh them by copying byte for byte, never by
 * editing here. The type profiles are the same three files `index.ts` loads
 * (an agent type is independent of the model that places it). Loading this
 * module recomputes every digest, refuses a record whose carried digest
 * differs, parses each record with the area model mappers and checks the
 * references between records exactly as the workspace's
 * `check-agent-model-contract.mjs` does. Any failure throws at import.
 */

import { mapAgentTypeProfileV1, type AgentTypeProfileV1 } from "../agent-model.js";
import {
  composeAgentAuthorityV2,
  mapAgentAreaIndexV1,
  mapAgentPositionV1,
  mapAgentRoleV4,
  mapFactoryProfileV1,
  mapOfficeProfileV2,
  officeHomeAreas,
  type AgentAreaIndexV1,
  type AgentPositionV1,
  type AgentRoleV4,
  type ComposedAgentAuthorityV2,
  type FactoryProfileV1,
  type OfficeProfileV2,
} from "../area-model.js";
import { composeAgentRoleTemplateV3 } from "../area-model-projection.js";
import type { AgentRoleTemplateV3 } from "../area-model.js";
import { unique, verified } from "./verified.js";

import areaIndex from "./agent-area-index.json";
import companionPosition from "./agent-position.companion.json";
import buildCoordinatorPosition from "./agent-position.coordinator.build-factory.json";
import paperworkCoordinatorPosition from "./agent-position.coordinator.paperwork.json";
import rilOpsCoordinatorPosition from "./agent-position.coordinator.ril-ops.json";
import supportL1Position from "./agent-position.support.l1.json";
import supportL2Position from "./agent-position.support.l2.json";
import supportL3Position from "./agent-position.support.l3.json";
import drafterRole from "./agent-role.v4.drafter.json";
import managerRole from "./agent-role.v4.manager.json";
import researcherRole from "./agent-role.v4.researcher.json";
import specialistRole from "./agent-role.v4.specialist.json";
import adHocType from "./agent-type-profile.ad-hoc.json";
import expertType from "./agent-type-profile.expert.json";
import permanentType from "./agent-type-profile.permanent.json";
import buildFactoryProfile from "./factory-profile.build-factory.json";
import paperworkFactoryProfile from "./factory-profile.paperwork.json";
import rilOpsFactoryProfile from "./factory-profile.ril-ops.json";
import appsOffice from "./office-profile.v2.build-factory.apps.json";
import slidesOffice from "./office-profile.v2.build-factory.slides.json";
import topicArtifactsOffice from "./office-profile.v2.build-factory.topic-artifacts.json";
import websiteOffice from "./office-profile.v2.build-factory.website.json";
import documentsOffice from "./office-profile.v2.paperwork.documents.json";
import mailOffice from "./office-profile.v2.paperwork.mail.json";
import meetingsOffice from "./office-profile.v2.paperwork.meetings.json";
import notesOffice from "./office-profile.v2.paperwork.notes.json";
import serverOffice from "./office-profile.v2.ril-ops.server.json";

export interface AreaModelCatalogV1 {
  readonly areaIndex: AgentAreaIndexV1;
  readonly typeProfiles: readonly AgentTypeProfileV1[];
  readonly roles: readonly AgentRoleV4[];
  readonly factories: readonly FactoryProfileV1[];
  readonly offices: readonly OfficeProfileV2[];
  readonly positions: readonly AgentPositionV1[];
}

/** The `role v4` of the standard agent of an Office (the Manager). */
const OFFICE_ROLE_ID = "manager";

/**
 * Check what no single mapper can: references between records. The same rules
 * as `areaModelErrors` in the workspace `check-agent-model-contract.mjs`.
 * Returns the messages, so a broken copy can be checked as well.
 */
export function areaModelReferenceErrors(catalog: AreaModelCatalogV1): string[] {
  const out: string[] = [];
  const areas = new Map(catalog.areaIndex.areas.map((area) => [area.id, area]));
  const factories = new Map(catalog.factories.map((factory) => [factory.factoryId, factory]));
  const officeKey = (factoryId: string | undefined, officeId: string | undefined) =>
    `${factoryId}/${officeId}`;
  const officeKeys = new Set(catalog.offices.map((o) => officeKey(o.factoryId, o.officeId)));
  for (const area of areas.values()) {
    if (area.kind === "office" && !officeKeys.has(officeKey(area.factoryId, area.officeId))) {
      out.push(
        `area ${area.id} names the Office ${area.factoryId}/${area.officeId}, which has no office-profile.v2 record`,
      );
    }
    if (
      (area.kind === "office" || area.kind === "factory") &&
      !factories.has(area.factoryId as string)
    ) {
      out.push(
        `area ${area.id} names the Factory ${area.factoryId}, which has no factory-profile record`,
      );
    }
  }
  for (const office of catalog.offices) {
    const homes = officeHomeAreas(catalog.areaIndex, office.factoryId, office.officeId);
    if (homes.length === 0) out.push(`Office ${office.id} has no home area in the index`);
    for (const home of homes) {
      if (areas.get(home)?.resourceDimension !== office.resource.dimension) {
        out.push(
          `Office ${office.id}: home area ${home} binds ${String(areas.get(home)?.resourceDimension)}, the profile ${office.resource.dimension}`,
        );
      }
    }
    if (!factories.has(office.factoryId)) {
      out.push(
        `Office ${office.id} names the Factory ${office.factoryId}, which has no factory-profile record`,
      );
    }
    for (const id of office.alsoActiveIn) {
      const area = areas.get(id);
      if (!area) out.push(`Office ${office.id}: alsoActiveIn names the unknown area ${id}`);
      else if (!["office", "factory"].includes(area.kind) || area.factoryId !== office.factoryId) {
        out.push(
          `Office ${office.id}: alsoActiveIn ${id} is not an office or factory area of ${office.factoryId}`,
        );
      } else if (homes.includes(id)) {
        out.push(`Office ${office.id}: alsoActiveIn lists its own home area ${id}`);
      }
    }
    if (office.standardAgent.roleId !== OFFICE_ROLE_ID) {
      out.push(`Office ${office.id}: the standard agent is not a ${OFFICE_ROLE_ID}`);
    }
    if ((office.factoryId === "build-factory") !== (office.cubi !== undefined)) {
      out.push(`Office ${office.id}: cubi belongs to build-factory Offices only`);
    }
  }
  for (const factory of catalog.factories) {
    if (![...areas.values()].some((area) => area.factoryId === factory.factoryId)) {
      out.push(`Factory ${factory.factoryId} has no area in the index`);
    }
    for (const [roleId, ids] of Object.entries(factory.suggestedTools)) {
      for (const id of ids) {
        if (areas.get(id)?.kind !== "tool") {
          out.push(
            `Factory ${factory.factoryId}: suggestedTools.${roleId} names ${id}, which is not a tool area`,
          );
        }
      }
    }
  }
  for (const position of catalog.positions) {
    if (position.present === "factory") {
      const factory = factories.get(position.factoryId as string);
      if (!factory) {
        out.push(`position ${position.id} is present in the unknown Factory ${position.factoryId}`);
      } else if (
        position.id.startsWith("coordinator.") &&
        factory.coordinatorAgentId !== position.agentId
      ) {
        out.push(
          `position ${position.id}: agent ${position.agentId} is not the coordinator of ${position.factoryId} (${factory.coordinatorAgentId})`,
        );
      }
    }
  }
  for (const factory of factories.values()) {
    if (
      !catalog.positions.some(
        (position) =>
          position.id === `coordinator.${factory.factoryId}` &&
          position.agentId === factory.coordinatorAgentId,
      )
    ) {
      out.push(
        `Factory ${factory.factoryId} has no coordinator position for ${factory.coordinatorAgentId}`,
      );
    }
  }
  return out;
}

function buildAreaModelCatalog(documents: {
  readonly areaIndex: unknown;
  readonly typeProfiles: readonly unknown[];
  readonly roles: readonly unknown[];
  readonly factories: readonly unknown[];
  readonly offices: readonly unknown[];
  readonly positions: readonly unknown[];
}): AreaModelCatalogV1 {
  const catalog: AreaModelCatalogV1 = Object.freeze({
    areaIndex: verified(documents.areaIndex, mapAgentAreaIndexV1),
    typeProfiles: Object.freeze(
      documents.typeProfiles.map((doc) => verified(doc, mapAgentTypeProfileV1)),
    ),
    roles: Object.freeze(documents.roles.map((doc) => verified(doc, mapAgentRoleV4))),
    factories: Object.freeze(documents.factories.map((doc) => verified(doc, mapFactoryProfileV1))),
    offices: Object.freeze(documents.offices.map((doc) => verified(doc, mapOfficeProfileV2))),
    positions: Object.freeze(documents.positions.map((doc) => verified(doc, mapAgentPositionV1))),
  });
  unique(
    catalog.roles.map((role) => role.roleId),
    "Role",
  );
  unique(
    catalog.typeProfiles.map((type) => type.agentType),
    "Agent type",
  );
  unique(
    catalog.factories.map((factory) => factory.factoryId),
    "Factory profile",
  );
  unique(
    catalog.offices.map((office) => `${office.factoryId}.${office.officeId}`),
    "Office profile",
  );
  unique(
    catalog.positions.map((position) => position.positionId),
    "Position",
  );
  const errors = areaModelReferenceErrors(catalog);
  if (errors.length > 0) throw new TypeError(`Area model is inconsistent: ${errors.join("; ")}`);
  // Every role in every Office composes: a catalog that cannot compose its own
  // records would offer roles it cannot explain.
  for (const office of catalog.offices) {
    const factory = catalog.factories.find((entry) => entry.factoryId === office.factoryId);
    if (!factory) continue;
    for (const role of catalog.roles)
      composeAgentAuthorityV2(role, factory, office, catalog.areaIndex);
  }
  return catalog;
}

/** The shipped first-party area model, parsed and verified at module load. */
export const FIRST_PARTY_AREA_MODEL: AreaModelCatalogV1 = buildAreaModelCatalog({
  areaIndex,
  typeProfiles: [permanentType, expertType, adHocType],
  roles: [researcherRole, drafterRole, specialistRole, managerRole],
  factories: [rilOpsFactoryProfile, paperworkFactoryProfile, buildFactoryProfile],
  offices: [
    serverOffice,
    mailOffice,
    documentsOffice,
    meetingsOffice,
    notesOffice,
    websiteOffice,
    slidesOffice,
    topicArtifactsOffice,
    appsOffice,
  ],
  positions: [
    companionPosition,
    paperworkCoordinatorPosition,
    rilOpsCoordinatorPosition,
    buildCoordinatorPosition,
    supportL1Position,
    supportL2Position,
    supportL3Position,
  ],
});

/** The bundled, verified area model (`FIRST_PARTY_AREA_MODEL`), as a call like `agentModelCatalog` style readers expect. */
export function areaModelCatalog(): AreaModelCatalogV1 {
  return FIRST_PARTY_AREA_MODEL;
}

/** A role seen from one Factory and Office: the "What this agent can do" view, in areas. */
export interface AgentRoleInOfficeV2 {
  authority: ComposedAgentAuthorityV2;
  /** The type profiles the role may run as. */
  allowedTypes: AgentTypeProfileV1[];
}

function lookup(roleId: string, factoryId: string, officeId: string) {
  const catalog = FIRST_PARTY_AREA_MODEL;
  const role = catalog.roles.find((entry) => entry.roleId === roleId);
  if (!role) throw new TypeError(`Unknown agent role ${roleId}.`);
  const factory = catalog.factories.find((entry) => entry.factoryId === factoryId);
  if (!factory) throw new TypeError(`Unknown Factory ${factoryId}.`);
  const office = catalog.offices.find(
    (entry) => entry.factoryId === factoryId && entry.officeId === officeId,
  );
  if (!office) throw new TypeError(`Factory ${factoryId} has no Office ${officeId}.`);
  return { catalog, role, factory, office };
}

/** Describe a first-party role in one Office, in areas. Throws on an id the catalog does not know. */
export function describeRoleInOffice(
  roleId: string,
  factoryId: string,
  officeId: string,
): AgentRoleInOfficeV2 {
  const { catalog, role, factory, office } = lookup(roleId, factoryId, officeId);
  return {
    authority: composeAgentAuthorityV2(role, factory, office, catalog.areaIndex),
    // The types whose `provides` covers the role's `requires`, derived and never stored.
    allowedTypes: catalog.typeProfiles.filter((type) =>
      role.requires.every((provision) => type.provides.includes(provision)),
    ),
  };
}

/** The template v3 of one first-party role in one Office as one type. Throws on an unknown id. */
export function composeFirstPartyRoleTemplateV3(
  roleId: string,
  factoryId: string,
  officeId: string,
  agentType: string,
): AgentRoleTemplateV3 {
  const { catalog, role, factory, office } = lookup(roleId, factoryId, officeId);
  const type = catalog.typeProfiles.find((entry) => entry.agentType === agentType);
  if (!type) throw new TypeError(`Unknown agent type ${agentType}.`);
  return composeAgentRoleTemplateV3({ role, type, factory, office, areaIndex: catalog.areaIndex });
}
