// Generated from canonical client error schema SHA256 f3c1ef4a62bdcc44a7d4fef199a4512eb591fb208660b862c63b043dc36bd04c.
// Regenerate: node scripts/generate-client-error-contract.mjs.

export type ModelFailureCause = "authentication" | "authorization" | "model_policy" | "funding" | "capacity" | "configuration" | "infrastructure" | "provider";
export type ModelAction = ({
  kind: "retry";
}) | ({
  kind: "sign_in";
}) | ({
  kind: "select_model";
  model_id: string;
}) | ({
  kind: "select_free_model";
  model_id?: string;
}) | ({
  kind: "configure_provider";
  provider_id?: string;
}) | ({
  kind: "use_provider_key";
  provider_id: string;
}) | ({
  kind: "use_model_endpoint";
  endpoint_id: string;
}) | ({
  kind: "manage_plan";
}) | ({
  kind: "buy_ai_boost";
}) | ({
  kind: "contact_support";
});
export type ClientErrorGuidance = {
  title: string;
  body: string;
  next_steps: (string)[];
  localization?: {
  title_message_id: string;
  body_message_id: string;
  next_step_message_ids: (string)[];
  message_params?: Record<string, (string) | (number) | (boolean)>;
};
};
export type ClientErrorLocalization = NonNullable<ClientErrorGuidance["localization"]>;
export type ModelFailureContext = {
  origin?: string;
  route_template?: string;
  profile_binding?: string;
  product?: string;
  workload?: string;
  policy_binding?: string;
  catalog_binding?: string;
  stage: "facts" | "selection" | "reservation" | "provider" | "settlement" | "transport" | "authentication" | "authorization";
  model_id?: string;
  agent_id?: string;
  provider_id?: string;
};
export type ClientErrorEnvelopeV1 = {
  error_code: string;
  reason_code: string;
  request_id?: string;
  capability?: string;
  provider_id?: string;
  required_features?: (string)[];
  missing_features?: (string)[];
  retryable: boolean;
  user_guidance: {
  title: string;
  body: string;
  next_steps: (string)[];
  localization?: {
  title_message_id: string;
  body_message_id: string;
  next_step_message_ids: (string)[];
  message_params?: Record<string, (string) | (number) | (boolean)>;
};
};
  remediation?: string;
  support_context?: Record<string, unknown>;
  cause?: "authentication" | "authorization" | "model_policy" | "funding" | "capacity" | "configuration" | "infrastructure" | "provider";
  retry_after_ms?: number | null;
  reset_at?: string;
  actions?: (({
  kind: "retry";
}) | ({
  kind: "sign_in";
}) | ({
  kind: "select_model";
  model_id: string;
}) | ({
  kind: "select_free_model";
  model_id?: string;
}) | ({
  kind: "configure_provider";
  provider_id?: string;
}) | ({
  kind: "use_provider_key";
  provider_id: string;
}) | ({
  kind: "use_model_endpoint";
  endpoint_id: string;
}) | ({
  kind: "manage_plan";
}) | ({
  kind: "buy_ai_boost";
}) | ({
  kind: "contact_support";
}))[];
};
export type ModelDenial = Omit<ClientErrorEnvelopeV1, "cause" | "request_id" | "capability" | "retry_after_ms" | "actions" | "user_guidance" | "support_context"> & {
 cause: ModelFailureCause; request_id: string; capability: "ai.model-executions" | "ai.agent-runs"; retry_after_ms: number | null; actions: ModelAction[]; user_guidance: ClientErrorGuidance & {localization: ClientErrorLocalization}; support_context: ModelFailureContext;
};
