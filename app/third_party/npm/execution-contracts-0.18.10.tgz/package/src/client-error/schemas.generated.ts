// Generated from canonical client error schema SHA256 f3c1ef4a62bdcc44a7d4fef199a4512eb591fb208660b862c63b043dc36bd04c.
// Regenerate: node scripts/generate-client-error-contract.mjs.
// oxlint-disable unicorn/no-thenable -- JSON Schema keyword.
export const clientErrorSchemaDocuments: Readonly<Record<string, unknown>> = {
  "client-error-envelope.v1.schema.json": {
    "$schema": "https://json-schema.org/draft/2020-12/schema",
    "$id": "https://schemas.kombify.dev/client/v1/error-envelope.schema.json",
    "title": "Kombify Client Error Envelope v1",
    "type": "object",
    "$ref": "#/$defs/envelopeFields",
    "$defs": {
      "envelopeFields": {
        "type": "object",
        "required": [
          "error_code",
          "reason_code",
          "retryable",
          "user_guidance"
        ],
        "properties": {
          "error_code": {
            "type": "string",
            "pattern": "^[a-z][a-z0-9]*(?:[._-][a-z0-9]+)*$"
          },
          "reason_code": {
            "type": "string",
            "pattern": "^[a-z][a-z0-9]*(?:[._-][a-z0-9]+)*$"
          },
          "request_id": {
            "type": "string",
            "minLength": 1,
            "maxLength": 256
          },
          "capability": {
            "type": "string",
            "pattern": "^[a-z][a-z0-9._-]*$"
          },
          "provider_id": {
            "type": "string",
            "minLength": 1,
            "maxLength": 256
          },
          "required_features": {
            "type": "array",
            "uniqueItems": true,
            "items": {
              "type": "string",
              "pattern": "^[a-z][a-z0-9._-]*$"
            }
          },
          "missing_features": {
            "type": "array",
            "uniqueItems": true,
            "items": {
              "type": "string",
              "pattern": "^[a-z][a-z0-9._-]*$"
            }
          },
          "retryable": {
            "type": "boolean"
          },
          "user_guidance": {
            "type": "object",
            "additionalProperties": false,
            "required": [
              "title",
              "body",
              "next_steps"
            ],
            "properties": {
              "title": {
                "type": "string",
                "minLength": 1,
                "maxLength": 160
              },
              "body": {
                "type": "string",
                "minLength": 1,
                "maxLength": 2000
              },
              "next_steps": {
                "type": "array",
                "minItems": 1,
                "maxItems": 8,
                "items": {
                  "type": "string",
                  "minLength": 1,
                  "maxLength": 500
                }
              },
              "localization": {
                "type": "object",
                "additionalProperties": false,
                "required": [
                  "title_message_id",
                  "body_message_id",
                  "next_step_message_ids"
                ],
                "properties": {
                  "title_message_id": {
                    "type": "string",
                    "minLength": 3,
                    "maxLength": 160,
                    "pattern": "^[a-z][a-z0-9]*(?:[._-][a-z0-9]+)+$"
                  },
                  "body_message_id": {
                    "type": "string",
                    "minLength": 3,
                    "maxLength": 160,
                    "pattern": "^[a-z][a-z0-9]*(?:[._-][a-z0-9]+)+$"
                  },
                  "next_step_message_ids": {
                    "type": "array",
                    "minItems": 1,
                    "maxItems": 8,
                    "items": {
                      "type": "string",
                      "minLength": 3,
                      "maxLength": 160,
                      "pattern": "^[a-z][a-z0-9]*(?:[._-][a-z0-9]+)+$"
                    }
                  },
                  "message_params": {
                    "type": "object",
                    "additionalProperties": {
                      "oneOf": [
                        {
                          "type": "string",
                          "maxLength": 512
                        },
                        {
                          "type": "number"
                        },
                        {
                          "type": "boolean"
                        }
                      ]
                    },
                    "maxProperties": 32,
                    "propertyNames": {
                      "pattern": "^[a-z][a-zA-Z0-9_]*$"
                    }
                  }
                }
              }
            }
          },
          "remediation": {
            "type": "string",
            "minLength": 1,
            "maxLength": 2000
          },
          "support_context": {
            "type": "object",
            "additionalProperties": true
          },
          "cause": {
            "enum": [
              "authentication",
              "authorization",
              "model_policy",
              "funding",
              "capacity",
              "configuration",
              "infrastructure",
              "provider"
            ]
          },
          "retry_after_ms": {
            "type": [
              "integer",
              "null"
            ],
            "minimum": 0,
            "maximum": 9007199254740991
          },
          "reset_at": {
            "type": "string",
            "format": "date-time"
          },
          "actions": {
            "type": "array",
            "maxItems": 16,
            "items": {
              "$ref": "#/$defs/action"
            }
          }
        },
        "allOf": [
          {
            "if": {
              "required": [
                "capability"
              ],
              "properties": {
                "capability": {
                  "enum": [
                    "ai.model-executions",
                    "ai.agent-runs"
                  ]
                }
              }
            },
            "then": {
              "required": [
                "cause",
                "request_id",
                "capability",
                "retry_after_ms",
                "actions",
                "support_context"
              ],
              "properties": {
                "capability": {
                  "enum": [
                    "ai.model-executions",
                    "ai.agent-runs"
                  ]
                },
                "user_guidance": {
                  "required": [
                    "localization"
                  ]
                },
                "support_context": {
                  "$ref": "#/$defs/modelContext"
                }
              }
            }
          }
        ]
      },
      "action": {
        "oneOf": [
          {
            "type": "object",
            "additionalProperties": false,
            "required": [
              "kind"
            ],
            "properties": {
              "kind": {
                "const": "retry"
              }
            }
          },
          {
            "type": "object",
            "additionalProperties": false,
            "required": [
              "kind"
            ],
            "properties": {
              "kind": {
                "const": "sign_in"
              }
            }
          },
          {
            "type": "object",
            "additionalProperties": false,
            "required": [
              "kind",
              "model_id"
            ],
            "properties": {
              "kind": {
                "const": "select_model"
              },
              "model_id": {
                "type": "string",
                "minLength": 1,
                "maxLength": 256
              }
            }
          },
          {
            "type": "object",
            "additionalProperties": false,
            "required": [
              "kind"
            ],
            "properties": {
              "kind": {
                "const": "select_free_model"
              },
              "model_id": {
                "type": "string",
                "minLength": 1,
                "maxLength": 256
              }
            }
          },
          {
            "type": "object",
            "additionalProperties": false,
            "required": [
              "kind"
            ],
            "properties": {
              "kind": {
                "const": "configure_provider"
              },
              "provider_id": {
                "type": "string",
                "minLength": 1,
                "maxLength": 256
              }
            }
          },
          {
            "type": "object",
            "additionalProperties": false,
            "required": [
              "kind",
              "provider_id"
            ],
            "properties": {
              "kind": {
                "const": "use_provider_key"
              },
              "provider_id": {
                "type": "string",
                "minLength": 1,
                "maxLength": 256
              }
            }
          },
          {
            "type": "object",
            "additionalProperties": false,
            "required": [
              "kind",
              "endpoint_id"
            ],
            "properties": {
              "kind": {
                "const": "use_model_endpoint"
              },
              "endpoint_id": {
                "type": "string",
                "minLength": 1,
                "maxLength": 256
              }
            }
          },
          {
            "type": "object",
            "additionalProperties": false,
            "required": [
              "kind"
            ],
            "properties": {
              "kind": {
                "const": "manage_plan"
              }
            }
          },
          {
            "type": "object",
            "additionalProperties": false,
            "required": [
              "kind"
            ],
            "properties": {
              "kind": {
                "const": "buy_ai_boost"
              }
            }
          },
          {
            "type": "object",
            "additionalProperties": false,
            "required": [
              "kind"
            ],
            "properties": {
              "kind": {
                "const": "contact_support"
              }
            }
          }
        ]
      },
      "modelContext": {
        "type": "object",
        "additionalProperties": false,
        "maxProperties": 11,
        "required": [
          "stage"
        ],
        "properties": {
          "origin": {
            "type": "string",
            "minLength": 1,
            "maxLength": 256
          },
          "route_template": {
            "type": "string",
            "minLength": 1,
            "maxLength": 512
          },
          "profile_binding": {
            "type": "string",
            "minLength": 1,
            "maxLength": 256
          },
          "product": {
            "type": "string",
            "minLength": 1,
            "maxLength": 256
          },
          "workload": {
            "type": "string",
            "minLength": 1,
            "maxLength": 256
          },
          "policy_binding": {
            "type": "string",
            "minLength": 1,
            "maxLength": 256
          },
          "catalog_binding": {
            "type": "string",
            "minLength": 1,
            "maxLength": 256
          },
          "stage": {
            "enum": [
              "facts",
              "selection",
              "reservation",
              "provider",
              "settlement",
              "transport",
              "authentication",
              "authorization"
            ]
          },
          "model_id": {
            "type": "string",
            "minLength": 1,
            "maxLength": 256
          },
          "agent_id": {
            "type": "string",
            "minLength": 1,
            "maxLength": 256
          },
          "provider_id": {
            "type": "string",
            "minLength": 1,
            "maxLength": 256
          }
        }
      }
    },
    "additionalProperties": false,
    "properties": {
      "error_code": {
        "$ref": "#/$defs/envelopeFields/properties/error_code"
      },
      "reason_code": {
        "$ref": "#/$defs/envelopeFields/properties/reason_code"
      },
      "request_id": {
        "$ref": "#/$defs/envelopeFields/properties/request_id"
      },
      "capability": {
        "$ref": "#/$defs/envelopeFields/properties/capability"
      },
      "provider_id": {
        "$ref": "#/$defs/envelopeFields/properties/provider_id"
      },
      "required_features": {
        "$ref": "#/$defs/envelopeFields/properties/required_features"
      },
      "missing_features": {
        "$ref": "#/$defs/envelopeFields/properties/missing_features"
      },
      "retryable": {
        "$ref": "#/$defs/envelopeFields/properties/retryable"
      },
      "user_guidance": {
        "$ref": "#/$defs/envelopeFields/properties/user_guidance"
      },
      "remediation": {
        "$ref": "#/$defs/envelopeFields/properties/remediation"
      },
      "support_context": {
        "$ref": "#/$defs/envelopeFields/properties/support_context"
      },
      "cause": {
        "$ref": "#/$defs/envelopeFields/properties/cause"
      },
      "retry_after_ms": {
        "$ref": "#/$defs/envelopeFields/properties/retry_after_ms"
      },
      "reset_at": {
        "$ref": "#/$defs/envelopeFields/properties/reset_at"
      },
      "actions": {
        "$ref": "#/$defs/envelopeFields/properties/actions"
      }
    }
  },
  "client-error-transport.v1.schema.json": {
    "$schema": "https://json-schema.org/draft/2020-12/schema",
    "$id": "https://schemas.kombify.dev/client/v1/error-transport.schema.json",
    "title": "Kombify running-channel error transport expansion",
    "description": "Only the pinned API HTTP, Gateway HTTP and model stream representations are retained. Remove legacy fields after Stable package/native parser adoption is evidenced on platform-ouhlt.6. New protocol fields belong in the canonical envelope.",
    "oneOf": [
      {
        "$ref": "#/$defs/apiHTTP"
      },
      {
        "$ref": "#/$defs/gatewayHTTP"
      },
      {
        "$ref": "#/$defs/stream"
      }
    ],
    "$defs": {
      "apiHTTP": {
        "type": "object",
        "allOf": [
          {
            "$ref": "client-error-envelope.v1.schema.json#/$defs/envelopeFields"
          }
        ],
        "required": [
          "error"
        ],
        "properties": {
          "error_code": {
            "$ref": "client-error-envelope.v1.schema.json#/$defs/envelopeFields/properties/error_code"
          },
          "reason_code": {
            "$ref": "client-error-envelope.v1.schema.json#/$defs/envelopeFields/properties/reason_code"
          },
          "request_id": {
            "$ref": "client-error-envelope.v1.schema.json#/$defs/envelopeFields/properties/request_id"
          },
          "capability": {
            "$ref": "client-error-envelope.v1.schema.json#/$defs/envelopeFields/properties/capability"
          },
          "provider_id": {
            "$ref": "client-error-envelope.v1.schema.json#/$defs/envelopeFields/properties/provider_id"
          },
          "required_features": {
            "$ref": "client-error-envelope.v1.schema.json#/$defs/envelopeFields/properties/required_features"
          },
          "missing_features": {
            "$ref": "client-error-envelope.v1.schema.json#/$defs/envelopeFields/properties/missing_features"
          },
          "retryable": {
            "$ref": "client-error-envelope.v1.schema.json#/$defs/envelopeFields/properties/retryable"
          },
          "user_guidance": {
            "$ref": "client-error-envelope.v1.schema.json#/$defs/envelopeFields/properties/user_guidance"
          },
          "remediation": {
            "$ref": "client-error-envelope.v1.schema.json#/$defs/envelopeFields/properties/remediation"
          },
          "support_context": {
            "$ref": "client-error-envelope.v1.schema.json#/$defs/envelopeFields/properties/support_context"
          },
          "cause": {
            "$ref": "client-error-envelope.v1.schema.json#/$defs/envelopeFields/properties/cause"
          },
          "retry_after_ms": {
            "$ref": "client-error-envelope.v1.schema.json#/$defs/envelopeFields/properties/retry_after_ms"
          },
          "reset_at": {
            "$ref": "client-error-envelope.v1.schema.json#/$defs/envelopeFields/properties/reset_at"
          },
          "actions": {
            "$ref": "client-error-envelope.v1.schema.json#/$defs/envelopeFields/properties/actions"
          },
          "error": {
            "type": "object",
            "additionalProperties": false,
            "required": [
              "code",
              "message"
            ],
            "properties": {
              "code": {
                "type": "string",
                "pattern": "^[a-z][a-z0-9]*(?:[._-][a-z0-9]+)*$"
              },
              "message": {
                "type": "string",
                "minLength": 1,
                "maxLength": 2000
              }
            }
          },
          "resetAt": {
            "type": "string",
            "anyOf": [
              {
                "const": ""
              },
              {
                "format": "date-time"
              }
            ]
          },
          "alternatives": {
            "type": "array",
            "maxItems": 2,
            "items": {
              "oneOf": [
                {
                  "type": "object",
                  "additionalProperties": false,
                  "required": [
                    "route",
                    "providerIds"
                  ],
                  "properties": {
                    "route": {
                      "const": "byok"
                    },
                    "providerIds": {
                      "type": "array",
                      "minItems": 1,
                      "maxItems": 64,
                      "uniqueItems": true,
                      "items": {
                        "type": "string",
                        "minLength": 1,
                        "maxLength": 256
                      }
                    }
                  }
                },
                {
                  "type": "object",
                  "additionalProperties": false,
                  "required": [
                    "route",
                    "endpointIds"
                  ],
                  "properties": {
                    "route": {
                      "const": "endpoint"
                    },
                    "endpointIds": {
                      "type": "array",
                      "minItems": 1,
                      "maxItems": 64,
                      "uniqueItems": true,
                      "items": {
                        "type": "string",
                        "minLength": 1,
                        "maxLength": 256
                      }
                    }
                  }
                }
              ]
            }
          },
          "topUp": {
            "type": "object",
            "additionalProperties": false,
            "required": [
              "addonId",
              "route"
            ],
            "properties": {
              "addonId": {
                "const": "ai_boost"
              },
              "route": {
                "const": "https://kombify.io/dashboard/billing#addons"
              }
            }
          }
        },
        "additionalProperties": false
      },
      "gatewayHTTP": {
        "type": "object",
        "allOf": [
          {
            "$ref": "client-error-envelope.v1.schema.json#/$defs/envelopeFields"
          }
        ],
        "required": [
          "error",
          "reason",
          "service"
        ],
        "properties": {
          "error_code": {
            "$ref": "client-error-envelope.v1.schema.json#/$defs/envelopeFields/properties/error_code"
          },
          "reason_code": {
            "$ref": "client-error-envelope.v1.schema.json#/$defs/envelopeFields/properties/reason_code"
          },
          "request_id": {
            "$ref": "client-error-envelope.v1.schema.json#/$defs/envelopeFields/properties/request_id"
          },
          "capability": {
            "$ref": "client-error-envelope.v1.schema.json#/$defs/envelopeFields/properties/capability"
          },
          "provider_id": {
            "$ref": "client-error-envelope.v1.schema.json#/$defs/envelopeFields/properties/provider_id"
          },
          "required_features": {
            "$ref": "client-error-envelope.v1.schema.json#/$defs/envelopeFields/properties/required_features"
          },
          "missing_features": {
            "$ref": "client-error-envelope.v1.schema.json#/$defs/envelopeFields/properties/missing_features"
          },
          "retryable": {
            "$ref": "client-error-envelope.v1.schema.json#/$defs/envelopeFields/properties/retryable"
          },
          "user_guidance": {
            "$ref": "client-error-envelope.v1.schema.json#/$defs/envelopeFields/properties/user_guidance"
          },
          "remediation": {
            "$ref": "client-error-envelope.v1.schema.json#/$defs/envelopeFields/properties/remediation"
          },
          "support_context": {
            "$ref": "client-error-envelope.v1.schema.json#/$defs/envelopeFields/properties/support_context"
          },
          "cause": {
            "$ref": "client-error-envelope.v1.schema.json#/$defs/envelopeFields/properties/cause"
          },
          "retry_after_ms": {
            "$ref": "client-error-envelope.v1.schema.json#/$defs/envelopeFields/properties/retry_after_ms"
          },
          "reset_at": {
            "$ref": "client-error-envelope.v1.schema.json#/$defs/envelopeFields/properties/reset_at"
          },
          "actions": {
            "$ref": "client-error-envelope.v1.schema.json#/$defs/envelopeFields/properties/actions"
          },
          "error": {
            "type": "string",
            "minLength": 1,
            "maxLength": 256
          },
          "reason": {
            "type": "string",
            "pattern": "^[a-z][a-z0-9]*(?:[._-][a-z0-9]+)*$"
          },
          "service": {
            "type": "string",
            "minLength": 1,
            "maxLength": 256
          },
          "source": {
            "const": "gateway_throttle"
          },
          "bucket": {
            "type": "string",
            "minLength": 1,
            "maxLength": 128
          }
        },
        "additionalProperties": false
      },
      "stream": {
        "type": "object",
        "additionalProperties": false,
        "required": [
          "type",
          "code",
          "message",
          "status",
          "denial"
        ],
        "properties": {
          "type": {
            "enum": [
              "error",
              "RUN_ERROR"
            ]
          },
          "code": {
            "type": "string",
            "pattern": "^[a-z][a-z0-9]*(?:[._-][a-z0-9]+)*$"
          },
          "message": {
            "type": "string",
            "minLength": 1,
            "maxLength": 2000
          },
          "status": {
            "type": "integer",
            "minimum": 400,
            "maximum": 599
          },
          "denial": {
            "$ref": "client-error-envelope.v1.schema.json"
          },
          "errorCode": {
            "type": "string",
            "pattern": "^[a-z][a-z0-9]*(?:[._-][a-z0-9]+)*$"
          },
          "reasonCode": {
            "type": "string",
            "pattern": "^[a-z][a-z0-9]*(?:[._-][a-z0-9]+)*$"
          },
          "retryable": {
            "type": "boolean"
          },
          "resetAt": {
            "type": "string",
            "anyOf": [
              {
                "const": ""
              },
              {
                "format": "date-time"
              }
            ]
          },
          "userGuidance": {
            "type": "object",
            "additionalProperties": false,
            "required": [
              "title",
              "body",
              "nextSteps"
            ],
            "properties": {
              "title": {
                "type": "string",
                "minLength": 1,
                "maxLength": 160
              },
              "body": {
                "type": "string",
                "minLength": 1,
                "maxLength": 2000
              },
              "nextSteps": {
                "type": "array",
                "minItems": 1,
                "maxItems": 8,
                "items": {
                  "type": "string",
                  "minLength": 1,
                  "maxLength": 500
                }
              }
            }
          },
          "param": {
            "type": "null"
          }
        }
      }
    }
  },
  "client-capability-registry.v1.json": {
    "version": "1",
    "capabilities": {
      "agents.approvals": {
        "authority": "ai-platform",
        "stability": "preview",
        "description": "Approve, deny, and resume governed agent runs."
      },
      "ai.agent-runs": {
        "authority": "ai-platform",
        "stability": "preview",
        "description": "Start and continue governed AI agent runs."
      },
      "ai.chat": {
        "authority": "ai-platform",
        "stability": "preview",
        "description": "Start and continue AI conversations."
      },
      "ai.history": {
        "authority": "ai-platform",
        "stability": "preview",
        "description": "Read durable AI sessions and transcripts."
      },
      "ai.model-executions": {
        "authority": "ai-platform",
        "stability": "preview",
        "description": "Request an admitted AI model execution."
      },
      "ai.structured.paperwork_quick_action": {
        "authority": "ai-platform",
        "stability": "preview",
        "description": "Run a structured Paperwork quick action."
      },
      "ai.structured.paperwork_tag_placement": {
        "authority": "ai-platform",
        "stability": "preview",
        "description": "Suggest tag placement for bound Paperwork content."
      },
      "ai.structured.paperwork_tags_cleanup": {
        "authority": "ai-platform",
        "stability": "preview",
        "description": "Clean up tags for a bound Paperwork document."
      },
      "ai.structured.homelab_provider_incident_advisory": {
        "authority": "ai-platform",
        "stability": "preview",
        "description": "Produce a structured Homelab provider incident advisory."
      },
      "paperwork.calendar": {
        "authority": "paperwork",
        "stability": "preview",
        "description": "Read and manage Paperwork calendar data."
      },
      "paperwork.documents": {
        "authority": "paperwork",
        "stability": "preview",
        "description": "Read and manage Paperwork documents."
      },
      "paperwork.mail": {
        "authority": "paperwork",
        "stability": "preview",
        "description": "Read and manage Paperwork mail."
      },
      "paperwork.search": {
        "authority": "paperwork",
        "stability": "preview",
        "description": "Search the bound Paperwork instance."
      },
      "paperwork.spaces": {
        "authority": "paperwork",
        "stability": "preview",
        "description": "Read and manage Paperwork spaces."
      },
      "paperwork.tasks": {
        "authority": "paperwork",
        "stability": "preview",
        "description": "Read and manage Paperwork tasks."
      },
      "speechkit.voice": {
        "authority": "speechkit",
        "stability": "preview",
        "description": "Use the shared recording, speech, and playback capability."
      },
      "homelab.runtime.read": {
        "authority": "homelab",
        "stability": "preview",
        "description": "Read Homelab runtime inventory and operational state."
      },
      "homelab.runtime.write": {
        "authority": "homelab",
        "stability": "preview",
        "description": "Request guarded Homelab runtime mutations."
      }
    }
  }
};
export const clientErrorEnvelopeKeys: readonly string[] = ["error_code","reason_code","request_id","capability","provider_id","required_features","missing_features","retryable","user_guidance","remediation","support_context","cause","retry_after_ms","reset_at","actions"];
