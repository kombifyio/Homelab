import { z } from "zod";

/**
 * The product map `kombify.product-map.v1`.
 *
 * A product publishes it about itself at `<origin>/product-map/v1/map.json`:
 * its pages, the controls that lead to them with the label of every locale,
 * tasks as ordered controls and, when captured, one screenshot per page with
 * the box of every marked control. The support runtime and the clients read
 * it. Nothing in it is person data.
 */
export const PRODUCT_MAP_SCHEMA = "kombify.product-map.v1" as const;

/** Where a product serves its map, relative to its origin. */
export const PRODUCT_MAP_PATH = "/product-map/v1/map.json" as const;

/** The path prefix every screenshot of a map lives under. */
export const PRODUCT_MAP_SCREENS_PREFIX = "/product-map/v1/screens/" as const;

export const PRODUCT_MAP_LIMITS = {
  pages: 200,
  controls: 600,
  tasks: 200,
  screens: 3000,
  locales: 20,
  pathLength: 10,
  steps: 8,
  requires: 8,
  labelChars: 160,
  purposeChars: 200,
  whereChars: 120,
  noteChars: 160,
  routeChars: 200,
  versionChars: 80,
  imageChars: 200,
  urlChars: 2048,
  imagePixels: 10000,
} as const;

/** Page, control and task ids: `settings.models-voice`, `nav.settings`. */
export const PRODUCT_MAP_ID_PATTERN = /^[a-z][a-z0-9.-]{1,79}$/;
/** Product ids: `companion-studio`. */
export const PRODUCT_MAP_PRODUCT_PATTERN = /^[a-z][a-z0-9-]{1,39}$/;
/** BCP 47 shaped locale keys: `en`, `de`, `zh-Hans`. */
const LOCALE_PATTERN = /^[a-z]{2,3}(?:-[A-Za-z0-9]{2,8})*$/;
/** A route: `/`, `/settings/models-voice`, `/fleet/agents/:agentId`. */
const ROUTE_PATTERN = /^\/(?:(?:[A-Za-z0-9._~-]+|:[A-Za-z][A-Za-z0-9_]*)(?:\/(?:[A-Za-z0-9._~-]+|:[A-Za-z][A-Za-z0-9_]*))*)?$/;
/** Short requirement codes: `supply-dock`, `voice-agent`. */
const REQUIRE_PATTERN = /^[a-z][a-z0-9-]{1,39}$/;
/** A screenshot path under the screens prefix, one file name per level, no traversal. */
const IMAGE_PATTERN = /^\/product-map\/v1\/screens\/(?:[A-Za-z0-9_-][A-Za-z0-9._-]*\/)*[A-Za-z0-9_-][A-Za-z0-9._-]*\.(?:webp|png)$/;

const id = z.string().regex(PRODUCT_MAP_ID_PATTERN);

/** What a page or control needs before a person has it: short codes, see PRODUCT_MAP_REQUIREMENTS. */
const requires = z.array(z.string().regex(REQUIRE_PATTERN)).max(PRODUCT_MAP_LIMITS.requires).optional();

/**
 * The requirement codes a map may use, with what each means in words and the
 * entitlement key the product checks where there is one. A runtime shows the
 * words. A code not listed here is still valid: it is shown as it is.
 */
export const PRODUCT_MAP_REQUIREMENTS = {
  "supply-dock": {
    en: "Needs a plan that includes running agents (the agent.run entitlement).",
    entitlement: "agent.run",
  },
  "voice-agent": {
    en: "Needs live voice in the plan (the speechkit.server.hosted and speechkit.voiceagent.live entitlements).",
    entitlement: "speechkit.voiceagent.live",
  },
  "model-choice": {
    en: "Needs a plan whose model catalog offers choosing single models.",
  },
} as const satisfies Record<string, { en: string; entitlement?: string }>;

const text = (max: number) =>
  z
    .string()
    .min(1)
    .max(max)
    .refine((value) => value.trim() === value && !/[\u0000-\u001f\u007f]/.test(value), {
      message: "text must be trimmed and free of control characters",
    });

/** A label in every locale the map carries. Always has `en`. */
export const productMapLocalizedSchema = z
  .record(z.string().regex(LOCALE_PATTERN), text(PRODUCT_MAP_LIMITS.labelChars))
  .refine((value) => typeof value.en === "string", { message: "a localized text needs \"en\"" })
  .refine((value) => Object.keys(value).length <= PRODUCT_MAP_LIMITS.locales, {
    message: "too many locales",
  });

export const productMapPageSchema = z.strictObject({
  id,
  route: z.string().max(PRODUCT_MAP_LIMITS.routeChars).regex(ROUTE_PATTERN),
  title: productMapLocalizedSchema,
  path: z.array(id).max(PRODUCT_MAP_LIMITS.pathLength),
  purpose: text(PRODUCT_MAP_LIMITS.purposeChars),
  requires,
});

export const productMapControlKindSchema = z.enum([
  "nav",
  "tab",
  "button",
  "field",
  "link",
  "menu",
  "toggle",
  "region",
]);

export const productMapControlSchema = z.strictObject({
  id,
  page: id.optional(),
  kind: productMapControlKindSchema,
  label: productMapLocalizedSchema,
  opens: id.optional(),
  anchor: z.string().regex(PRODUCT_MAP_ID_PATTERN).optional(),
  where: text(PRODUCT_MAP_LIMITS.whereChars),
  requires,
});

export const productMapActionSchema = z.enum(["open", "click", "choose", "type", "toggle"]);

export const productMapTaskStepSchema = z.strictObject({
  control: id,
  action: productMapActionSchema,
  note: text(PRODUCT_MAP_LIMITS.noteChars).optional(),
});

export const productMapTaskSchema = z.strictObject({
  id,
  title: productMapLocalizedSchema,
  steps: z.array(productMapTaskStepSchema).min(1).max(PRODUCT_MAP_LIMITS.steps),
  docs: z
    .string()
    .max(PRODUCT_MAP_LIMITS.urlChars)
    .refine(isHttpsUrl, { message: "docs must be an https URL" })
    .optional(),
});

const fraction = z.number().min(0).max(1);

export const productMapBoxSchema = z
  .strictObject({
    control: id,
    x: fraction,
    y: fraction,
    w: fraction,
    h: fraction,
  })
  .refine((box) => box.w > 0 && box.h > 0 && box.x + box.w <= 1.000001 && box.y + box.h <= 1.000001, {
    message: "a box must have a size and lie inside the image",
  });

export const productMapScreenSchema = z.strictObject({
  page: id,
  locale: z.string().regex(LOCALE_PATTERN),
  theme: z.enum(["light", "dark"]),
  image: z.string().max(PRODUCT_MAP_LIMITS.imageChars).regex(IMAGE_PATTERN),
  width: z.number().int().min(1).max(PRODUCT_MAP_LIMITS.imagePixels),
  height: z.number().int().min(1).max(PRODUCT_MAP_LIMITS.imagePixels),
  boxes: z.array(productMapBoxSchema).max(PRODUCT_MAP_LIMITS.controls),
});

const productMapObjectSchema = z.strictObject({
  schema: z.literal(PRODUCT_MAP_SCHEMA),
  product: z.string().regex(PRODUCT_MAP_PRODUCT_PATTERN),
  origin: z.string().max(PRODUCT_MAP_LIMITS.urlChars).refine(isMapOrigin, {
    message: "origin must be a bare https origin (http only for loopback)",
  }),
  version: text(PRODUCT_MAP_LIMITS.versionChars),
  generatedAt: z.iso.datetime({ offset: true }),
  locales: z
    .array(z.string().regex(LOCALE_PATTERN))
    .min(1)
    .max(PRODUCT_MAP_LIMITS.locales)
    .refine((locales) => locales.includes("en"), { message: "locales must include \"en\"" }),
  pages: z.array(productMapPageSchema).max(PRODUCT_MAP_LIMITS.pages),
  controls: z.array(productMapControlSchema).max(PRODUCT_MAP_LIMITS.controls),
  tasks: z.array(productMapTaskSchema).max(PRODUCT_MAP_LIMITS.tasks),
  screens: z.array(productMapScreenSchema).max(PRODUCT_MAP_LIMITS.screens),
});

/**
 * The whole map, with the cross references checked: ids are unique, every
 * id a page, control, task or screen names exists, every label carries every
 * locale of `locales`, and a screen exists once per page, locale and theme.
 */
export const productMapV1Schema = productMapObjectSchema.superRefine((map, context) => {
  const issue = (path: (string | number)[], message: string) =>
    context.addIssue({ code: "custom", path, message });

  const pageIds = new Set<string>();
  map.pages.forEach((page, index) => {
    if (pageIds.has(page.id)) issue(["pages", index, "id"], `duplicate page id ${page.id}`);
    pageIds.add(page.id);
  });
  const controlIds = new Set<string>();
  map.controls.forEach((control, index) => {
    if (controlIds.has(control.id)) issue(["controls", index, "id"], `duplicate control id ${control.id}`);
    controlIds.add(control.id);
  });
  const taskIds = new Set<string>();
  map.tasks.forEach((task, index) => {
    if (taskIds.has(task.id)) issue(["tasks", index, "id"], `duplicate task id ${task.id}`);
    taskIds.add(task.id);
  });
  if (new Set(map.locales).size !== map.locales.length) issue(["locales"], "duplicate locale");

  const everyLocale = (value: Record<string, string>, path: (string | number)[]) => {
    for (const locale of map.locales) {
      if (typeof value[locale] !== "string") issue(path, `missing locale ${locale}`);
    }
  };

  map.pages.forEach((page, index) => {
    everyLocale(page.title, ["pages", index, "title"]);
    page.path.forEach((entry, step) => {
      if (!controlIds.has(entry)) issue(["pages", index, "path", step], `unknown control ${entry}`);
    });
  });
  map.controls.forEach((control, index) => {
    everyLocale(control.label, ["controls", index, "label"]);
    if (control.page !== undefined && !pageIds.has(control.page)) {
      issue(["controls", index, "page"], `unknown page ${control.page}`);
    }
    if (control.opens !== undefined && !pageIds.has(control.opens)) {
      issue(["controls", index, "opens"], `unknown page ${control.opens}`);
    }
  });
  map.tasks.forEach((task, index) => {
    everyLocale(task.title, ["tasks", index, "title"]);
    task.steps.forEach((step, stepIndex) => {
      if (!controlIds.has(step.control)) {
        issue(["tasks", index, "steps", stepIndex, "control"], `unknown control ${step.control}`);
      }
    });
  });
  const screenKeys = new Set<string>();
  map.screens.forEach((screen, index) => {
    if (!pageIds.has(screen.page)) issue(["screens", index, "page"], `unknown page ${screen.page}`);
    if (!map.locales.includes(screen.locale)) issue(["screens", index, "locale"], `unknown locale ${screen.locale}`);
    const key = `${screen.page}|${screen.locale}|${screen.theme}`;
    if (screenKeys.has(key)) issue(["screens", index], `duplicate screen ${key}`);
    screenKeys.add(key);
    screen.boxes.forEach((box, boxIndex) => {
      if (!controlIds.has(box.control)) {
        issue(["screens", index, "boxes", boxIndex, "control"], `unknown control ${box.control}`);
      }
    });
  });
});

export type ProductMapLocalized = Record<string, string>;
export type ProductMapPage = z.infer<typeof productMapPageSchema>;
export type ProductMapControlKind = z.infer<typeof productMapControlKindSchema>;
export type ProductMapControl = z.infer<typeof productMapControlSchema>;
export type ProductMapAction = z.infer<typeof productMapActionSchema>;
export type ProductMapTaskStep = z.infer<typeof productMapTaskStepSchema>;
export type ProductMapTask = z.infer<typeof productMapTaskSchema>;
export type ProductMapBox = z.infer<typeof productMapBoxSchema>;
export type ProductMapScreen = z.infer<typeof productMapScreenSchema>;
export type ProductMapV1 = z.infer<typeof productMapV1Schema>;

function isHttpsUrl(value: string): boolean {
  try {
    return new URL(value).protocol === "https:";
  } catch {
    return false;
  }
}

function isMapOrigin(value: string): boolean {
  try {
    const url = new URL(value);
    if (url.origin !== value) return false;
    if (url.protocol === "https:") return true;
    return url.protocol === "http:" && ["localhost", "127.0.0.1", "[::1]"].includes(url.hostname);
  } catch {
    return false;
  }
}
