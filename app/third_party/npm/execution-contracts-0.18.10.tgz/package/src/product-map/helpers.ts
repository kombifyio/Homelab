import type {
  ProductMapBox,
  ProductMapControl,
  ProductMapLocalized,
  ProductMapPage,
  ProductMapScreen,
  ProductMapTask,
  ProductMapV1,
} from "./schema.js";

/**
 * Pure helpers over a validated map. The support runtime and every client use
 * these, so a route, a label or a search resolves the same way everywhere.
 * None of them fetches, and none of them invents: an id the map does not have
 * resolves to `undefined` or to nothing.
 */

/** The page with this id. */
export function productMapPage(map: ProductMapV1, pageId: string): ProductMapPage | undefined {
  return map.pages.find((page) => page.id === pageId);
}

/** The control with this id. */
export function productMapControl(map: ProductMapV1, controlId: string): ProductMapControl | undefined {
  return map.controls.find((control) => control.id === controlId);
}

/** The task with this id. */
export function productMapTask(map: ProductMapV1, taskId: string): ProductMapTask | undefined {
  return map.tasks.find((task) => task.id === taskId);
}

/**
 * The text of a localized value in a locale: the exact locale, then its
 * language part (`de-AT` reads `de`, `zh-CN` reads `zh-Hans` through the
 * language part `zh`), then English.
 */
export function localizedText(value: ProductMapLocalized, locale: string | undefined): string {
  const wanted = (locale ?? "").trim();
  if (wanted) {
    if (typeof value[wanted] === "string") return value[wanted];
    const lower = wanted.toLowerCase();
    const keys = Object.keys(value);
    const exact = keys.find((key) => key.toLowerCase() === lower);
    if (exact) return value[exact]!;
    const language = lower.split("-")[0]!;
    const sameLanguage = keys.find((key) => key.toLowerCase() === language) ??
      keys.find((key) => key.toLowerCase().split("-")[0] === language);
    if (sameLanguage) return value[sameLanguage]!;
  }
  return value.en ?? Object.values(value)[0] ?? "";
}

function routeSegments(route: string): string[] {
  let path = route.trim();
  if (/^[a-z][a-z0-9+.-]*:\/\//i.test(path)) {
    try {
      path = new URL(path).pathname;
    } catch {
      return [];
    }
  }
  path = path.split(/[?#]/, 1)[0] ?? "";
  return path.split("/").filter((segment) => segment.length > 0);
}

/**
 * The page a concrete route belongs to. `:param` segments match any one
 * segment, a query string and a hash are ignored, a full URL is read by its
 * path, and when several pages match the one with the most fixed segments
 * wins (`/supply-dock/library` over `/supply-dock/:category`).
 */
export function matchProductMapRoute(map: ProductMapV1, route: string): ProductMapPage | undefined {
  const segments = routeSegments(route).map((segment) => {
    try {
      return decodeURIComponent(segment).toLowerCase();
    } catch {
      return segment.toLowerCase();
    }
  });
  let best: { page: ProductMapPage; fixed: number } | undefined;
  for (const page of map.pages) {
    const pattern = routeSegments(page.route);
    if (pattern.length !== segments.length) continue;
    let fixed = 0;
    let matches = true;
    for (let index = 0; index < pattern.length; index += 1) {
      const part = pattern[index]!;
      if (part.startsWith(":")) continue;
      if (part.toLowerCase() !== segments[index]) {
        matches = false;
        break;
      }
      fixed += 1;
    }
    if (matches && (!best || fixed > best.fixed)) best = { page, fixed };
  }
  return best?.page;
}

/** The navigation path of a page, as the controls a person clicks in order. */
export function productMapPath(map: ProductMapV1, pageId: string): ProductMapControl[] {
  const page = productMapPage(map, pageId);
  if (!page) return [];
  return page.path
    .map((controlId) => productMapControl(map, controlId))
    .filter((control): control is ProductMapControl => control !== undefined);
}

/**
 * The screenshot of a page for a locale: the exact locale, then its language
 * part, then English, and never a picture in any other language. The theme is
 * preferred, light by default, and another theme is the fallback.
 */
export function screenFor(
  map: ProductMapV1,
  pageId: string,
  locale: string | undefined,
  theme: "light" | "dark" = "light",
): ProductMapScreen | undefined {
  const screens = map.screens.filter((screen) => screen.page === pageId);
  if (screens.length === 0) return undefined;
  const wanted = (locale ?? "").trim().toLowerCase();
  const language = wanted.split("-")[0] ?? "";
  const rank = (screen: ProductMapScreen): number => {
    const key = screen.locale.toLowerCase();
    const localeRank = key === wanted ? 0 : key.split("-")[0] === language && language ? 1 : key === "en" ? 2 : 3;
    return localeRank * 2 + (screen.theme === theme ? 0 : 1);
  };
  return [...screens]
    .filter((screen) => rank(screen) < 6)
    .sort((left, right) => rank(left) - rank(right))[0];
}

/** The recorded box of a control on a screenshot, as fractions of the image. */
export function screenBox(screen: ProductMapScreen, controlId: string): Omit<ProductMapBox, "control"> | undefined {
  const box = screen.boxes.find((entry) => entry.control === controlId);
  return box ? { x: box.x, y: box.y, w: box.w, h: box.h } : undefined;
}

export interface ProductMapHit<T> {
  item: T;
  score: number;
}

export interface ProductMapSearchResult {
  pages: ProductMapHit<ProductMapPage>[];
  controls: ProductMapHit<ProductMapControl>[];
  tasks: ProductMapHit<ProductMapTask>[];
}

/** Lower case, accents removed, so "Paramètres" finds "parametres". */
function fold(value: string): string {
  return value.normalize("NFKD").replace(/\p{M}+/gu, "").toLowerCase();
}

/** Letters and digits split into words, CJK kept as runs. */
function words(value: string): string[] {
  return fold(value).split(/[^\p{L}\p{N}]+/u).filter((word) => word.length > 0);
}

const HAN = /[\p{Script=Han}\p{Script=Hiragana}\p{Script=Katakana}\p{Script=Hangul}]/u;

function tokenize(query: string): string[] {
  const tokens = words(query).filter((word) => word.length >= 2 || HAN.test(word));
  return [...new Set(tokens)].slice(0, 12);
}

/**
 * How well a text matches the query tokens: a whole word scores 3, a word
 * that starts with the token 2 and any other occurrence 1 (CJK has no spaces,
 * so it only has occurrences). Weighted by where the text sits.
 */
function scoreText(text: string, tokens: string[], weight: number): number {
  if (!text) return 0;
  const folded = fold(text);
  const textWords = words(text);
  let score = 0;
  for (const token of tokens) {
    if (textWords.includes(token)) score += 3;
    else if (textWords.some((word) => word.startsWith(token))) score += 2;
    else if (folded.includes(token)) score += 1;
  }
  return score * weight;
}

function scoreLocalized(value: ProductMapLocalized, locale: string, tokens: string[], weight: number): number {
  const own = localizedText(value, locale);
  const english = value.en ?? "";
  return Math.max(scoreText(own, tokens, weight), scoreText(english, tokens, weight));
}

/**
 * A small lexical search over page titles and purposes, control labels and
 * task titles, in the person's locale and in English. Every list is ordered by
 * score and holds at most `limit` entries. An empty query finds nothing.
 */
export function findInProductMap(
  map: ProductMapV1,
  query: string,
  locale: string,
  limit = 5,
): ProductMapSearchResult {
  const tokens = tokenize(query);
  const empty: ProductMapSearchResult = { pages: [], controls: [], tasks: [] };
  if (tokens.length === 0 || limit <= 0) return empty;
  const phrase = fold(query.trim());
  const phraseBonus = (value: ProductMapLocalized) =>
    phrase.length >= 3 &&
    (fold(localizedText(value, locale)).includes(phrase) || fold(value.en ?? "").includes(phrase))
      ? 4
      : 0;

  const rank = <T>(hits: ProductMapHit<T>[]) =>
    hits
      .filter((hit) => hit.score > 0)
      .sort((left, right) => right.score - left.score)
      .slice(0, limit);

  return {
    pages: rank(
      map.pages.map((page) => ({
        item: page,
        score:
          scoreLocalized(page.title, locale, tokens, 3) +
          scoreText(page.purpose, tokens, 1) +
          phraseBonus(page.title),
      })),
    ),
    controls: rank(
      map.controls.map((control) => ({
        item: control,
        score: scoreLocalized(control.label, locale, tokens, 3) + phraseBonus(control.label),
      })),
    ),
    tasks: rank(
      map.tasks.map((task) => ({
        item: task,
        score: scoreLocalized(task.title, locale, tokens, 3) + phraseBonus(task.title),
      })),
    ),
  };
}
