/**
 * The MCP form of the `workbench.host.use` lease (Connect contract §17, Beads platform-gs8vjz.4).
 *
 * The Gateway is the MCP client of every Workbench host a person links through kombify Connect
 * (workspace D-2026-11-18-02). For each call it mints one lease: an EdDSA JWS signed with the
 * Connect mint key the host already trusts, naming the host generation, the linking owner's
 * full-environment grant, the caller (the person or one of the person's agents) and the digest
 * of the exact JSON-RPC body. The host serves the call with the owner's full access.
 *
 * - Transport: `POST <endpoint.http_base_url>/mcp`, `Authorization: Bearer <lease>`, stateless MCP
 *   `WORKBENCH_HOST_MCP_PROTOCOL_VERSION` (one POST per call, no initialize, no session).
 * - One lease serves one call: the host consumes its `jti`, Gateway mints a fresh one per call.
 * - Before any effect the host asks Gateway for current authority
 *   (`POST /v1/environments/{environmentId}/mcp/authority`, Connect host proof). `continue`
 *   keeps an agent-started turn running for as long as the link, the Supply Dock connection,
 *   the owner and the host generation stay current.
 */
import { sha256 } from "@noble/hashes/sha2";

import {
  CONNECT_CLOCK_SKEW_SECONDS,
  type ConnectCapability,
  type ConnectMintClaimsV1,
  type ConnectT3Scope,
} from "./contract.js";
import { signEdDsaJws, verifyEdDsaJws } from "./jws.js";

/** The capability the MCP lease names (Connect contract §17). */
const WORKBENCH_HOST_CAPABILITY_ID = "workbench.host.use";

export const WORKBENCH_HOST_MCP_LEASE_TYPE = "kombify-connect-mcp-lease+jwt" as const;
export const WORKBENCH_HOST_MCP_PATH = "/mcp" as const;
export const WORKBENCH_HOST_MCP_FORM = "mcp" as const;
/** The stateless MCP protocol one call is served under: no initialize, no session (headers MCP-Protocol-Version, Mcp-Method, Mcp-Name; body params._meta). */
export const WORKBENCH_HOST_MCP_PROTOCOL_VERSION = "2026-07-28" as const;
export const WORKBENCH_HOST_MCP_LEASE_MAX_LIFETIME_SECONDS = 60 as const;
export const WORKBENCH_HOST_MCP_BODY_DIGEST_DOMAIN = "kombify.workbench-host-mcp-body.digest.v1" as const;
/** Gateway instance id of a linked environment in the MCP instance registry. */
export const WORKBENCH_HOST_INSTANCE_PREFIX = "workbench-host:" as const;

export function workbenchHostInstanceIdV1(environmentId: string): string {
  if (!identifier(environmentId, 128)) throw new Error("Invalid Workbench host environment.");
  return `${WORKBENCH_HOST_INSTANCE_PREFIX}${environmentId}`;
}

export function workbenchHostMcpAuthorityPathV1(environmentId: string): string {
  if (!identifier(environmentId, 128)) throw new Error("Invalid Workbench host environment.");
  return `/v1/environments/${environmentId}/mcp/authority`;
}

/** The person, or one of the person's agents (its instance and the run that makes the call). */
export type WorkbenchHostMcpCallerV1 =
  | { readonly kind: "person" }
  | { readonly kind: "agent"; readonly agentInstanceId: string; readonly runId: string };

export interface WorkbenchHostMcpLeaseClaimsV1 {
  /** The Connect issuer (`CONNECT_ORIGIN`). */
  readonly iss: string;
  readonly aud: `t3-env:${string}`;
  /** The linking owner. */
  readonly sub: string;
  readonly iat: number;
  readonly exp: number;
  /** One call: the host consumes it once. */
  readonly jti: string;
  readonly environmentId: string;
  readonly orgId: string;
  readonly method: "POST";
  readonly path: typeof WORKBENCH_HOST_MCP_PATH;
  readonly capability: typeof WORKBENCH_HOST_CAPABILITY_ID;
  readonly form: typeof WORKBENCH_HOST_MCP_FORM;
  readonly caller: WorkbenchHostMcpCallerV1;
  /** Gateway request id of the call. */
  readonly requestId: string;
  /** The call's `clientRequestId` when it has one, else `requestId`. */
  readonly commandId: string;
  readonly bodyDigest: `sha256:${string}`;
  /** The owner's full-environment grant, the same claims as a Connect credential mint. */
  readonly kombify_connect: ConnectMintClaimsV1;
}

export type WorkbenchHostMcpAuthorityPurposeV1 = "admit" | "continue";

export interface WorkbenchHostMcpAuthorityRequestV1 {
  readonly lease: string;
  readonly purpose: WorkbenchHostMcpAuthorityPurposeV1;
}

export interface WorkbenchHostMcpAuthorityV1 {
  readonly authority: "current";
  readonly environmentId: string;
  readonly subject: string;
  readonly caller: WorkbenchHostMcpCallerV1;
  readonly commandId: string;
  readonly hostGeneration: number;
}

const textEncoder = new TextEncoder();

/** Digest of the exact body bytes the host receives. */
export function workbenchHostMcpBodyDigestV1(body: Uint8Array | string): `sha256:${string}` {
  const bytes = typeof body === "string" ? textEncoder.encode(body) : body;
  const prefix = textEncoder.encode(`${WORKBENCH_HOST_MCP_BODY_DIGEST_DOMAIN}\n`);
  const input = new Uint8Array(prefix.length + bytes.length);
  input.set(prefix, 0);
  input.set(bytes, prefix.length);
  return `sha256:${Array.from(sha256(input), (byte) => byte.toString(16).padStart(2, "0")).join("")}`;
}

export function signWorkbenchHostMcpLeaseV1(input: {
  readonly seed: Uint8Array;
  readonly kid?: string;
  readonly claims: WorkbenchHostMcpLeaseClaimsV1;
}): string {
  const claims = parseWorkbenchHostMcpLeaseClaimsV1(input.claims);
  return signEdDsaJws({
    seed: input.seed,
    typ: WORKBENCH_HOST_MCP_LEASE_TYPE,
    ...(input.kid ? { kid: input.kid } : {}),
    payload: claims as unknown as Record<string, unknown>,
  });
}

export type WorkbenchHostMcpLeaseResult =
  | { readonly ok: true; readonly claims: WorkbenchHostMcpLeaseClaimsV1 }
  | { readonly ok: false; readonly reason: string };

/**
 * Signature and every immutable binding of one call. The host additionally checks the grant
 * claims against its running state, consumes the `jti` and asks Gateway for current authority.
 * `allowExpired` serves `continue` authority checks of an agent-started turn.
 */
export function verifyWorkbenchHostMcpLeaseV1(input: {
  readonly token: string;
  readonly publicKey: Uint8Array;
  readonly issuer: string;
  readonly environmentId: string;
  readonly now: number;
  /** The running host generation; omitted only by Gateway, which checks it against its own record. */
  readonly hostGeneration?: number;
  /** The exact received body; omitted only by Gateway's `continue` check. */
  readonly body?: Uint8Array | string;
  readonly allowExpired?: boolean;
}): WorkbenchHostMcpLeaseResult {
  if (typeof input.token !== "string" || input.token.length === 0 || input.token.length > 16_384)
    return { ok: false, reason: "workbench_host_mcp_lease_invalid" };
  const verified = verifyEdDsaJws<Record<string, unknown>>({
    token: input.token,
    publicKey: input.publicKey,
    typ: WORKBENCH_HOST_MCP_LEASE_TYPE,
  });
  if (!verified.ok) return { ok: false, reason: "workbench_host_mcp_lease_invalid" };
  let claims: WorkbenchHostMcpLeaseClaimsV1;
  try {
    claims = parseWorkbenchHostMcpLeaseClaimsV1(verified.payload);
  } catch {
    return { ok: false, reason: "workbench_host_mcp_lease_invalid" };
  }
  if (claims.iss !== input.issuer || claims.environmentId !== input.environmentId || claims.aud !== `t3-env:${input.environmentId}`)
    return { ok: false, reason: "workbench_host_mcp_lease_audience" };
  if (input.hostGeneration !== undefined && claims.kombify_connect.host_generation !== input.hostGeneration)
    return { ok: false, reason: "workbench_host_mcp_lease_generation" };
  if (claims.iat > input.now + CONNECT_CLOCK_SKEW_SECONDS) return { ok: false, reason: "workbench_host_mcp_lease_not_yet_valid" };
  if (!input.allowExpired && claims.exp <= input.now) return { ok: false, reason: "workbench_host_mcp_lease_expired" };
  if (input.body !== undefined && workbenchHostMcpBodyDigestV1(input.body) !== claims.bodyDigest)
    return { ok: false, reason: "workbench_host_mcp_lease_body" };
  return { ok: true, claims };
}

export function parseWorkbenchHostMcpLeaseClaimsV1(value: unknown): WorkbenchHostMcpLeaseClaimsV1 {
  const claims = record(value, "lease");
  only(claims, [
    "iss", "aud", "sub", "iat", "exp", "jti", "environmentId", "orgId", "method", "path", "capability", "form",
    "caller", "requestId", "commandId", "bodyDigest", "kombify_connect",
  ]);
  const environmentId = claims.environmentId;
  if (
    !identifier(claims.iss, 256) || !identifier(environmentId, 128) || claims.aud !== `t3-env:${environmentId}` ||
    !identifier(claims.sub, 256) || !identifier(claims.orgId, 256) || !identifier(claims.jti, 128) ||
    !identifier(claims.requestId, 128) || !identifier(claims.commandId, 256) ||
    claims.method !== "POST" || claims.path !== WORKBENCH_HOST_MCP_PATH ||
    claims.capability !== WORKBENCH_HOST_CAPABILITY_ID || claims.form !== WORKBENCH_HOST_MCP_FORM ||
    typeof claims.bodyDigest !== "string" || !/^sha256:[0-9a-f]{64}$/u.test(claims.bodyDigest) ||
    !Number.isSafeInteger(claims.iat) || !Number.isSafeInteger(claims.exp) ||
    (claims.exp as number) <= (claims.iat as number) ||
    (claims.exp as number) - (claims.iat as number) > WORKBENCH_HOST_MCP_LEASE_MAX_LIFETIME_SECONDS
  )
    throw new Error("Invalid Workbench host MCP lease.");
  return { ...(claims as unknown as WorkbenchHostMcpLeaseClaimsV1), caller: parseCaller(claims.caller), kombify_connect: parseGrant(claims.kombify_connect) };
}

export function parseWorkbenchHostMcpAuthorityRequestV1(value: unknown): WorkbenchHostMcpAuthorityRequestV1 {
  const request = record(value, "authority request");
  only(request, ["lease", "purpose"]);
  if (typeof request.lease !== "string" || request.lease.length === 0 || request.lease.length > 16_384 ||
      (request.purpose !== "admit" && request.purpose !== "continue"))
    throw new Error("Invalid Workbench host MCP authority request.");
  return { lease: request.lease, purpose: request.purpose };
}

function parseCaller(value: unknown): WorkbenchHostMcpCallerV1 {
  const caller = record(value, "caller");
  if (caller.kind === "person") {
    only(caller, ["kind"]);
    return { kind: "person" };
  }
  only(caller, ["kind", "agentInstanceId", "runId"]);
  if (caller.kind !== "agent" || !identifier(caller.agentInstanceId, 256) || !identifier(caller.runId, 256))
    throw new Error("Invalid Workbench host MCP caller.");
  return { kind: "agent", agentInstanceId: caller.agentInstanceId, runId: caller.runId };
}

function parseGrant(value: unknown): ConnectMintClaimsV1 {
  const grant = record(value, "grant");
  only(grant, [
    "installation_id", "installation_epoch", "grant_id", "grant_revision", "grant_version", "host_generation",
    "profile", "capabilities", "t3_scopes", "session_expires_at",
  ]);
  const counts = ["installation_epoch", "grant_revision", "grant_version", "host_generation", "session_expires_at"] as const;
  if (
    !identifier(grant.installation_id, 128) || !identifier(grant.grant_id, 128) ||
    counts.some((key) => !Number.isSafeInteger(grant[key]) || (grant[key] as number) < 0) ||
    (grant.host_generation as number) < 1 || grant.profile !== "full-environment" ||
    !stringList(grant.capabilities) || !stringList(grant.t3_scopes)
  )
    throw new Error("Invalid Workbench host MCP grant.");
  return {
    installation_id: grant.installation_id,
    installation_epoch: grant.installation_epoch as number,
    grant_id: grant.grant_id,
    grant_revision: grant.grant_revision as number,
    grant_version: grant.grant_version as number,
    host_generation: grant.host_generation as number,
    profile: "full-environment",
    capabilities: grant.capabilities as ConnectCapability[],
    t3_scopes: grant.t3_scopes as ConnectT3Scope[],
    session_expires_at: grant.session_expires_at as number,
  };
}

function record(value: unknown, what: string): Record<string, unknown> {
  if (value === null || typeof value !== "object" || Array.isArray(value)) throw new Error(`Invalid Workbench host MCP ${what}.`);
  return value as Record<string, unknown>;
}

function only(value: Record<string, unknown>, keys: readonly string[]): void {
  if (Object.keys(value).some((key) => !keys.includes(key))) throw new Error("Unexpected Workbench host MCP field.");
}

function stringList(value: unknown): value is string[] {
  return Array.isArray(value) && value.length <= 32 && value.every((entry) => identifier(entry, 64));
}

function identifier(value: unknown, max: number): value is string {
  return (
    typeof value === "string" && value.length > 0 && value.length <= max && value.trim() === value &&
    !Array.from(value).some((character) => character.charCodeAt(0) < 33 || character.charCodeAt(0) === 127)
  );
}
